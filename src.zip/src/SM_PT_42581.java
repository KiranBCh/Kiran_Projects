import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_PT_42581 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);
		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(7000);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("Testperforma");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'Testperforma')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("CAPE FLORES");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
		Actions actions = new Actions(driver);
		driver.findElement(By.xpath("//button[@id='btnScheduleEditing']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class='buttoNs']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--standard q-btn--rectangle q-btn--actionable q-focusable q-hoverable sbtn']")).click();
		Thread.sleep(3000);
		List<WebElement> TerminalName = driver.findElements(By.xpath("((//div[@class='service-lanes']//div[@class='service-lane'])[2]//div[@class='terminalNameContainer']//input)[1]"));
		String BeforeTerminalNameStr = "";
		for(WebElement value : TerminalName) {
			if(value.getAttribute("value") != null) {				
				BeforeTerminalNameStr = value.getAttribute("value");
				break;
			}
		}
		WebElement changeTerminal = driver.findElement(By.xpath("((//div[@class='service-lanes']//div[@class='service-lane'])[2]//div[@class='terminalNameContainer']//input)[1]"));
		Thread.sleep(2000);
		actions.moveToElement(changeTerminal).doubleClick().perform();
		changeTerminal.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(7000);
		changeTerminal.sendKeys("CIT");
		Thread.sleep(7000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		List<WebElement> AfterTerminalName = driver.findElements(By.xpath("((//div[@class='service-lanes']//div[@class='service-lane'])[2]//div[@class='terminalNameContainer']//input)[1]"));
		String AfterTerminalNameStr = "";
		for(WebElement value : AfterTerminalName) {
			if(value.getAttribute("value") != null) {				
				AfterTerminalNameStr = value.getAttribute("value");
				break;
			}
		}
		if (AfterTerminalNameStr != BeforeTerminalNameStr) {
			System.out.println("Verifyed, BeforeTerminalName= "+ BeforeTerminalNameStr + "  AfterTerminalName= " + AfterTerminalNameStr);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Verifyed, BeforeTerminalName= "+ BeforeTerminalNameStr + "  AfterTerminalName= " + AfterTerminalNameStr, "", "Pass", "42582", 1, "Verify");
		}
		else {
			System.out.println("Not Verifyed, BeforeTerminalName= "+ BeforeTerminalNameStr + "  AfterTerminalName= " + AfterTerminalNameStr);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Not Verifyed, BeforeTerminalName= "+ BeforeTerminalNameStr + "  AfterTerminalName= " + AfterTerminalNameStr, "", "Pass", "42582", 1, "Verify");
		}
		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(3000);
		List<WebElement> SecondTerminalName = driver.findElements(By.xpath("((//tr[@class='data-table__row data-table__row--centered'])[1]//td//div[@class='data-table__sub-td'])[3]//input[@class='q-field__input q-placeholder col']"));
		String SecondTerminalNameValue = "";
		for(WebElement value : SecondTerminalName) {
			if(value.getAttribute("value") != null) {				
				SecondTerminalNameValue = value.getAttribute("value");
				break;
			}
		}
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement SecondTerminalNameChange = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered'])[1]//td//div[@class='data-table__sub-td'])[3]//input[@class='q-field__input q-placeholder col']"));
		SecondTerminalNameChange.click();
		SecondTerminalNameChange.sendKeys("CCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		List<WebElement> AfterSecondTerminalName = driver.findElements(By.xpath("((//tr[@class='data-table__row data-table__row--centered'])[1]//td//div[@class='data-table__sub-td'])[3]//input[@class='q-field__input q-placeholder col']"));
		String AfterSecondTerminalNameValue = "";
		for(WebElement value : AfterSecondTerminalName) {
			if(value.getAttribute("value") != null) {				
				AfterSecondTerminalNameValue = value.getAttribute("value");
				break;
			}
		}
		if (SecondTerminalNameValue != AfterSecondTerminalNameValue) {
			System.out.println("Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue, "", "Pass", "42582", 1, "Verify");
		}
		else {
			System.out.println("Not_Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Not_Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue, "", "Fail", "42582", 1, "Verify");
		}
	}
}
