import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Tb_Cursor_test1 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(3000);
		WebElement Schedule1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Schedule1.click();
		Thread.sleep(9000);
        Actions actions = new Actions(driver);

		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.moveToElement(Lane).build().perform();
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(5000);
		
		WebElement element = driver.findElement(By.xpath("//div[@class='q-card portBlock default resizable']"));
		//actions.clickAndHold(element).moveByOffset(150, 100).perform();
		/*
		System.out.println("Size= "+element.getSize());
		//element.getSize().width - 5
		actions.moveToElement(element, element.getSize().height + 100, 0)
        .clickAndHold()
        .moveByOffset(80, 80)  // Adjust the offset based on how much you want to resize
        .release()
        .perform();
		*/
		new Actions(driver).keyDown(Keys.SHIFT).sendKeys(inputElement, "hello").keyUp(Keys.SHIFT).perform();
		
	}
}
