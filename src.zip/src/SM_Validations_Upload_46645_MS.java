import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Validations_Upload_46645_MS {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(9000);
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("MARINA");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(7000);
		
		WebElement ScheduleInformation = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		ScheduleInformation.click();
		Thread.sleep(8000);
				
		WebElement AddPort = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPort.click();
		Thread.sleep(3000);
		
		WebElement AddPortName = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPortName.click();		
		Thread.sleep(3000);
		for (int i = 0; i < 2; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		Thread.sleep(4000);
		AddPortName.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement AddPort2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPort2.click();
		Thread.sleep(3000);
		
		WebElement AddPortName2 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPortName2.click();		
		Thread.sleep(3000);
		
		AddPortName2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement enterExNum1 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[8]//input"));
		enterExNum1.click();
		enterExNum1.sendKeys("1");
		Thread.sleep(2000);
		WebElement enterExNum2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]//td[8]//input"));
		enterExNum2.click();
		enterExNum2.sendKeys("1");
		Thread.sleep(2000);
		
		WebElement terminal1 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[3]"));
		terminal1.click();
		Thread.sleep(3000);
		
		WebElement Internalvoyage1 = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
		Internalvoyage1.click();
		Thread.sleep(5000);
		
		WebElement GenerateNumber = driver.findElement(By.xpath("//div[@class='q-card__section q-card__section--vert'][2]//div[@class='toggle-items']//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']"));
		GenerateNumber.click();
		Thread.sleep(2000);
		
        driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
        
        WebElement terminalunselect = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[3]"));
        terminalunselect.click();
		Thread.sleep(3000);
		// First Port Unselect 
				
		WebElement terminal1Checkbox2 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
		terminal1Checkbox2.click();
		Thread.sleep(3000);
				
		WebElement InternalvoyageNumber2 = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
		InternalvoyageNumber2.click();
		Thread.sleep(5000);
				
		WebElement GenerateNumber2 = driver.findElement(By.xpath("//div[@class='q-card__section q-card__section--vert'][2]//div[@class='toggle-items']//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']"));
		GenerateNumber2.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
		WebElement terminalunselect2 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
		terminalunselect2.click();
		
		WebElement VesselOperator1 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[4]//input"));
		VesselOperator1.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		
		WebElement VesselOperator2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]/td[4]//input"));
		VesselOperator2.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement Leg1 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]/td[18]//input"));
		Leg1.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement Leg2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]/td[18]//input"));
		Leg2.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		driver.findElement(By.xpath("//button[@id='btnSaveServiceCentral']")).click();
		Thread.sleep(4000);
		
		WebElement exit1 = driver.findElement(By.xpath("//div[@class='q-banner row items-center q-banner--top-padding text-white bg-red']"));
		
		driver.findElement(By.xpath("//button[@id='btnSaveServiceCentral']")).click();
	
		//Operation Status
		WebElement OS1 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[1]//td[18]//div[@id='ddlPortOperationStatuses']"));
		OS1.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//th[contains(text(), 'Operation Status')]")).click();
		Thread.sleep(2000);
		
		WebElement OS2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[2]//td[18]//div[@id='ddlPortOperationStatuses']"));
		OS2.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//th[contains(text(), 'Product Pairing')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnSaveServiceCentral']")).click();
		Thread.sleep(2000);
	}
}
