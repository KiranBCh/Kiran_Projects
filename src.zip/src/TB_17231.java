import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TB_17231 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		Thread.sleep(9000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Robot robot = new Robot();
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("BDCGP");
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddPort);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		for (int i = 0; i <= 3 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddTerminalName = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//div[@class='highlight data-table__sub-td']//input"));
		AddTerminalName.click();
		Thread.sleep(3000);
		AddTerminalName.sendKeys("CCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName);
		
		WebElement SelectTerminal = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//div[@class='data-table__sub-td']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectTerminal.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		Thread.sleep(3000);
		
		WebElement SecondTerminal = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[@class='data-table__sticky-column_3']//div[@class='data-table__sub-td']//input[@class='q-field__input q-placeholder col']"));
		SecondTerminal.click();
		Thread.sleep(3000);
		SecondTerminal.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		Thread.sleep(3000);
		SecondTerminal.sendKeys("NCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName);
		
		WebElement UnSelectTerminal = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//div[@class='data-table__sub-td']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		UnSelectTerminal.click();
		Thread.sleep(3000);
		
		WebElement backbutton = driver.findElement(By.xpath("(//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row'])[1]//i[@class='q-icon notranslate material-icons']"));
		backbutton.click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(3000);
		
		WebElement unselect1stTerminal = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered selected-row'])[1]//td[@class='data-table__sticky-column_3']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		unselect1stTerminal.click();
		Thread.sleep(3000);
		
		WebElement detele1stTerminal = driver.findElement(By.xpath("(//button[@id='btnDelete'])[2]//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']"));
		Thread.sleep(3000);
		detele1stTerminal.click();
		//Calclulation
		//New Pilot In = Berth time of first terminal (after deletion) - Arrival Time
		WebElement PortStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[16]"));
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
		
		//String PortStayText = PortStay.getText();
		
		long pilotInValue = Long.parseLong(PilotIn.getText());
		long pilotOutValue = Long.parseLong(PilotOut.getText());
		//int PortStayValue = Integer.parseInt(PortStayText);
		if (pilotInValue != 0) {
			//cl.log.info("pilotIn -->"+ pilotInValue);
	        //cl.ActualTestDataValue = "Pilot In";
	    	//cl.result("Verified, Pilot In= "+ pilotInValue, "" , "Pass", "", 1, "VERIFY");
		}
		
		WebElement ArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p"));
		String ArrivalTimeValue = ArrivalTime.getText();
		System.out.println("ArrivalTimeValue-->"+ArrivalTimeValue);
		if (ArrivalTimeValue != null) {
			//cl.log.info("ArrivalTime -->"+ ArrivalTimeValue);
	        //cl.ActualTestDataValue = "Arrival Time";
	    	//cl.result("Verified, Arrival Time= "+ ArrivalTimeValue, "" , "Pass", "", 1, "VERIFY");
		}
		WebElement BerthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered'][1]//td[19]//div[@class='clickable']//p"));
		String BerthTimeValue = BerthTime.getText();
		System.out.println("BerthTimeValue-->"+BerthTimeValue);
		if (BerthTimeValue != null) {
			//cl.log.info("BerthTime -->"+ BerthTimeValue);
	        //cl.ActualTestDataValue = "Berth Time";
	    	//cl.result("Verified, Berth Time= "+ BerthTimeValue, "" , "Pass", "", 1, "VERIFY");
		}
		//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Week' W, E HH:mm");
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        // Parse the dates
		Date date1 = dateFormat.parse(ArrivalTimeValue);
		Date date2 = dateFormat.parse(BerthTimeValue);
		long timeDifferenceMillis = Math.abs(date2.getTime() - date1.getTime());
		long hoursBetween = timeDifferenceMillis / (60 * 60 * 1000);
		long roundedHours = Math.round(hoursBetween);
        // Calculate the difference in hours
        System.out.println("Difference in hours: " + roundedHours + " hours");
	   if (pilotInValue == -(roundedHours)) {
		   	//cl.log.info("New Pilot In = Berth time of first terminal (after deletion) - Arrival Time -->"+ roundedHours);
	        //cl.ActualTestDataValue = "Berth time of first terminal - Arrival Time";
	    	//cl.result("Verified, New Pilot In= "+ roundedHours, "" , "Pass", "", 1, "VERIFY");
	   }else {
		 //cl.log.info("New Pilot In = Berth time of first terminal (after deletion) - Arrival Time -->"+ roundedHours);
	        //cl.ActualTestDataValue = "Berth time of first terminal - Arrival Time";
	    	//cl.result("Verified, New Pilot In= "+ roundedHours, "" , "Fail", "", 1, "VERIFY"); 
	   }
	   //New Shifting for all terminals = Berth Time - Unberth time of earlier terminal (if any), else Shifting Time = 0
	   int ShiftingTime = 0;
	   if (ShiftingTime == 0) {
		   	//cl.log.info("New Shifting for all terminals = Berth Time - Unberth time of earlier terminal (if any), else Shifting Time = 0);
	        //cl.ActualTestDataValue = "Shifting Time";
	    	//cl.result("Verified, Shifting Time= "+ ShiftingTime, "" , "Pass", "", 1, "VERIFY");
	   }
	   //New Pilot Out = Departure Time - Unberth time of last terminal (after deletion)
	   if (pilotOutValue != 0) {
			//cl.log.info("pilotOut -->"+ pilotOutValue);
	        //cl.ActualTestDataValue = "Pilot Out";
	    	//cl.result("Verified, Pilot Out= "+ pilotOutValue, "" , "Pass", "", 1, "VERIFY");
		}
	   WebElement DepartureTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[22]//div[@class='clickable']//p"));
		String DepartureTimeValue = DepartureTime.getText();
		System.out.println("DepartureTimeValue-->"+DepartureTimeValue);
		if (DepartureTimeValue != null) {
			//cl.log.info("DepartureTime -->"+ DepartureTimeValue);
	        //cl.ActualTestDataValue = "Departure Time";
	    	//cl.result("Verified, Departure Time= "+ DepartureTimeValue, "" , "Pass", "", 1, "VERIFY");
		}
		WebElement UnBerthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered'][1]//td[20]//div[@class='clickable']//p"));
		String UnBerthTimeValue = UnBerthTime.getText();
		System.out.println("UnBerthTimeValue-->"+UnBerthTimeValue);
		if (BerthTimeValue != null) {
			//cl.log.info("UnBerthTime -->"+ BerthTimeValue);
	        //cl.ActualTestDataValue = "UnBerth Time";
	    	//cl.result("Verified, UnBerth Time= "+ BerthTimeValue, "" , "Pass", "", 1, "VERIFY");
		}
		Date date11 = dateFormat.parse(DepartureTimeValue);
		Date date22 = dateFormat.parse(UnBerthTimeValue);
		long timeDifferenceMillis2 = Math.abs(date11.getTime() - date22.getTime());
		long hoursBetween2 = timeDifferenceMillis2 / (60 * 60 * 1000);
		long roundedHours2 = Math.round(hoursBetween2);
        // Calculate the difference in hours
        System.out.println("Difference in hours: " + roundedHours2 + " hours");
	   if (roundedHours2 == pilotOutValue) {
		   	//cl.log.info("New Pilot Out = Departure Time - Unberth time of last terminal (after deletion)"+ roundedHours2);
	        //cl.ActualTestDataValue = "Departure Time - Unberth time of last terminal";
	    	//cl.result("Verified, New Pilot Out= "+ roundedHours2, "" , "Pass", "", 1, "VERIFY");
	   }else {
		 //cl.log.info("New Pilot Out = Departure Time - Unberth time of last terminal (after deletion)"+ roundedHours2);
	        //cl.ActualTestDataValue = "Departure Time - Unberth time of last terminal";
	    	//cl.result("Verified, New Pilot Out= "+ roundedHours2, "" , "Fail", "", 1, "VERIFY");
	   }
	   // New Port Buffer = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals)
		
	   WebElement PilotIn_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		
		int pilotInText = Integer.parseInt(PilotIn.getText());
		int PilotOutText = Integer.parseInt(PilotOut.getText());
		int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
       int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
       int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
       int Shifting_AllTerminals = 0;
       int ARKS_Shifting_AllTerminals = 0;
       
       int PortBuffer = pilotInText + PilotOutText + Shifting_AllTerminals - PilotInARKSText - PilotOutARKSText - ARKS_Shifting_AllTerminals;
       
       if (bufferTimeValueText == PortBuffer) {
       	System.out.println("Verifyed_PortBufferTime_Is_Equals(bufferTimeValue)");
       	//cl.ActualTestDataValue = "Port Buffer Time";
       	//cl.result("Verifyed New Port BufferTimings are Recalculated with above Logic BeforeBufferTime "+ bufferTimeValueText + " AfterBufferTime " + PortBuffer, "", "Pass", "", 1, "Verify");
       }
       else {
       	System.out.println("Verifyed_PortBufferTime_Is_Not_Equals(bufferTimeValue)");
        //cl.ActualTestDataValue = "Port Buffer Time";
       	//cl.result("Not Verifyed New Port BufferTimings are Recalculated with above Logic BeforeBufferTime "+ bufferTimeValueText + " AfterBufferTime " + PortBuffer, "", "Fail", "", 1, "Verify");
       }
	}
		
}
