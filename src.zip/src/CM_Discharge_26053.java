import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CM_Discharge_26053 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		String VesselName = "ONE MATRIX";
		VesselClick_Search.sendKeys(VesselName);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		
		driver.findElement(By.xpath("//span[contains(text(),'Search')]")).click();
		Thread.sleep(4000);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[contains(text(), 'ONE MATRIX')]")).click();
		
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-select__dropdown-icon'])[2]")).click();
		Thread.sleep(5000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Voyage = (WebElement) driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col q-field__input--padding']"));
		Voyage.click();
		Thread.sleep(4000);
		Voyage.sendKeys("081W");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		
		WebElement VesselSummaryPage = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[1]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPage.click();
		Thread.sleep(8000);
		
		WebElement PortNameClick = driver.findElement(By.xpath("//div[@class='cm_page_port_summaries']//div[text()='SGSIN']"));
		PortNameClick.click();
		Thread.sleep(8000);
		for (int i = 0; i <3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement Center = driver.findElement(By.xpath("(//div[@class='port-detail-heading vert-line'])[2]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", Center);
		//Discharge
		WebElement DischargeClick = driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--unelevated q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--no-uppercase accordian-button'])[5]"));
		DischargeClick.click();
		Thread.sleep(3000);
		
		WebElement TotalCell = driver.findElement(By.xpath("(//div[@class='total-cell table-cell']//div)[60]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'border:3px solid yellow')", TotalCell);
		boolean totalcellValue = TotalCell.isDisplayed();
		if (totalcellValue) {
			cl.result("Verifyed Total Cell Selected", "", "Pass", "", 1, "Verify");

		} else {
			cl.result("Verifyed Total Cell Selected", "", "Fail", "", 1, "Verify");
		}
		WebElement TotalRow = driver.findElement(By.xpath("((//div[@class='pairing-allocation-table'])[19]//div[@class='row-container port-total-row'])[1]"));
		js.executeScript("arguments[0].setAttribute('style', 'border:3px solid yellow')", TotalRow);
		boolean TotalRowValue = TotalRow.isDisplayed();
		if (TotalRowValue) {
			cl.result("Verifyed Total Row Selected", "", "Pass", "", 1, "Verify");

		} else {
			cl.result("Verifyed Total Row Selected", "", "Fail", "", 1, "Verify");
		}
	}
}
