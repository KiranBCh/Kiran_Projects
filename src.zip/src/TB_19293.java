import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_19293 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("//label[@class='q-field row no-wrap items-start q-field--borderless q-select q-field--auto-height q-select--without-input q-select--without-chips q-select--single q-field--float q-field--dense q-field--readonly portName portSelect']"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(10, 150)","");
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@class=\"dayRows\"]//div[@id=\"block\"]//div[@class=\"schedule-line\" and @id=\"timingLine\"])[1]"));
		actions.click(Lane1).build().perform();
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		/*
		WebElement Drag2 = driver.findElement(By.xpath("//div[@class='timing']"));
		System.out.println(Drag2.getLocation());
		Thread.sleep(4000);
		for (int i = 0; i < 2; i++) {
			actions.clickAndHold(Drag2).moveByOffset(-10, -30).release().build().perform();
		}
		*/
	}
}
