import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SP_31270 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Schedule Publishing')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(9000);

		driver.findElement(By.xpath(
				"(//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Add service']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(
				"//th[text()=' Select Service Code ( ']/div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Add Service Codes']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[3]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//a[contains(text(), 'ANBIEN BAY')])[2]")).click();
		Thread.sleep(5000);
		boolean ChangeTerminalSettingstrue = false;
		WebElement R_button0 = driver.findElement(By.xpath("(//tr[2]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center'])[1]"));
		String staus = R_button0.getAttribute("aria-checked");
		System.out.println("Status of R_buton0 "+ staus);
		boolean R_button0_status = Boolean.parseBoolean(staus);
		
		WebElement R_button1 = driver.findElement(By.xpath("(//tr[2]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center'])[2]"));
		String staus1 = R_button1.getAttribute("aria-checked");
		System.out.println("Status of R_buton1 "+ staus1);
		boolean R_button1_status = Boolean.parseBoolean(staus1);
		
		WebElement R_button2 = driver.findElement(By.xpath("(//tr[2]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center'])[3]"));
		String staus2 = R_button2.getAttribute("aria-checked");
		System.out.println("Status of R_buton2 "+ staus2);
		boolean R_button2_status = Boolean.parseBoolean(staus2);
		
		if (R_button0_status == true) {
			R_button1.click();
			ChangeTerminalSettingstrue = true;
		}else if (R_button1_status == true){
			R_button2.click();
			ChangeTerminalSettingstrue = true;
		}
		else if (R_button2_status == true){
			R_button0.click();
			ChangeTerminalSettingstrue = true;
		}
		/*
		List<WebElement> R_button = driver.findElements(By.xpath("//tr[@class='terminal-row'][1]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center' and @role]"));
		System.out.println("Size " + R_button.size());
		for (int i = 0; i < R_button.size(); i++) {
			if(R_button.get(i).getAttribute("aria-checked").contains("true")) {
				System.out.println("Size " + i);
				R_button.get((i+1)).click();
				ChangeTerminalSettingstrue3  = R_button.get((i+1)).getAttribute("aria-checked").contains("true");
				System.out.println(ChangeTerminalSettingstrue3);	
				break;
			}
			else if(i==2)
			{
				R_button.get((i-1)).click();
				break;
			}
		}
		
		//WebElement SaveButton = driver.findElement(By.xpath("(//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row'])[3]"));
		//SaveButton.click();
		*/
		if (ChangeTerminalSettingstrue==true) {
			System.out.println("Verifyed, Changed The Subscription Settings = "+ ChangeTerminalSettingstrue);
			 //cl.ActualTestDataValue = "Subscription Settings";
        	//cl.result("Verifyed Changed The Subscription Settings "+ChangeTerminalSettingstrue3, "", "Pass", "31269", 1, "Verify");
		}
		else {
			System.out.println("Not Verifyed, changed The Subscription Settings = "+ ChangeTerminalSettingstrue);
			//cl.ActualTestDataValue = "Subscription Settings";
        	//cl.result("Not Verifyed Changed The Subscription Settings "+ChangeTerminalSettingstrue3, "", "Fail", "31269", 1, "Verify");
		}
	}
}
