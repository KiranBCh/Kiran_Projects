import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_CopyAndPaste_17223 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(3000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		AddPortName.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 120)","");
		Thread.sleep(4000);
		
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(4000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		AddPortName2.sendKeys("BDMGL");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(110, 250)","");
		Thread.sleep(4000);
		
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName3 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[3]"));
		Thread.sleep(4000);
		actions.moveToElement(AddPortName3).doubleClick().perform();
		AddPortName3.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		Thread.sleep(4000);
		WebElement element = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element);
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(2000);
        
		for (int i = 0; i <5; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		
		//UtilizationCheckBox
		driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='row-grouping']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]")).click();
		//External
		driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[1]")).click();
		//Internall
		driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[2]")).click();
		
		//ServiceRotation
		WebElement ServiceRotation = driver.findElement(By.xpath("(//td[@class='highlight row-grouping']//input[@class='q-field__input q-placeholder col'])[1]"));
		ServiceRotation.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		//Leg
		WebElement Leg = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[1]"));
		Leg.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement LegMiddle = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[2]"));
		LegMiddle.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement LegLast = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[3]"));
		LegLast.click();
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--round q-btn--actionable q-focusable q-hoverable q-btn--dense']")).click();
		Thread.sleep(5000);
		
		WebElement CopyPort = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.click(CopyPort).build().perform();
		Thread.sleep(3000);
		actions.contextClick(CopyPort).build().perform();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id='itmCopyPort']")).click();
		Thread.sleep(2000);
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(100, 300)","");
		Thread.sleep(4000);
		WebElement Lane3 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane3).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane3).build().perform();
		driver.findElement(By.xpath("//div[@id='itmPastePort']")).click();
		Thread.sleep(2000);
		
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(2000);
        
        //driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='row-grouping']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]")).click();
		//External
		WebElement internal = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[7]"));
		boolean InternalVer = internal.getAttribute("aria-checked").contains("true");
		System.out.println("InternalVer-->"+InternalVer);
		//Internall
		WebElement external = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[8]"));
		boolean ExternalVer = external.getAttribute("aria-checked").contains("true");
		System.out.println("ExternalVer-->"+ExternalVer);
		//Leg
		WebElement getLegMiddle = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']//input))[4]"));
		String leg1 = getLegMiddle.getText();
		System.out.println("leg1-->"+leg1);
		
		List<WebElement> OperationStatus = driver.findElements(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]//td[9]//div[@class='q-field__inner relative-position col self-stretch']//div[@id='ddlTerminalOperationStatuses']//span"));
		
		((JavascriptExecutor)driver).executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", OperationStatus);
		
	}
}
