import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CM_46367_calculation {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		String VesselName = "ONE MATRIX";
		VesselClick_Search.sendKeys(VesselName);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		
		driver.findElement(By.xpath("//span[contains(text(),'Search')]")).click();
		Thread.sleep(4000);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[contains(text(), 'ONE MATRIX')]")).click();
		
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-select__dropdown-icon'])[2]")).click();
		Thread.sleep(5000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Voyage = (WebElement) driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col q-field__input--padding']"));
		Voyage.click();
		Thread.sleep(4000);
		Voyage.sendKeys("081W");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		
		WebElement VesselSummaryPage = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[1]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPage.click();
		Thread.sleep(8000);
		
		WebElement PortNameClick = driver.findElement(By.xpath("//div[@class='cm_page_port_summaries']//div[text()='THLCH']"));
		PortNameClick.click();
		Thread.sleep(8000);
		
		WebElement VesselSummaryPageDF_SA = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[4]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPageDF_SA.click();
		Thread.sleep(8000);
		
		WebElement BSAU_Tues = driver.findElement(By.xpath("(//div[@class='bsa-table-row']//div[@class='cell-content']//b)[1]"));
		String BSAU_TuesValue = BSAU_Tues.getText();
		if (BSAU_TuesValue != null){
			System.out.println("BSAU_Tues-->"+BSAU_TuesValue);
			//cl.result("Verifyed TEUs= " + BSAU_TuesValue , "", "Pass", "", 1, "Verify");
		}
		else {
			System.out.println("BSAU_Tues-->"+BSAU_TuesValue);
			//cl.result("Verifyed TEUs= " + BSAU_TuesValue , "", "Fail", "", 1, "Verify");
		}
		
		WebElement BSAU_TuesPes = driver.findElement(By.xpath("(//div[@class='bsa-table-row']//div[@class='cell-content'][2])[1]"));
		String BSAU_TuesPesValue = BSAU_TuesPes.getText();
		if (BSAU_TuesPesValue != null){
			System.out.println("BSAU_Tues_Pe-->"+BSAU_TuesPesValue);
			//cl.result("Verifyed TEUS Percentage= " + BSAU_TuesPesValue , "", "Pass", "", 1, "Verify");
		}
		else {
			System.out.println("BSAU_Tues_Pe-->"+BSAU_TuesPesValue);
			//cl.result("Verifyed TEUS Percentage= " + BSAU_TuesPesValue , "", "Fail", "", 1, "Verify");
		}
		
		WebElement BSAU_Tons = driver.findElement(By.xpath("(//div[@class='bsa-table-row']//div[@class='cell-content'][1])[2]"));
		String BSAU_TonsValue = BSAU_Tons.getText();
		if (BSAU_TonsValue != null){
			System.out.println("BSAU_Tons_Pe-->"+BSAU_TonsValue);
			//cl.result("Verifyed Tons= " + BSAU_TonsValue , "", "Pass", "", 1, "Verify");
		}
		else {
			System.out.println("BSAU_Tons_Pe-->"+BSAU_TonsValue);
			//cl.result("Verifyed Tons= " + BSAU_TonsValue , "", "Fail", "", 1, "Verify");
		}
		
		WebElement BSAU_TonsPes = driver.findElement(By.xpath("(//div[@class='bsa-table-row']//div[@class='cell-content'][2])[2]"));
		String BSAU_TonsPesValue = BSAU_TonsPes.getText();
		if (BSAU_TonsPesValue != null){
			System.out.println("BSAU_TonsPesValue-->"+BSAU_TonsPesValue);
			//cl.result("Verifyed Tons Percentage= " + BSAU_TonsPesValue , "", "Pass", "", 1, "Verify");
		}
		else {
			System.out.println("BSAU_TonsPesValue-->"+BSAU_TonsPesValue);
			//cl.result("Verifyed Tons Percentage= " + BSAU_TonsPesValue , "", "Pass", "", 1, "Verify");
		}
	}
}
