import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_22148 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		AddPortName.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(2000);
        
		for (int i = 0; i <4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		
		WebElement TerminalBufferTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[17]"));
		String TerminalBufferTimeValue = TerminalBufferTime.getText();
		System.out.println("TerminalBufferTime--->"+TerminalBufferTimeValue);
		if (TerminalBufferTimeValue != null) {
            //cl.ActualTestDataValue = "Terminal Buffer Time";
    	    //cl.result("Verifyed, Terminal Buffer Time= "+ TerminalBufferTimeValue, "" , "Pass", "", 1, "VERIFY");
        }
        
		WebElement PortBufferTime = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[18])[1]"));
		String PortBufferTimeValue = PortBufferTime.getText();
		System.out.println("PortBufferTime--->"+PortBufferTimeValue);
		if (PortBufferTimeValue != null) {
            //cl.ActualTestDataValue = "Port Buffer Time";
    	    //cl.result("Verifyed, Port Buffer Time= "+ PortBufferTimeValue, "" , "Pass", "", 1, "VERIFY");
        }
        
		List<WebElement> TerminalOperationTime = driver.findElements(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[16]//input"));
		String TerminalOperationTimeValue = "";
		for(WebElement value : TerminalOperationTime) {
			if(value.getAttribute("value") != null) {				
				TerminalOperationTimeValue = value.getAttribute("value");
				break;
			}
		}
		System.out.println("TerminalOperationTime--->"+TerminalOperationTimeValue);
		if (TerminalOperationTimeValue != null) {
            //cl.ActualTestDataValue = "Terminal Operation Time";
    	    //cl.result("Verifyed, Terminal Operation Time= "+ TerminalOperationTimeValue, "" , "Pass", "", 1, "VERIFY");
        }
		WebElement TerminalStay = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[15]"));
		String TerminalStayValue = TerminalStay.getText();
		System.out.println("TerminalStay--->"+TerminalStayValue);
		if (TerminalStayValue != null) {
            //cl.ActualTestDataValue = "Terminal Stay";
    	    //cl.result("Verifyed, Terminal Stay= "+ TerminalStayValue, "" , "Pass", "", 1, "VERIFY");
        }
		WebElement PortStay = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[16])[1]"));
		String PortStayValue = PortStay.getText();
		System.out.println("PortStay--->"+PortStayValue);
		if (PortStayValue != null) {
            //cl.ActualTestDataValue = "Port Stay";
    	    //cl.result("Verifyed, Port Stay= "+ PortStayValue, "" , "Pass", "", 1, "VERIFY");
        }
		WebElement PilotIn = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td[23]"));
		String PilotInValue = PilotIn.getText();
		System.out.println("PilotIn--->"+PilotInValue);
		if (PilotInValue != null) {
            //cl.ActualTestDataValue = "PilotIn";
    	    //cl.result("Verifyed, PilotIn= "+ PilotInValue, "" , "Pass", "", 1, "VERIFY");
        }
		WebElement PilotOut = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td[25]"));
		String PilotOutValue = PilotOut.getText();
		System.out.println("PilotOut--->"+PilotOutValue);
		if (PilotOutValue != null) {
            //cl.ActualTestDataValue = "PilotOut";
    	    //cl.result("Verifyed, PilotOut= "+ PilotOutValue, "" , "Pass", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--round q-btn--actionable q-focusable q-hoverable q-btn--dense']")).click();
		
		WebElement CopyPort = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.click(CopyPort).build().perform();
		Thread.sleep(3000);
		actions.contextClick(CopyPort).build().perform();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id='itmCopyPort']")).click();
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		Thread.sleep(4000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		driver.findElement(By.xpath("//div[@id='itmPastePort']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(2000);
        
        WebElement TerminalBufferTime1 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[17])[1]"));
		String TerminalBufferTimeValue1 = TerminalBufferTime1.getText();
		System.out.println("TerminalBufferTime1--->"+TerminalBufferTimeValue1);
		if (TerminalBufferTimeValue.equals(TerminalBufferTimeValue1)) {
            //cl.ActualTestDataValue = "Terminal Buffer Time";
    	    //cl.result("Verifyed, Terminal Buffer Time= "+ TerminalBufferTimeValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "Terminal Buffer Time";
    	    //cl.result("Verifyed, Terminal Buffer Time= "+ TerminalBufferTimeValue1, "" , "Fail", "", 1, "VERIFY");
         }
		WebElement PortBufferTime1 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[18])[2]"));
		String PortBufferTimeValue1 = PortBufferTime1.getText();
		System.out.println("PortBufferTime--->"+PortBufferTimeValue1);
		if (PortBufferTimeValue.equals(PortBufferTimeValue1)) {
            //cl.ActualTestDataValue = "Port Buffer Time";
    	    //cl.result("Verifyed, Port Buffer Time= "+ PortBufferTimeValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "Port Buffer Time";
    	    //cl.result("Verifyed, Port Buffer Time= "+ PortBufferTimeValue1, "" , "Fail", "", 1, "VERIFY");
         }
        
		List<WebElement> TerminalOperationTime1 = driver.findElements(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[16]//input)[2]"));
		String TerminalOperationTimeValue1 = "";
		for(WebElement value : TerminalOperationTime1) {
			if(value.getAttribute("value") != null) {				
				TerminalOperationTimeValue1 = value.getAttribute("value");
				break;
			}
		}
		System.out.println("TerminalOperationTime1--->"+TerminalOperationTimeValue1);
		if (TerminalOperationTimeValue.equals(TerminalOperationTimeValue1)) {
            //cl.ActualTestDataValue = "Terminal Operation Time";
    	    //cl.result("Verifyed, Terminal Operation Time= "+ TerminalOperationTimeValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "Terminal Operation Time";
    	    //cl.result("Verifyed, Terminal Operation Time= "+ TerminalOperationTimeValue1, "" , "Fail", "", 1, "VERIFY");
         }
		WebElement TerminalStay1 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[15])[2]"));
		String TerminalStayValue1 = TerminalStay1.getText();
		System.out.println("TerminalStay1--->"+TerminalStayValue1);
		if (TerminalStayValue.equals(TerminalStayValue1)) {
            //cl.ActualTestDataValue = "Terminal Stay";
    	    //cl.result("Verifyed, Terminal Stay= "+ TerminalStayValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "Terminal Stay";
    	    //cl.result("Verifyed, Terminal Stay= "+ TerminalStayValue1, "" , "Fail", "", 1, "VERIFY");
        }
		WebElement PortStay1 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[16])[1]"));
		String PortStayValue1 = PortStay1.getText();
		System.out.println("PortStay--->"+PortStayValue1);
		if (PortStayValue.equals(PortStayValue1)) {
            //cl.ActualTestDataValue = "Port Stay";
    	    //cl.result("Verifyed, Port Stay= "+ PortStayValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "Port Stay";
    	    //cl.result("Verifyed, Port Stay= "+ PortStayValue1, "" , "Fail", "", 1, "VERIFY");
        }
		WebElement PilotIn1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td[23]"));
		String PilotInValue1 = PilotIn1.getText();
		System.out.println("PilotIn--->"+PilotInValue1);
		if (PilotInValue.equals(PilotInValue1)) {
            //cl.ActualTestDataValue = "PilotIn";
    	    //cl.result("Verifyed, PilotIn= "+ PilotInValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "PilotIn";
    	    //cl.result("Verifyed, PilotIn= "+ PilotInValue1, "" , "Fail", "", 1, "VERIFY");
        }
		WebElement PilotOut1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td[25]"));
		String PilotOutValue1 = PilotOut1.getText();
		System.out.println("PilotOut--->"+PilotOutValue1);
		if (PilotOutValue.equals(PilotOutValue1)) {
            //cl.ActualTestDataValue = "PilotOut";
    	    //cl.result("Verifyed, PilotOut= "+ PilotOutValue1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.ActualTestDataValue = "PilotOut";
    	    //cl.result("Verifyed, PilotOut= "+ PilotOutValue1, "" , "Fail", "", 1, "VERIFY");
        }
		System.out.println("End");
	}
}
