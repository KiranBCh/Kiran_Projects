import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class CM_Pagenation_21749 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col']"));
		VesselClick_Search.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		String VesselName = "HLS";
		VesselClick_Search.sendKeys(VesselName);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Search= driver.findElement(By.xpath("//span[contains(text(),'Search')]"));
		Search.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Search);
		Thread.sleep(6000);
		driver.navigate().refresh();
		Thread.sleep(8000);
		Thread.sleep(6000);
		Thread.sleep(6000);
		List<WebElement> listofVessels = driver.findElements(By.xpath("//div[@class='vessel_item_row']"));
		Thread.sleep(6000);
		Thread.sleep(4000);
		int listofVesselssize = listofVessels.size();
		System.out.println("Default Size of Vessels-->"+ listofVesselssize);
		Thread.sleep(4000);
		WebElement minimumsize = driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle bg-white text-primary q-btn--actionable q-focusable q-hoverable q-btn--dense'])[1]"));
		minimumsize.click();
		Thread.sleep(4000);
		Thread.sleep(4000);
		List<WebElement> listofVessels2 = driver.findElements(By.xpath("//div[@class='vessel_item_row']"));
		Thread.sleep(4000);
		Thread.sleep(4000);
		int listofVesselssize2 = listofVessels2.size();
		System.out.println("Default Size of Vessels2-->"+ listofVesselssize2);
		
		List<WebElement> sizeofrows = driver.findElements(By.xpath("//div[@class='q-pagination__middle row justify-center']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle text-primary q-btn--actionable q-focusable q-hoverable']"));
		System.out.println("TotalRows in Page--->"+sizeofrows.size());
		for (int i = 0; i < sizeofrows.size(); i++) {
			sizeofrows.get(i).click();
			Thread.sleep(4000);
			Thread.sleep(4000);
			List<WebElement> listofVessel = driver.findElements(By.xpath("//div[@class='vessel_item_row']"));
			Thread.sleep(4000);
			Thread.sleep(4000);
			System.out.println("InnerLoop-->"+ listofVessel.size());
			if (listofVessel.size() !=0){
	              //cl.ActualTestDataValue = "Navigate to Minimum Size of Pages";
	        	  //cl.result("Verifyed Minimum Size of Pages= "+listofVessel.size(), "", "Pass", "", 1, "VERIFY");
	        }else {
	        	 //cl.ActualTestDataValue = "Navigate to Minimum Size of Pages";
	        	  //cl.result("Verifyed Minimum Size of Pages= "+listofVessel.size(), "", "Fail", "", 1, "VERIFY");
	         }
		}
		
		List<WebElement> sizeofrowsback = driver.findElements(By.xpath("//div[@class='q-pagination__middle row justify-center']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle text-primary q-btn--actionable q-focusable q-hoverable']"));
		System.out.println("TotalRows in Page Back--->"+sizeofrowsback.size());
		for (int i = sizeofrowsback.size() - 1; i >= 0; i--) {
			sizeofrowsback.get(i).click();
			Thread.sleep(4000);
			Thread.sleep(4000);
			List<WebElement> listofVessel = driver.findElements(By.xpath("//div[@class='vessel_item_row']"));
			Thread.sleep(4000);
			Thread.sleep(4000);
			System.out.println("InnerLoop-->"+ listofVessel.size());
			if (listofVessel.size() !=0){
	              //cl.ActualTestDataValue = "Navigate to Minimum Size of Pages to Back";
	        	  //cl.result("Verifyed Minimum Size of Pages to Back= "+listofVessel.size(), "", "Pass", "", 1, "VERIFY");
	        }else {
	        	 //cl.ActualTestDataValue = "Navigate to Minimum Size of Pages to Back";
	        	  //cl.result("Verifyed Minimum Size of Pages to Back= "+listofVessel.size(), "", "Fail", "", 1, "VERIFY");
	         }
		}
		WebElement PageSizeMax = driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle bg-white text-primary q-btn--actionable q-focusable q-hoverable q-btn--dense'])[3]"));
		PageSizeMax.click();
		Thread.sleep(4000);
		Thread.sleep(4000);
		List<WebElement> maxforward = driver.findElements(By.xpath("//div[@class='q-pagination__middle row justify-center']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle text-primary q-btn--actionable q-focusable q-hoverable']"));
		System.out.println("TotalRows in Page Max Forward--->"+maxforward.size());
		for (int i = 0; i < maxforward.size(); i++) {
			maxforward.get(i).click();
			Thread.sleep(4000);
			Thread.sleep(4000);
			List<WebElement> listofVesselmax = driver.findElements(By.xpath("//div[@class='vessel_item_row']"));
			Thread.sleep(4000);
			Thread.sleep(4000);
			System.out.println("InnerLoop-->"+ listofVesselmax.size());
			if (listofVesselmax.size() !=0){
	              //cl.ActualTestDataValue = "Navigate to Maximum Size of Pages";
	        	  //cl.result("Verifyed Maximum Size of Pages to Back= "+listofVesselmax.size(), "", "Pass", "", 1, "VERIFY");
	        }else {
	        	//cl.ActualTestDataValue = "Navigate to Maximum Size of Pages";
	        	  //cl.result("Verifyed Maximum Size of Pages to Back= "+listofVesselmax.size(), "", "Fail", "", 1, "VERIFY");
	         }
		}
		
		List<WebElement> maxforwardback = driver.findElements(By.xpath("//div[@class='q-pagination__middle row justify-center']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle text-primary q-btn--actionable q-focusable q-hoverable']"));
		System.out.println("TotalRows in Page Max Back--->"+maxforwardback.size());
		for (int i = maxforwardback.size() - 1; i >= 0; i--) {
			maxforwardback.get(i).click();
			Thread.sleep(4000);
			Thread.sleep(4000);
			List<WebElement> listofVesselmaxback = driver.findElements(By.xpath("//div[@class='vessel_item_row']"));
			Thread.sleep(4000);
			Thread.sleep(4000);
			System.out.println("InnerLoop-->"+ listofVesselmaxback.size());
			if (listofVesselmaxback.size() !=0){
	              //cl.ActualTestDataValue = "Navigate to Maximum Size of Pages to Back";
	        	  //cl.result("Verifyed Maximum Size of Pages to Back= "+listofVesselmaxback.size(), "", "Pass", "", 1, "VERIFY");
	        }else {
	        	//cl.ActualTestDataValue = "Navigate to Maximum Size of Pages to Back";
	        	  //cl.result("Verifyed Maximum Size of Pages to Back= "+listofVesselmaxback.size(), "", "Fail", "", 1, "VERIFY");
	         }
		}
		
	}
}
