import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_17210_calculation {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(2000);
        Actions actions = new Actions(driver);
		Robot robot = new Robot();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        for (int i = 0; i <5; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
        driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(3000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("AEJEA");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement SelectTerminal = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy']"));
		SelectTerminal.click();
		
		WebElement DeleteTerminal = driver.findElement(By.xpath("//div[@class='left_side']//button[@id='btnDelete']"));
		DeleteTerminal.click();
		
		boolean DeleteTermianlVerfication = DeleteTerminal.isDisplayed();
		if (DeleteTermianlVerfication) {
			System.out.println("DeleteTermianl--->"+DeleteTermianlVerfication);
            //cl.ActualTestDataValue = "Terminal Delete";
    	    //cl.result("Verifyed, Terminal Deleted= "+ DeleteTermianlVerfication, "" , "Pass", "", 1, "VERIFY");
        }
        else {
        	//cl.ActualTestDataValue = "Terminal Delete";
    	    //cl.result("Verifyed, Terminal Deleted= "+ DeleteTermianlVerfication, "" , "Fail", "", 1, "VERIFY");
        }
        
		WebElement SelectPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectPort.click();
		
		WebElement AddTerminal = driver.findElement(By.xpath("//button[@id='btnAddTerminal']"));
		AddTerminal.click();
		
		WebElement UnSelectPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row selected-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		UnSelectPort.click();
		
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		int pilotInText = Integer.parseInt(PilotIn.getText());
		System.out.println("PilotIn-->"+pilotInText);
		
		//Berth Time of new terminal = Arrival Time + Pilot In
		WebElement BirthTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='clickable'])[1]"));
        String BirthTimeValue = BirthTime.getText();
        js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", BirthTime);
		WebElement ArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p"));
		String ArrivalTimeValue = ArrivalTime.getText();
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ArrivalTime);
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
		Date date1 = dateFormat.parse(ArrivalTimeValue);
		Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(Calendar.HOUR_OF_DAY, pilotInText);
        Date newDate = calendar.getTime();
        String result = dateFormat.format(newDate);
        System.out.println("Berth Time--->"+result);
        if (BirthTimeValue.equals(result)) {
        	System.out.println("2.BerthTime Calculate in hours: " + result + " result");
		   	//cl.log.info("New Berth Time of new terminal = new Arrival Time + Pilot In -->"+ result);
	        //cl.ActualTestDataValue = "new Berth Time of new Terminal ";
	    	//cl.result("Verified, New Arrival Time = "+ ArrivalTimeValue + " Pilot In= " + pilotInText+ " BirthTime= "+BirthTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Berth Time of new terminal = new Arrival Time + Pilot In -->"+ result);
		   //cl.ActualTestDataValue = "new Berth Time of new Terminal ";
	    	//cl.result("Verified, New Arrival Time = "+ ArrivalTimeValue + " Pilot In= " + pilotInText+ " BirthTime= "+BirthTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
        //Unberth Time of new terminal = Berth Time of new terminal + Terminal Stay of new terminal
        WebElement TerminalStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[15]"));
        String TerminalStayText = TerminalStay.getText();
        int TerminalStayValue = Integer.parseInt(TerminalStayText);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", TerminalStay);
        WebElement UnBirthTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[20]//div[@class='clickable'])[1]"));
        String UnBirthTimeValue = UnBirthTime.getText();
        Date date3 = dateFormat.parse(BirthTimeValue);
        calendar.setTime(date3);
        calendar.add(Calendar.HOUR_OF_DAY, TerminalStayValue);
        Date newDate3 = calendar.getTime();
        String result3 = dateFormat.format(newDate3);
        if (UnBirthTimeValue.equals(result3)) {
        	System.out.println("3.UnBerthTime Calculate in hours: " + result3 + " result");
		   	//cl.log.info("New Unberth Time of new terminal = new Berth Time + Terminal Stay -->"+ result3);
	        //cl.ActualTestDataValue = "new Berth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue + " Terminal Stay= " + TerminalStayText+ " UnBirth Time= "+UnBirthTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Unberth Time of new terminal = new Berth Time + Terminal Stay -->"+ result3);
	        //cl.ActualTestDataValue = "new Berth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue + " Terminal Stay= " + TerminalStayText+ " UnBirth Time= "+UnBirthTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
       // Pilot Out = Departure Time - Unberth Time
        WebElement DepartureTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[22]//div[@class='clickable']//p"));
		String DepartureTimeValue = DepartureTime.getText();
		Thread.sleep(3000);
		WebElement PilotOut = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td[25]"));
		String PilotOutValue = PilotOut.getText();
		long PilotOutValue1 = Long.parseLong(PilotOutValue);
		System.out.println("PilotOut-->"+ PilotOutValue);
		Date date01 = dateFormat.parse(DepartureTimeValue);
		Date date02 = dateFormat.parse(UnBirthTimeValue);
		long timeDifferenceMillis = Math.abs(date01.getTime() - date02.getTime());
		long hoursBetween = timeDifferenceMillis / (60 * 60 * 1000);
		long roundedHours = Math.round(hoursBetween);
        if (PilotOutValue1 == roundedHours) {
        	System.out.println("Departure Time - Unberth Time" + roundedHours + " hours");
		   	//cl.log.info("Pilot Out = Departure Time - Unberth Time -->"+ roundedHours);
	        //cl.ActualTestDataValue = "Pilot Out";
	    	//cl.result("Verified, Departure Time = "+ DepartureTimeValue + " UnBirth Time= "+UnBirthTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   //cl.log.info("Pilot Out = Departure Time - Unberth Time -->"+ roundedHours);
	        //cl.ActualTestDataValue = "Pilot Out";
	    	//cl.result("Verified, Departure Time = "+ DepartureTimeValue + " UnBirth Time= "+UnBirthTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
        Thread.sleep(2000);
        WebElement SelectPort2 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectPort2.click();
		
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		Thread.sleep(2000);
		WebElement UnSelectPort2 = driver.findElement(By.xpath("//tr[@class='data-table__port-row selected-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		UnSelectPort2.click();
		Thread.sleep(2000);
		WebElement AddTerminal2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]//div[@class='highlight data-table__sub-td']//input"));
		AddTerminal2.click();		
		Thread.sleep(3000);
		AddTerminal2.sendKeys("JA4");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		//Assign Shifting Timing of new terminal = 1h
		//Berth Time of new terminal = Unberth time of previous terminal + Shifting Timing of new terminal
		WebElement ShiftingTime = driver
				.findElement(By.xpath("//th[normalize-space()='Shifting Time']//following::tr[3]//td[26]"));
		int ShiftingTimeValue = Integer.parseInt(ShiftingTime.getText()); 
		WebElement BerthTime = driver.findElement(By.xpath(
				"//th[normalize-space()='Berth Time']//following::tr[3]//td[19]//div[@class='clickable']//p"));
		WebElement UnberthTime = driver.findElement(By.xpath(
				"//th[normalize-space()='Unberth Time']//following::tr[2]//td[20]//div[@class='clickable']//p"));
		String BerthTimeValue = BerthTime.getText();
		String UnberthTimeValue = UnberthTime.getText();
        Date date4 = dateFormat.parse(UnberthTimeValue);
        calendar.setTime(date4);
        calendar.add(Calendar.HOUR_OF_DAY, ShiftingTimeValue);
        Date newDate4 = calendar.getTime();
        String result4 = dateFormat.format(newDate4);
        System.out.println("UnberthTimeValue--->"+UnberthTimeValue);
		if (BerthTimeValue.equals(result4)) {
			System.out.println("Berth Time of new terminal = Unberth time of previous terminal + Shifting Timing of new terminal-->" + result4);
			//cl.log.info("Berth Time of new terminal = Unberth time of previous terminal + Shifting Timing of new terminal -->"+ result4);
	        //cl.ActualTestDataValue = "Berth Time of Second Terminal";
	    	//cl.result("Verified, UnBirth Time= "+UnBirthTimeValue + " Shifting Time "+ShiftingTime.getText(), "" , "Pass", "", 1, "VERIFY");
	   }else {
		   //cl.log.info("Berth Time of new terminal = Unberth time of previous terminal + Shifting Timing of new terminal -->"+ result4);
	        //cl.ActualTestDataValue = "Berth Time of Second Terminal";
	    	//cl.result("Verified, UnBirth Time= "+UnBirthTimeValue + " Shifting Time "+ShiftingTime.getText(), "" , "Fail", "", 1, "VERIFY"); 
	   }
		//Unberth Time of new terminal = Berth Time of new terminal + Terminal Stay of new terminal
		WebElement Terminal2Stay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[4]//td[15]"));
        String TerminalStay2Text = Terminal2Stay.getText();
        int TerminalStay2Text1 = Integer.parseInt(TerminalStay2Text);
        System.out.println("TerminalStay2Text1--->"+TerminalStay2Text1);
        System.out.println("BerthTimeValue--->"+BerthTimeValue);
        
        Date date5 = dateFormat.parse(BerthTimeValue);
        calendar.setTime(date5);
        calendar.add(Calendar.HOUR_OF_DAY, TerminalStay2Text1);
        Date newDate5 = calendar.getTime();
        String result5 = dateFormat.format(newDate5);
        System.out.println("result5--->"+result5);
        WebElement UnberthTime1 = driver.findElement(By.xpath(
				"//th[normalize-space()='Unberth Time']//following::tr[3]//td[20]//div[@class='clickable']//p"));
		String UnberthTimeValue1 = UnberthTime1.getText();
        if (UnberthTimeValue1.equals(result5)) {
        	System.out.println("Unberth Time of new terminal = Berth Time of new terminal + Terminal Stay of new terminal-->" + result5);
			//cl.log.info("Unberth Time of new terminal = Berth Time of new terminal + Terminal Stay of new terminal -->"+ result5);
	        //cl.ActualTestDataValue = "UnBerth Time of Second Terminal";
	    	//cl.result("Verified, Birth Time= "+BerthTimeValue + " Terminal Stay2 "+TerminalStay2Text, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   System.out.println("--->Unberth Time of new terminal = Berth Time of new terminal + Terminal Stay of new terminal-->" + result5);
		 //cl.log.info("Unberth Time of new terminal = Berth Time of new terminal + Terminal Stay of new terminal -->"+ result5);
	        //cl.ActualTestDataValue = "UnBerth Time of Second Terminal";
	    	//cl.result("Verified, Birth Time= "+BerthTimeValue + " Terminal Stay2 "+TerminalStay2Text, "" , "Fail", "", 1, "VERIFY"); 
	   }
       //new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals)
		WebElement PilotIn_ARKS = driver
				.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver
				.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver
				.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));

		//int pilotInText = Integer.parseInt(PilotIn.getText());
		int PilotOutText = Integer.parseInt(PilotOut.getText());
		int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
		int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
		int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
		int ARKS_Shifting_AllTerminals = 0;
		int PortBuffer = pilotInText + (PilotOutText) + ShiftingTimeValue - PilotInARKSText - PilotOutARKSText
				- ARKS_Shifting_AllTerminals;

		if (bufferTimeValueText == PortBuffer) {
			System.out.println("new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals)-->" + PortBuffer);
			//cl.log.info("new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals) -->"+ bufferTimeValue.getText());
	        //cl.ActualTestDataValue = "Port Buffer Of Second Terminal";
	    	//cl.result("Verified", "" , "Pass", "", 1, "VERIFY");
	   }else {
		 //cl.log.info("new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals) -->"+ bufferTimeValue.getText());
	        //cl.ActualTestDataValue = "Port Buffer Of Second Terminal";
	    	//cl.result("Verified", "" , "Fail", "", 1, "VERIFY"); 
	   }
	}
}
