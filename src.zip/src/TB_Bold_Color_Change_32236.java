import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import groovy.lang.ListWithDefault;


public class TB_Bold_Color_Change_32236 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		
		/*		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 150)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		WebElement speed = driver.findElement(By.xpath("(//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip'])[5]//input"));
	    Thread.sleep(3000);
	    String  speedColor = speed.getCssValue("color");
	    System.out.println("speedColor= " + speedColor);
	    
	    WebElement speedBold = driver.findElement(By.xpath("(//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip'])[5]//input"));
	    Thread.sleep(3000);
	    String speedBoldValue = speedBold.getCssValue("font-weight");
	    System.out.println("speedBold= " + speedBoldValue);
	    
	    WebElement speedwidth = driver.findElement(By.xpath("(//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip'])[5]//input"));
	    Thread.sleep(3000);
	    String speedwidthValue = speedwidth.getCssValue("width");
	    System.out.println("speedwidth= " + speedwidthValue);
	    
	    WebElement speedalign = driver.findElement(By.xpath("(//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip'])[5]//input"));
	    Thread.sleep(3000);
	    String speedalignValue = speedalign.getCssValue("text-align");
	    System.out.println("speedalign= " + speedalignValue);
		////////////////////////////////////////////////
	    JavascriptExecutor jse = (JavascriptExecutor) driver;
		
	    //FontAlignment
	    List<WebElement> fonts = driver.findElements(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']"));
	    int count=0;
	    int valueCount = fonts.size();
	    for (WebElement webElement : fonts) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
				count++;
			   }
		}
	    
	    List<WebElement> WeeksDays = driver.findElements(By.xpath("//div[@class='dayColumn']//div//div"));
	    int countWk=0;
	    int valueCountWk = WeeksDays.size();
	    for (WebElement webElement : WeeksDays) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
				countWk++;
			   }
		}
	    
	    List<WebElement> Weeks = driver.findElements(By.xpath("//div[@class='headerLabels']//div"));
	    int countWk1=0;
	    int valueCountWk1 = Weeks.size();
	    for (WebElement webElement : Weeks) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
				countWk1++;
			   }
		}
	  
	    List<WebElement> Weeksday = driver.findElements(By.xpath("//div[@class='weekColumn']//div//div"));
	    int countday1=0;
	    int valueCountday1 = Weeksday.size();
	    for (WebElement webElement : Weeksday) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    		countday1++;
			   }
		}
	    WebElement Heading = driver.findElement(By.xpath("//div[@class='page-title']"));
	    if (Heading.getCssValue("align-items").toLowerCase().equals("center")) {
	    	{
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Heading);
	    		
			   }
	    }
	    
	    WebElement Cascade = driver.findElement(By.xpath("//i[@class='q-icon cascade_icon']"));
	    if (Cascade.getCssValue("align-items").toLowerCase().equals("center")) {
	    	{
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Cascade);
	    		
			   }
	    }
	    
	    WebElement Schedule = driver.findElement(By.xpath("//div[@class='schedulHeaderText']"));
	    if (Schedule.getCssValue("align-items").toLowerCase().equals("center")) {
	    	{
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Schedule);
	    		
			   }
	    }
	    driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
	    Thread.sleep(3000);
	    
	    List<WebElement> ScheduleInformation = driver.findElements(By.xpath("//th[contains(@class, 'highlight')]"));
	    int countsc=0;
	    int countscVa = ScheduleInformation.size();
	    for (WebElement webElement : ScheduleInformation) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    		countsc++;
			   }
		}
	    
	    List<WebElement> ScheduleInformationrow = driver.findElements(By.xpath("//th[@scope='col']"));
	    int countscr=0;
	    int countscVar = ScheduleInformationrow.size();
	    for (WebElement webElement : ScheduleInformationrow) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    		countscr++;
			   }
		}
	    List<WebElement> ScheduleHeading = driver.findElements(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']"));
	    int countscrh=0;
	    int countscVarh = ScheduleHeading.size();
	    for (WebElement webElement : ScheduleHeading) {
	    	if(webElement.getCssValue("text-align").toLowerCase().equals("center"))
			   {
	    		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    		countscrh++;
			   }
		}
	  
	  */
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		List<WebElement> week = driver.findElements(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
		int count = 0;
		int weeksize = week.size();
		String  weekpositionValue = "";
		String  weekheightValue = "";
		String  weekwidthValue = "";
		String  weekbordercolorValue = "";
		for (WebElement webElement : week) {
			weekpositionValue = webElement.getCssValue("position");
			weekheightValue = webElement.getCssValue("height");
			weekwidthValue = webElement.getCssValue("width");
			weekbordercolorValue = webElement.getCssValue("border-color");
	    	jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    	if((weekheightValue.equals("840px"))&&(weekwidthValue.equals("42.5px"))) {
	    	count++;
	    	}
		}
		if(count==weeksize)
		{
			
		}
		/*
		WebElement weekposition = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String  weekpositionValue = weekposition.getCssValue("position");
	    System.out.println("weekposition= " + weekpositionValue);
	    
	    WebElement weekheight = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String weekheightValue = weekheight.getCssValue("height");
	    System.out.println("weekheight= " + weekheightValue);
	    
	    WebElement weekwidth = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String weekwidthValue = weekwidth.getCssValue("width");
	    System.out.println("weekwidth= " + weekwidthValue);
	    
	    WebElement weekbordercolor = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String weekbordercolorValue = weekbordercolor.getCssValue("border-color");
	    System.out.println("weekbordercolor= " + weekbordercolorValue);
	    /////
	    
	    WebElement dayposition = driver.findElement(By.xpath("//div[@class='dayColumn']//div[@class='dayBlock']"));
	    Thread.sleep(3000);
	    String  daypositionValue = dayposition.getCssValue("position");
	    System.out.println("dayposition= " + weekpositionValue);
	    
	    WebElement dayheight = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String dayheightValue = dayheight.getCssValue("height");
	    System.out.println("dayheight= " + dayheightValue);
	    
	    WebElement daywidth = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String weekwidthValue = weekwidth.getCssValue("width");
	    System.out.println("weekwidth= " + weekwidthValue);
	    */
	    
	    WebElement weekbordercolor = driver.findElement(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
	    Thread.sleep(3000);
	    String weekbordercolorValue = weekbordercolor.getCssValue("border-color");
	    System.out.println("weekbordercolor= " + weekbordercolorValue);
	    
 	}
}
