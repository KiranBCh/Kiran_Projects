import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_EDITSpeed_20666 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);

		Robot robot = new Robot();
		Thread.sleep(7000);
        driver.findElement(By.xpath("(//div[@class='schedule-btn-group']//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row'])[1]")).click();
        Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort1.click();		
		Thread.sleep(3000);
		
		Thread.sleep(3000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(4000);
		 
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		List<WebElement> SpeedText = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedTextValue = "";
		for(WebElement value : SpeedText) {
			if(value.getAttribute("value") != null) {				
				SpeedTextValue = value.getAttribute("value");
				break;
			}
		}
		
		if(SpeedTextValue != null){
        	System.out.println("Speed= " + SpeedTextValue);
        	//cl.log.info("Speed Default-->"+ SpeedTextValue);
            //cl.ActualTestDataValue = "Speed Schedule Information Page";
    	    //cl.result("Verifyed, Speed= "+ SpeedTextValue, "" , "Pass", "", 1, "VERIFY");
       }else {
    	   System.out.println("Speed= " + SpeedTextValue);
       		//cl.log.info("Speed Default-->"+ SpeedTextValue);
           //cl.ActualTestDataValue = "Speed";
   	    	//cl.result("Verifyed, Speed= "+ SpeedTextValue, "" , "Fail", "", 1, "VERIFY");
       }
		WebElement changeSpeed = driver.findElement(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		changeSpeed.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", changeSpeed);
		changeSpeed.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		Thread.sleep(3000);
		changeSpeed.sendKeys("50");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons'])[1]")).click();
		Thread.sleep(3000);
		
		WebElement Speed = driver.findElement(By.xpath("//div[@class='q-card']//input"));
		String SpeedValue = Speed.getAttribute("value");
		System.out.println("Speed= "+ SpeedValue);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Speed);
		if(SpeedValue != null){
        	System.out.println("Speed= " + SpeedValue);
        	//cl.log.info("Speed Default-->"+ SpeedValue);
            //cl.ActualTestDataValue = "Speed Gantt Chart";
    	    //cl.result("Verifyed, Speed= "+ SpeedValue, "" , "Pass", "", 1, "VERIFY");
       }else {
    	   System.out.println("Speed= " + SpeedValue);
       		//cl.log.info("Speed Default-->"+ SpeedValue);
           //cl.ActualTestDataValue = "Speed Gantt Chart";
   	    	//cl.result("Verifyed, Speed= "+ SpeedValue, "" , "Fail", "", 1, "VERIFY");
       }
		
		WebElement SpeedChangeGantt = driver.findElement(By.xpath("//div[@class='q-card']//input"));
		SpeedChangeGantt.click();
		SpeedChangeGantt.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		Thread.sleep(3000);
		SpeedChangeGantt.sendKeys("60");
		
		System.out.println("Speed= "+ SpeedValue);
		
		WebElement SpeedCha = driver.findElement(By.xpath("//div[@class='q-card']//input"));
		String SpeedChaValue = SpeedCha.getAttribute("value");
		System.out.println("Speed= "+ SpeedChaValue);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", SpeedCha);
		if(SpeedValue != null){
        	System.out.println("Speed= " + SpeedChaValue);
        	//cl.log.info("Speed Default-->"+ SpeedChaValue);
            //cl.ActualTestDataValue = "Speed Changed Gantt Chart";
    	    //cl.result("Verifyed, Speed= "+ SpeedChaValue, "" , "Pass", "", 1, "VERIFY");
       }else {
    	   System.out.println("Speed= " + SpeedValue);
       		//cl.log.info("Speed Default-->"+ SpeedValue);
           //cl.ActualTestDataValue = "Speed Gantt Chart";
   	    	//cl.result("Verifyed, Speed= "+ SpeedChaValue, "" , "Fail", "", 1, "VERIFY");
       }
	}
}
