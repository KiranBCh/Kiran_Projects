import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resize_31247 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		//Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,105)","");
		Thread.sleep(3000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		Thread.sleep(5000);
		//Resize
		Thread.sleep(5000);
		
		WebElement Drag3 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[3]"));
		System.out.println(Drag3.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag3).moveByOffset(10, 20).release().build().perform();
		
		WebElement Drag2 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[2]"));
		System.out.println(Drag2.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		//actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		
		WebElement Drag1 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[1]"));
		Thread.sleep(3000);
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		
		
		WebElement UnberthTime1terminalChange = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-unberth-010']"));
		actions.moveToElement(UnberthTime1terminalChange).doubleClick().perform();
		WebElement timeclick = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='2']"));
		actions.doubleClick(timeclick).build().perform();
		WebElement statusmsg = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg.getText());
		Thread.sleep(6000);	
		
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    
	    
	    WebElement UnberthTime2terminalChange = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-unberth-010']"));
		actions.moveToElement(UnberthTime2terminalChange).doubleClick().perform();
		WebElement timeclick2 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='20']"));
		actions.doubleClick(timeclick2).build().perform();
		WebElement statusmsg2 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg2.getText());
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    
		
	    WebElement UnberthTime3terminalChange = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-unberth-010']"));
		actions.moveToElement(UnberthTime3terminalChange).doubleClick().perform();
		WebElement timeclick3 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='5']"));
		actions.doubleClick(timeclick3).build().perform();
		WebElement statusmsg3 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg3.getText());
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
		/*
		 Error Arrival Invalid Option:Unberth time Berth.
Error Arrival Invalid Option:Unberth time Exceeds departure.
Error Arrival Invalid Option:Unberth time Berth.
		 */
	}
}
