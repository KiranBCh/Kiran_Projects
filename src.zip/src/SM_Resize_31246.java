import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resize_31246 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(3000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,105)","");
		Thread.sleep(3000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		Thread.sleep(5000);
		//Resize
		Thread.sleep(5000);
		
		WebElement Drag3 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[3]"));
		System.out.println(Drag3.getLocation());
		Thread.sleep(3000);
		
		WebElement Drag2 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[2]"));
		System.out.println(Drag2.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		
		
		WebElement Drag1 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[1]"));
		Thread.sleep(3000);
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 30).release().build().perform();
		
		WebElement berthTimeterminal2Change = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-berth-010']"));
		actions.moveToElement(berthTimeterminal2Change).doubleClick().perform();
		WebElement timeclick = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='2']"));
		actions.doubleClick(timeclick).build().perform();
		WebElement statusmsg = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg.getText());
		Thread.sleep(6000);	
		if (statusmsg.getText() !=null){
			System.out.println("Error "+statusmsg.getText());
            cl.ActualTestDataValue = "Error berth ";
	        cl.result("Verifyed Error message= "+ statusmsg.getText(), "Berth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error "+statusmsg.getText());
            cl.ActualTestDataValue = "Error Unberth ";
	        cl.result("Not Verifyed Error message= "+ statusmsg.getText(), "Berth Time" , "Fail", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
		Thread.sleep(6000);
		
		WebElement berthTimeterminal1Change1 = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[1]//div[@id='term-berth-000']"));
		actions.moveToElement(berthTimeterminal1Change1).doubleClick().perform();
		WebElement timeclick1 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='12']"));
		actions.doubleClick(timeclick1).build().perform();
		WebElement statusmsg1 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg1.getText());
		Thread.sleep(6000);
		if (statusmsg1.getText() !=null){
			System.out.println("Error "+statusmsg1.getText());
            cl.ActualTestDataValue = "Error Berth ";
	        cl.result("Verifyed Error message= "+ statusmsg1.getText(), "Berth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error "+statusmsg1.getText());
            cl.ActualTestDataValue = "Error Berth ";
	        cl.result("Not Verifyed Error message= "+ statusmsg1.getText(), "Berth Time" , "Fail", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
		Thread.sleep(6000);
		
		WebElement berthTimeterminal1Change2 = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[1]//div[@id='term-berth-000']"));
		actions.moveToElement(berthTimeterminal1Change2).doubleClick().perform();
		WebElement timeclick2 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='3']"));
		actions.doubleClick(timeclick2).build().perform();
		WebElement statusmsg2 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg2.getText());
		Thread.sleep(6000);
		if (statusmsg2.getText() !=null){
			System.out.println("Error "+statusmsg2.getText());
            cl.ActualTestDataValue = "Error Berth ";
	        cl.result("Verifyed Error message= "+ statusmsg2.getText(), "Berth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error "+statusmsg2.getText());
            cl.ActualTestDataValue = "Error Berth ";
	        cl.result("Not Verifyed Error message= "+ statusmsg2.getText(), "Berth Time" , "Fail", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
		Thread.sleep(6000);
		
		WebElement UnberthTime2terminalChange = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-unberth-010']"));
		actions.moveToElement(UnberthTime2terminalChange).doubleClick().perform();
		WebElement timeclick3 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='23']"));
		actions.doubleClick(timeclick3).build().perform();
		WebElement statusmsg3 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg3.getText());
		Thread.sleep(6000);
		if (statusmsg3.getText() !=null){
			System.out.println("Error "+statusmsg3.getText());
            cl.ActualTestDataValue = "Error UnBerth ";
	        cl.result("Verifyed Error message= "+ statusmsg3.getText(), "UnBerth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error "+statusmsg3.getText());
            cl.ActualTestDataValue = "Error UnBerth ";
	        cl.result("Not Verifyed Error message= "+ statusmsg3.getText(), "UnBerth Time" , "Fail", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    
	    WebElement UnberthTime5terminalChange = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-unberth-010']"));
		actions.moveToElement(UnberthTime5terminalChange).doubleClick().perform();
		WebElement timeclick5 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='5']"));
		actions.doubleClick(timeclick5).build().perform();
		WebElement statusmsg5 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg5.getText());
		Thread.sleep(6000);
		if (statusmsg5.getText() !=null){
			System.out.println("Error "+statusmsg5.getText());
            cl.ActualTestDataValue = "Error UnBerth ";
	        cl.result("Verifyed Error message= "+ statusmsg5.getText(), "UnBerth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error "+statusmsg5.getText());
            cl.ActualTestDataValue = "Error UnBerth ";
	        cl.result("Not Verifyed Error message= "+ statusmsg5.getText(), "UnBerth Time" , "Fail", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    /*
	    WebElement UnberthTime7terminalChange = driver.findElement(By.xpath("(//div[@class='columnbackground schedule-lane']//div[@class='terminal'])[2]//div[@id='term-unberth-010']"));
		actions.moveToElement(UnberthTime7terminalChange).doubleClick().perform();
		WebElement timeclick7 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='19']"));
		actions.doubleClick(timeclick7).build().perform();
		WebElement statusmsg7 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg7.getText());
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    */
	}
}
