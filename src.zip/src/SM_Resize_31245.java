import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resize_31245 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,105)","");
		Thread.sleep(3000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		Thread.sleep(5000);
		//Resize
		Thread.sleep(5000);
		
		WebElement Drag3 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[3]"));
		System.out.println(Drag3.getLocation());
		Thread.sleep(3000);
		
		WebElement Drag2 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[2]"));
		System.out.println(Drag2.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		
		
		WebElement Drag1 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[1]"));
		Thread.sleep(3000);
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		
		//Click on 1 Port
		
		WebElement DepartueTime1PortChange = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='0']//div[@id='port-departure-00']"));
		actions.moveToElement(DepartueTime1PortChange).doubleClick().perform();
		WebElement timeclick = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='22']"));
		actions.doubleClick(timeclick).build().perform();
		WebElement statusmsg = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		//System.out.println("Error Arrival "+statusmsg.getText());
		//String error1 = statusmsg.getText();
		if (statusmsg.getText() !=null){
			System.out.println("Error "+statusmsg.getText());
            //cl.ActualTestDataValue = "Error Arrival ";
	        //cl.result("Verifyed Error message= "+ error1, "Departure Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error " +statusmsg.getText());
            //cl.ActualTestDataValue = "Error Arrival ";
	        //cl.result("Not Verifyed Error message= "+ error1, "Departure Time" , "Fail", "", 1, "VERIFY");
        }
		
	    Thread.sleep(6000);
	    
	    driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    
		// Click on 2 Port
	    WebElement DepartureTimeChange = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='1']//div[@id='port-departure-01']"));
	    actions.doubleClick(DepartureTimeChange).build().perform();
		WebElement timeclick1 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='22']"));
		actions.doubleClick(timeclick1).build().perform();
		WebElement statusmsg1 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg1.getText());
		Thread.sleep(3000);
		//String error2 = statusmsg1.getText();
		if (statusmsg1.getText() !=null){
			System.out.println("Error "+statusmsg1.getText());
            //cl.ActualTestDataValue = "Error Departure";
	        //cl.result("Verifyed Error message= "+ error2, "Departure Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error " +statusmsg1.getText());
            //cl.ActualTestDataValue = "Error Departure ";
	        //cl.result("Not Verifyed Error message= "+ error2, "Departure Time" , "Fail", "", 1, "VERIFY");
        }
		
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
		// Click on 2 Port
		WebElement DepartureTimeChange1 = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='1']//div[@id='port-departure-01']"));
	    actions.doubleClick(DepartureTimeChange1).build().perform();
		WebElement timeclick2 = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='14']"));
		actions.doubleClick(timeclick2).build().perform();
		WebElement statusmsg2 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg2.getText());
		Thread.sleep(3000);
		if (statusmsg2.getText() != null){
			System.out.println("Error "+statusmsg2.getText());
            //cl.ActualTestDataValue = "Error Departure";
	        //cl.result("Verifyed Error message= "+ error3, "Departure Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Error " +statusmsg2.getText());
            //cl.ActualTestDataValue = "Error Departure ";
	        //cl.result("Not Verifyed Error message= "+ error3, "Departure Time" , "Fail", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    
	    //Error Arrival Invalid Option:Departure time Exceeds Arrival.
	    //Error Arrival Invalid Option:Departure time Exceeds Arrival.
	    //Error Arrival Invalid Option:Departure time Exceeds unberth.
	}
}
