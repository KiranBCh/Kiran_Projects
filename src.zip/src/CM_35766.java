import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CM_35766 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);
 
		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]")).click();
		Thread.sleep(9000);
		
		WebElement VesselClick_Search = (WebElement) driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(4000);
		//Actions actions = new Actions(driver);
		Robot robot = new Robot();
		VesselClick_Search.sendKeys("ONE MATRIX");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[contains(text(),'Search')]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span[contains(text(),'ONE MATRIX')]")).click();
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Voyage = (WebElement) driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col q-field__input--padding']"));
		Voyage.click();
		Thread.sleep(4000);
		/*
		Voyage.sendKeys("081W");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		*/
		driver.findElement(By.xpath("(//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row'])[6]")).click();
		Thread.sleep(9000);
		driver.findElement(By.xpath("//i[normalize-space()='chevron_right']")).click();
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-expansion-item__toggle-icon'])[1]")).click();
		Thread.sleep(9000);
		
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='unfold_more'])[1]")).click();
		Thread.sleep(9000);
		
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		/*
		String A = driver.findElement(By.xpath("(//div[@class='cell-content'])[22]")).getText();
		int Aa= Integer.parseInt(A);
		System.out.println(Aa);
		
		String B = driver.findElement(By.xpath("(//div[@class='cell-content'])[30]")).getText();
		int Bb= Integer.parseInt(B);
		System.out.println(Bb);
		
		String C = driver.findElement(By.xpath("(//div[@class='cell-content'])[13]")).getText();
		int Cc= Integer.parseInt(C);
		System.out.println(Cc);
		
		int d=Aa+Bb;
		if(d==Cc)
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("Fail");
		}
		*/
	}
}
