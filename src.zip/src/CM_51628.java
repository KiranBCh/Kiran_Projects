import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CM_51628 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

			ChromeDriver driver = new ChromeDriver();

			String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
			driver.get(domain_url);
			driver.manage().window().maximize();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
			Thread.sleep(3000);

			driver.findElement(By.xpath("//button[@id='next']")).click();
			Thread.sleep(9000);
			
			driver.navigate().refresh();
			Thread.sleep(9000);
			
			WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
			ClickVessel.click();
			Thread.sleep(3000);
			
			WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
			VesselClick_Search.click();
			Thread.sleep(2000);
			
			Robot robot = new Robot();
			String VesselName = "X-PRESS ALTAIR";
			VesselClick_Search.sendKeys(VesselName);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(8000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement Search= driver.findElement(By.xpath("//span[contains(text(),'Search')]"));
			Search.click();
			js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", Search);
			Thread.sleep(6000);
			
			WebElement VeseelNameenter = driver.findElement(By.xpath("//span[contains(text(), 'X-PRESS ALTAIR')]"));
			Thread.sleep(6000);
			VeseelNameenter.click();
			js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", VeseelNameenter);
			Thread.sleep(9000);
			
			WebElement dropdown = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-select__dropdown-icon'])[2]"));
			dropdown.click();
			Thread.sleep(5000);
			js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", dropdown);
			Thread.sleep(3000);
			WebElement dropdownlist = driver.findElement(By.xpath("//div[contains(@id, 'q-portal--menu')]//div[@role='listbox']"));
			js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", dropdownlist);
	}
}
