import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import groovy.lang.ListWithDefault;

public class SM_42609_PF {
	public static void main(String[] args) throws InterruptedException, AWTException {
System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch1.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("WES GESA");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		/*
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(5000);
		*/
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        /*
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        Prefix.sendKeys("HH");
        Thread.sleep(4000);
      
        WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        Suffix.sendKeys("20");
        Thread.sleep(8000);
 		*/
        driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(5000);
        Thread.sleep(5000);
        
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		List<WebElement> input = driver.findElements(By.xpath("(//div[@id='ddlPortOperationStatuses'])[1]//div//span[@class='ellipsis']"));
		int iteration = input.size();
		System.out.println("Size="+ iteration);
		for (WebElement element : input) {
            String text = element.getText();
            System.out.println("Element text: " + text);
            if (text != null) {
            	System.out.println("Default Port= " + text);
            	//cl.log.info("Default Port= " + text);
            	//cl.ActualTestDataValue = "Default Port";
            	//cl.result("Its have been Default Port.", "" , "Pass", "", 1, "VERIFY");
            } else {
            	//cl.log.info("Default Port= " + text);
            	//cl.ActualTestDataValue = "Default Port";
            	//cl.result("Its have been Default Port.", "" , "Fail", "", 1, "VERIFY");
       }
        }
		WebElement changePort = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[1]//td[@class='data-table__sticky-column_3']//input"));
		changePort.click();
		changePort.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", changePort);
		changePort.sendKeys("PAPCN");
		Thread.sleep(7000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", changePort);
		
		List<WebElement> StatusOfCanalPort = driver.findElements(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//div[@id='ddlPortOperationStatuses']//div//span[@class='ellipsis']"));
		int StatusOfCanalPortValue = input.size();
		System.out.println("Size="+ StatusOfCanalPortValue);
		for (WebElement element : StatusOfCanalPort) {
            String text = element.getText();
            System.out.println("Element text: " + text);
            if (text != null) {
            	System.out.println("Canal Port= " + text);
            	//cl.log.info("Canal Port= " + text);
            	//cl.ActualTestDataValue = "Canal Port";
            	//cl.result("Its have been Canal Port.", "" , "Pass", "", 1, "VERIFY");
            } else {
            	//cl.log.info("Canal Port= " + text);
            	//cl.ActualTestDataValue = "Canal Port";
            	//cl.result("Its have been Canal Port.", "" , "Fail", "", 1, "VERIFY");
       }
		}
	}
}