import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_46633_Calculation_Man {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(9000);
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("ALANA");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(7000);
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@class='service-lanes']//div[@class='service-lane'])[2]"));
		actions.moveToElement(Lane).build().perform();
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@class='q-item q-item-type row no-wrap q-item--clickable q-link cursor-pointer q-focusable q-hoverable item'])[2]"));
		AddPortButton.click();
		Thread.sleep(5000);
		
		WebElement draggableElement = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='timing']")); 
		String currentStyle = draggableElement.getAttribute("style");
		System.out.println(currentStyle);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		Thread.sleep(5000);
		String newValue = "200px";
		String script = "arguments[0].style.height = '" + newValue + "';";
		jsExecutor.executeScript(script, draggableElement);
		
		WebElement Colorverification = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='timing']"));
		//JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String script1 = "return window.getComputedStyle(arguments[0], ':before').getPropertyValue('background-color')";
        String FetchValue = (String) jsExecutor.executeScript(script1, Colorverification);
        System.out.println(FetchValue);
	}
}
