import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_19301 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		Thread.sleep(9000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Robot robot = new Robot();
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("BDCGP");
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddPort);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		for (int i = 0; i <= 3 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
				
		WebElement SelectTerminal = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectTerminal.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		Thread.sleep(3000);
				
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		Thread.sleep(3000);
		WebElement AddTerminalName = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='highlight data-table__sub-td']//input)[1]"));
		AddTerminalName.click();
		Thread.sleep(3000);
		AddTerminalName.sendKeys("CGP");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName);
		
		WebElement AddTerminalName2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='highlight data-table__sub-td']//input)[1]"));
		AddTerminalName2.click();
		Thread.sleep(3000);
		AddTerminalName2.sendKeys("CCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName2);
		
		WebElement AddTerminalName3 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='highlight data-table__sub-td']//input)[1]"));
		AddTerminalName3.click();
		Thread.sleep(3000);
		AddTerminalName3.sendKeys("NCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName3);
		
		WebElement UnSelectPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row selected-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		UnSelectPort.click();
		Thread.sleep(3000);
		
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Unberth Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
		
		WebElement SelectTerminal1 = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//div[@class='data-table__sub-td']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectTerminal1.click();
		Thread.sleep(3000);
		
		WebElement ChangeBirthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//td[19]//div[@class='clickable']"));
		ChangeBirthTime.click();
		Thread.sleep(3000);
		WebElement ChangeBirthT = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']//option[@value='14']"));
		ChangeBirthT.click();
		Actions actions = new Actions(driver);
		actions.moveToElement(ChangeBirthT).doubleClick().perform();
		Thread.sleep(3000);
		WebElement OutsideClick = driver.findElement(By.xpath("//th[normalize-space()='Berth Time']"));
		OutsideClick.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ChangeBirthTime);
		boolean isEnabled = ChangeBirthT.isEnabled();
		if (isEnabled) {
			System.out.println("Verify that Calendar Component opens and user able to input new BerthTime");		
			//cl.result("Verify that Calendar Component opens and user able to input new Berth time ", "", "Pass", "", 1, "Verify");
		}
		else {
			System.out.println("Not Verify that Calendar Component opens and user able to input new BerthTime");
			//cl.result("Verify that Calendar Component opens and user able to input new Berth time ", "", "Fail", "", 1, "Verify");
		}
		
		//1. New Unberth Time = new Birth Time + Terminal Stay
		
		WebElement BerthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//td[19]//div//p"));
		String BerthTimeValue = BerthTime.getText();
		
		WebElement UnBerthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//td[20]//div//p"));
		String UnBerthTimeValue = UnBerthTime.getText();
		
		WebElement TerminalStay = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//td[15]"));
		String TerminalStayValue = TerminalStay.getText();
		int TerminalStayValue1 = Integer.parseInt(TerminalStayValue);
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        // Parse the dates
		Date date1 = dateFormat.parse(BerthTimeValue);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(Calendar.HOUR_OF_DAY, TerminalStayValue1);
        Date newDate = calendar.getTime();
        String result = dateFormat.format(newDate);
        System.out.println("UnBerthTime Calculate in hours: " + result + " result");
        if (UnBerthTimeValue.equals(result)) {
		   	//cl.log.info("New Unberth Time = new Birth Time + Terminal Stay -->"+ result);
	        //cl.ActualTestDataValue = "new Birth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BerthTimeValue + " Terminal Stay= " + TerminalStayValue+ " UnBerth Time= "+UnBerthTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Unberth Time = new Birth Time + Terminal Stay -->"+ result);
	        //cl.ActualTestDataValue = "new Birth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BerthTimeValue + " Terminal Stay= " + TerminalStayValue+ " UnBerth Time= "+UnBerthTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
       //2. New Pilot In = new Berth Time - Arrival Time
       WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
       int PilotInValue = Integer.parseInt(PilotIn.getText());
       js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", PilotIn);
       WebElement ArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p"));
       String ArrivalTimeValue = ArrivalTime.getText();
       js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ArrivalTime);
       Date date11 = dateFormat.parse(ArrivalTimeValue);
		Date date22 = dateFormat.parse(BerthTimeValue);
		long timeDifferenceMillis2 = Math.abs(date22.getTime() - date11.getTime());
		long hoursBetween2 = timeDifferenceMillis2 / (60 * 60 * 1000);
		long roundedHours2 = Math.round(hoursBetween2);
       // Calculate the difference in hours
       System.out.println("Difference in hours: " + roundedHours2 + " hours");
	}
}
