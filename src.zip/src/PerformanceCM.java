import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class PerformanceCM {
	public static void main(String[] args) throws InterruptedException, AWTException, IOException {
	
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");
		String dir = "C:/Users/KiranbabuChiluvuru/eclipse-workspace/HtmlResponse/";
		//TC_34162_Validating_Collapse_Expand_ROB_Empty_Equipment_Table
		ChromeDriver driver = new ChromeDriver();
		try {
		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		WebElement userName = driver.findElement(By.xpath("//input[@id='email']"));
		userName.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		File File = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(File, new File(dir + "01111_loging.png"));
		driver.findElement(By.xpath("//button[@id='next']")).click();
		
		
		Thread.sleep(8000);
		driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]")).click();
		File File1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(File1, new File(dir + "02222_VesselClick.png"));
		
		driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']")).click();
		Thread.sleep(7000);
		
		String Vessel = "AKACIA";
		Robot robot = new Robot();
		driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']")).sendKeys(Vessel);
		Thread.sleep(8000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		File File2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(File2, new File(dir + "03333_EnterVesselName.png"));
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Search')]")).click();
		Thread.sleep(7000);
		File File8 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(File8, new File(dir + "04444_Search.png"));
		WebElement VesselClick = driver.findElement(By.xpath("//span[contains(text(),'" + Vessel + "')]"));
		Thread.sleep(2000);
		VesselClick.click();
		Thread.sleep(4000);
		File File3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(File3, new File(dir + "05555_VesselSummaryPage.png"));
		
		driver.findElement(By.xpath("(//span[contains(text(),'ROB')])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[normalize-space()='EMPTY']//preceding::div[@class='expansion-btn'])[2]")).click();
		Thread.sleep(2000);
		WebElement mtUnit=driver.findElement(By.xpath("(//div[contains(text(),'MT Units')])[1]"));
		scrollIntoView(mtUnit,driver);
		WebElement mtTeus=driver.findElement(By.xpath("(//div[contains(text(),'MT TEUs')])[1]"));
		scrollIntoView(mtTeus,driver);
		WebElement mtTons=driver.findElement(By.xpath("(//div[contains(text(),'MT Tons')])[1]"));
		scrollIntoView(mtTons,driver);
		WebElement mtTonsTeu=driver.findElement(By.xpath("(//div[contains(text(),'MT Ton/TEU')])[1]"));
		scrollIntoView(mtTonsTeu,driver);
		File File6 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(File6, new File(dir + "06666_Verification.png"));
		driver.close();
		
		}catch (Exception e) {
			System.out.println("Error Message-->"+ dir+e.toString());
			String htmlSource = driver.getPageSource();
			FileWriter fileWriter = new FileWriter(dir+"/Failed.txt", false);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.printf("%s", htmlSource);
            printWriter.close();
			File File5 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(File5, new File(dir + "FailedImg.png"));
		}
	}
	public static void HighLight(WebElement ele,WebDriver driver) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')",ele);
		}catch (Exception e) {
		}
	}
	public static void scrollIntoView(WebElement ele,WebDriver driver) {
		try {
			HighLight(ele,driver);
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'})", ele);
		}catch (Exception e) {
		}
	}
}
