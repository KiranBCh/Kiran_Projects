import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_35350_Change_PortName {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		List<WebElement> FirstPortName = driver.findElements(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		String PortNameValue = "";
		for(WebElement value : FirstPortName) {
			if(value.getAttribute("value").equals("AEAJM")) {				
				PortNameValue = value.getAttribute("value");
				break;
			}
		}
		if (PortNameValue !=null){
			System.out.println("PortName= "+ PortNameValue);
			//cl.log.info("First Port Name-->"+ PortNameValue);
            //cl.ActualTestDataValue = "First Port Name";
	        //cl.result("Port Name"+ PortNameValue, "First Port Name" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.log.info("First Port Name-->"+ PortNameValue);
            //cl.ActualTestDataValue = "First Port Name";
	        //cl.result("Port Name"+ PortNameValue, "First Port Name" , "Fail", "", 1, "VERIFY");
        }
		
		WebElement changePort = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(changePort).doubleClick().perform();
		changePort.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(7000);
		changePort.sendKeys("INHAL");
		Thread.sleep(7000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		List<WebElement> rePortName = driver.findElements(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		String rePortNameValue = "";
		for(WebElement value : rePortName) {
			if(value.getAttribute("value").equals("INHAL")) {				
				rePortNameValue = value.getAttribute("value");
				break;
			}
		}
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 120)","");
		if (rePortNameValue !=null){
			System.out.println("PortName= "+ rePortNameValue);
			//cl.log.info("First Port Name-->"+ rePortNameValue);
            //cl.ActualTestDataValue = "Change First Port Name";
	        //cl.result("Change The Port Name "+ rePortNameValue, "Change First Port Name" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.log.info("First Port Name-->"+ rePortNameValue);
            //cl.ActualTestDataValue = "Change First Port Name";
	        //cl.result("Change The Port Name "+ rePortNameValue, "Change First Port Name" , "Fail", "", 1, "VERIFY");
        }
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		AddPortName2.sendKeys("BDMGL");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		List<WebElement> AddPort2Name = driver.findElements(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		String Port2NameValue = "";
		for(WebElement value : AddPort2Name) {
			if(value.getAttribute("value").equals("BDMGL")) {				
				Port2NameValue = value.getAttribute("value");
				break;
			}
		}
		if (Port2NameValue !=null){
			System.out.println("PortName2= "+ Port2NameValue);
			//cl.log.info("Second Port Name-->"+ Port2NameValue);
            //cl.ActualTestDataValue = "Second Port Name";
	        //cl.result("Second Port Name"+ Port2NameValue, "Second Port Name" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.log.info("Second Port Name-->"+ Port2NameValue);
            //cl.ActualTestDataValue = "Second Port Name";
	        //cl.result("Second Port Name"+ Port2NameValue, "Second Port Name" , "Fail", "", 1, "VERIFY");
        }
		WebElement ChangeSecondPort = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(ChangeSecondPort).doubleClick().perform();
		ChangeSecondPort.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(7000);
		ChangeSecondPort.sendKeys("MTMLA");
		Thread.sleep(7000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		List<WebElement> rePort2Name = driver.findElements(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		String rePort2NameValue = "";
		for(WebElement value : rePort2Name) {
			if(value.getAttribute("value").equals("MTMLA")) {				
				rePort2NameValue = value.getAttribute("value");
				break;
			}
		}
		if (rePort2NameValue !=null){
			System.out.println("PortName= "+ rePort2NameValue);
			//cl.log.info("Change Second Port Name-->"+ rePort2NameValue);
            //cl.ActualTestDataValue = "Change Second Port Name";
	        //cl.result("Change The Second Port Name "+ rePort2NameValue, "Change Second Port Name" , "Pass", "", 1, "VERIFY");
        }else {
        	//cl.log.info("Change Second Port Name-->"+ rePort2NameValue);
            //cl.ActualTestDataValue = "Change Second Port Name";
	        //cl.result("Change The Second Port Name "+ rePort2NameValue, "Change Second Port Name" , "Fail", "", 1, "VERIFY");
        }
	}
}
