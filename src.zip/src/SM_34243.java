import java.awt.AWTException;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class SM_34243 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement closesidebar =driver.findElement(By.xpath("//div[@class='q-drawer__content fit scroll xpf-menubar']"));
		js.executeScript("arguments[0].setAttribute('style', 'border:4x solid yellow')", closesidebar);
		boolean closesidebarvalue = closesidebar.isEnabled();
		if (closesidebarvalue == true) {
			System.out.println("Kiran");
	        //cl.ActualTestDataValue = "Close Side Bar Verification";
	    	//cl.result("Close Side Bar Verification", "", "Pass", "", 1, "VERIFY");
		} else {
			//cl.ActualTestDataValue = "Close Side Bar Verification";
	    	//cl.result("Close Side Bar Verification", "", "Fail", "", 1, "VERIFY");
		}
		
		String display = closesidebar.getCssValue("display");
		if (display != null) {
			System.out.println("display-->"+display);
			//cl.log.info("display -->"+ display);
	        //cl.ActualTestDataValue = "Display";
	    	//cl.result("Verified, Display= "+ display, "" , "Pass", "", 1, "VERIFY");
		}
		String flexdirection = closesidebar.getCssValue("flex-direction");
		System.out.println("flexdirection= " + flexdirection);
		if (flexdirection != null) {
			//cl.log.info("flexdirection -->"+ flexdirection);
	        //cl.ActualTestDataValue = "Flex Direction";
	    	//cl.result("Verified, Flex Direction= "+ flexdirection, "" , "Pass", "", 1, "VERIFY");
		}
		String justifycontent = closesidebar.getCssValue("justify-content");
		System.out.println("justifycontent= " + justifycontent);
		if (justifycontent != null) {
			//cl.log.info("justifycontent -->"+ justifycontent);
		    //cl.ActualTestDataValue = "Justify Content";
			//cl.result("Verified, Justify Content= "+ justifycontent, "" , "Pass", "", 1, "VERIFY");
		}
		String overflowx = closesidebar.getCssValue("overflow-x");
		System.out.println("overflowx= " + overflowx);
		if (overflowx != null) {
			//cl.log.info("overflowx -->"+ overflowx);
	        //cl.ActualTestDataValue = "OverFlowx";
	    	//cl.result("Verified, OverFlowx= "+ overflowx, "" , "Pass", "", 1, "VERIFY");
		}
		String backgroundcolor = closesidebar.getCssValue("background-color");
		System.out.println("backgroundcolor= " + backgroundcolor);
		if (backgroundcolor != null) {
			//cl.log.info("backgroundcolor -->"+ backgroundcolor);
	        //cl.ActualTestDataValue = "Side Bar Background Color";
	    	//cl.result("Verified, Side Bar Background Color= "+ backgroundcolor, "" , "Pass", "", 1, "VERIFY");
		}
		String color = closesidebar.getCssValue("color");
		System.out.println("color= " + color);
		if (color != null) {
			//cl.log.info("color -->"+ color);
	        //cl.ActualTestDataValue = "Side Bar color";
	    	//cl.result("Verified, Side bar= "+ color, "" , "Pass", "", 1, "VERIFY");
		}
		String fontsize = closesidebar.getCssValue("font-size");
		System.out.println("fontsize= " + fontsize);
		if (fontsize != null) {
			//cl.log.info("fontsize -->"+ fontsize);
	        //cl.ActualTestDataValue = "Side Font Size";
	    	//cl.result("Verified, Side bar= "+ fontsize, "" , "Pass", "", 1, "VERIFY");
		}
		String fontweight = closesidebar.getCssValue("font-weight");
		System.out.println("fontweight= " + fontweight);
		if (fontweight != null) {
			//cl.log.info("fontweight -->"+ fontweight);
	        //cl.ActualTestDataValue = "Side bar fornweight";
	    	//cl.result("Verified, Side bar fornweight= "+ fontweight, "" , "Pass", "", 1, "VERIFY");
		}
		String width = closesidebar.getCssValue("width");
		System.out.println("width= " + width);
		if (width != null) {
			//cl.log.info("width -->"+ width);
	        //cl.ActualTestDataValue = "Side bar Width";
	    	//cl.result("Verified, Side bar Width= "+ width, "" , "Pass", "", 1, "VERIFY");
		}
		String height = closesidebar.getCssValue("height");
		System.out.println("height= " + height);
		if (height != null) {
			//cl.log.info("height -->"+ height);
	        //cl.ActualTestDataValue = "Side bar Height";
	    	//cl.result("Verified, Side bar Height= "+ height, "" , "Pass", "", 1, "VERIFY");
		}
		
		//open Side bar
		Actions actions = new Actions(driver);
		WebElement OpenSideBar = driver.findElement(By.xpath("(//div[@class='q-item__section column q-item__section--side justify-center q-item__section--avatar xpf-menu-item__icon'])[3]"));
		actions.moveToElement(OpenSideBar).perform();
		OpenSideBar.click();
		
		WebElement Obackgroudcolor = driver.findElement(By.xpath("//div[@class='q-list xpf-menu__top']//div[@class='q-item q-item-type row no-wrap q-item--clickable q-link cursor-pointer q-focusable q-hoverable xpf-menu-item xpf-menu-item--app xpf-app-logo']"));
		String ObackgroudcolorO = Obackgroudcolor.getCssValue("background-color");
		System.out.println("ObackgroudcolorO= " + ObackgroudcolorO);
		if (ObackgroudcolorO != null) {
			//cl.log.info("ObackgroudcolorO -->"+ ObackgroudcolorO);
	        //cl.ActualTestDataValue = "Side Bar Open Color";
	    	//cl.result("Verified, Side Bar Open Color= "+ ObackgroudcolorO, "" , "Pass", "", 1, "VERIFY");
		}
		WebElement LogoO = driver.findElement(By.xpath("//div[@class='q-list xpf-menu__top']//div//i[@class='q-icon shared-icon']"));
		String fontsizeO = LogoO.getCssValue("font-size");
		System.out.println("fontsizeO= " + fontsizeO);
		if (fontsizeO != null) {
			//cl.log.info("fontsize -->"+ fontsizeO);
	        //cl.ActualTestDataValue = "Side Bar Open Color";
	    	//cl.result("Verified, Side Bar Open Color= "+ fontsizeO, "" , "Pass", "", 1, "VERIFY");
			js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", LogoO);
		}
		
		List<WebElement> elementList = driver.findElements(By.xpath("//div[@class='q-list xpf-menu__top']//div[@class='q-item__section column q-item__section--main justify-center xpf-menu-item__label']"));
		int SizeOf = elementList.size();
		System.out.println("SizeOf-->"+SizeOf);
		for (int i = 0; i < SizeOf; i++) {
			WebElement element = elementList.get(i);
			System.out.println("Elements-->"+ element.getText());
			js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", element);
			String BridgeNamejustifycontent = element.getCssValue("justify-content");
			System.out.println("justifycontent= " + BridgeNamejustifycontent);
			if (BridgeNamejustifycontent != null) {
				//cl.log.info("fontsize -->"+ BridgeNamejustifycontent);
		        //cl.ActualTestDataValue = "Side Bar Open";
		    	//cl.result("Verified, = "+ BridgeNamejustifycontent, "" , "Pass", "", 1, "VERIFY");
			}
			String BridgeNameflexdirection = element.getCssValue("flex-direction");
			System.out.println("flexdirection= " + BridgeNameflexdirection);
			if (BridgeNameflexdirection != null) {
				//cl.log.info("flexdirection -->"+ BridgeNameflexdirection);
		        //cl.ActualTestDataValue = "Flex Direction";
		    	//cl.result("Verified, Flex Direction= "+ BridgeNameflexdirection, "" , "Pass", "", 1, "VERIFY");
			}
			String BridgeNameDisplay = element.getCssValue("display");
			System.out.println("BridgeNameDisplay= " + BridgeNameDisplay);
			if (BridgeNameDisplay != null) {
				//cl.log.info("BridgeNameDisplay -->"+ BridgeNameDisplay);
		        //cl.ActualTestDataValue = "Display";
		    	//cl.result("Verified, Display= "+ BridgeNameDisplay, "" , "Pass", "", 1, "VERIFY");
			}
			String BridgeNameboxsizing = element.getCssValue("box-sizing");
			System.out.println("BridgeNameboxsizing= " + BridgeNameboxsizing);
			if (BridgeNameboxsizing != null) {
				//cl.log.info("boxsizing -->"+ BridgeNameboxsizing);
		        //cl.ActualTestDataValue = "Box Sizing";
		    	//cl.result("Verified, Box Sizing= "+ BridgeNameboxsizing, "" , "Pass", "", 1, "VERIFY");
			}
			String BridgeNametexttransform = element.getCssValue("text-align");
			System.out.println("BridgeNametexttransform= " + BridgeNametexttransform);
			if (BridgeNametexttransform != null) {
				//cl.log.info("texttransform -->"+ BridgeNametexttransform);
		        //cl.ActualTestDataValue = "Text Align";
		    	//cl.result("Verified, Text Align= "+ BridgeNametexttransform, "" , "Pass", "", 1, "VERIFY");
			}
			String BridgeNamecolor = element.getCssValue("color");
			System.out.println("BridgeNamecolor= " + BridgeNamecolor);
			if (BridgeNamecolor != null) {
				//cl.log.info("texttransform -->"+ BridgeNamecolor);
		        //cl.ActualTestDataValue = "Color";
		    	//cl.result("Verified, Color= "+ BridgeNamecolor, "" , "Pass", "", 1, "VERIFY");
			}
		}
		
		List<WebElement> LogosList = driver.findElements(By.xpath("//i[@class='q-icon notranslate material-icons shared-icon']"));
		int SizeOfLogo = LogosList.size();
		System.out.println("Logos SizeOf-->"+SizeOfLogo);
		for (int i = 0; i < SizeOfLogo; i++) {
			WebElement element = LogosList.get(i);
			System.out.println("Elements-->"+ element.getText());
			js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", element);
			String Logofontfamily = element.getCssValue("font-family");
			System.out.println("justifycontent= " + Logofontfamily);
			if (Logofontfamily != null) {
				//cl.log.info("fontsize -->"+ Logofontfamily);
		        //cl.ActualTestDataValue = "Icons fontfamily";
		    	//cl.result("Verified, fontfamily= "+ Logofontfamily, "" , "Pass", "", 1, "VERIFY");
			}
			String Logofontweight = element.getCssValue("font-weight");
			System.out.println("flexdirection= " + Logofontweight);
			if (Logofontweight != null) {
				//cl.log.info("flexdirection -->"+ Logofontweight);
		        //cl.ActualTestDataValue = "Icons Font Weight";
		    	//cl.result("Verified, Font Weight= "+ Logofontweight, "" , "Pass", "", 1, "VERIFY");
			}
			String Logofontstyle = element.getCssValue("font-style");
			System.out.println("BridgeNameDisplay= " + Logofontstyle);
			if (Logofontstyle != null) {
				//cl.log.info("BridgeNameDisplay -->"+ Logofontstyle);
		        //cl.ActualTestDataValue = "Icons fontstyle";
		    	//cl.result("Verified, fontstyle= "+ Logofontstyle, "" , "Pass", "", 1, "VERIFY");
			}
			String Logodisplay = element.getCssValue("display");
			System.out.println("BridgeNameboxsizing= " + Logodisplay);
			if (Logodisplay != null) {
				//cl.log.info("boxsizing -->"+ Logodisplay);
		        //cl.ActualTestDataValue = "Icons display";
		    	//cl.result("Verified, Logo Display= "+ Logodisplay, "" , "Pass", "", 1, "VERIFY");
			}
			String Logotexttransform = element.getCssValue("line-height");
			System.out.println("BridgeNametexttransform= " + Logotexttransform);
			if (Logotexttransform != null) {
				//cl.log.info("texttransform -->"+ Logotexttransform);
		        //cl.ActualTestDataValue = "Icons Text Align";
		    	//cl.result("Verified, Text Align= "+ Logotexttransform, "" , "Pass", "", 1, "VERIFY");
			}
			String Logootexttransform = element.getCssValue("text-transform");
			System.out.println("BridgeNamecolor= " + Logootexttransform);
			if (Logootexttransform != null) {
				//cl.log.info("texttransform -->"+ Logootexttransform);
		        //cl.ActualTestDataValue = "Icons text transform";
		    	//cl.result("Verified, text transform= "+ Logootexttransform, "" , "Pass", "", 1, "VERIFY");
			}
			String Logoletterspacing = element.getCssValue("letter-spacing");
			System.out.println("Logoletterspacing= " + Logoletterspacing);
			if (Logoletterspacing != null) {
				//cl.log.info("texttransform -->"+ Logoletterspacing);
		        //cl.ActualTestDataValue = "Icons letterspacing";
		    	//cl.result("Verified, letterspacing= "+ Logoletterspacing, "" , "Pass", "", 1, "VERIFY");
			}
			String Logowordwrap = element.getCssValue("word-wrap");
			System.out.println("BridgeNamecolor= " + Logowordwrap);
			if (Logowordwrap != null) {
				//cl.log.info("texttransform -->"+ Logowordwrap);
		        //cl.ActualTestDataValue = "Icons wordwrap";
		    	//cl.result("Verified, wordwrap= "+ Logowordwrap, "" , "Pass", "", 1, "VERIFY");
			}
			String Logowhitespace = element.getCssValue("white-space");
			System.out.println("BridgeNamecolor= " + Logowhitespace);
			if (Logowhitespace != null) {
				//cl.log.info("texttransform -->"+ Logowhitespace);
		        //cl.ActualTestDataValue = "Icons white space";
		    	//cl.result("Verified, white space= "+ Logowhitespace, "" , "Pass", "", 1, "VERIFY");
			}
			String Logodirection = element.getCssValue("direction");
			System.out.println("Logodirection= " + Logodirection);
			if (Logodirection != null) {
				//cl.log.info("texttransform -->"+ Logodirection);
		        //cl.ActualTestDataValue = "Icons Direction";
		    	//cl.result("Verified, Direction= "+ Logodirection, "" , "Pass", "", 1, "VERIFY");
			}
		}
		WebElement OpenBarTable = driver.findElement(By.xpath("(//body[@class='desktop no-touch body--light']//div)[6]"));
		String display2 = OpenBarTable.getCssValue("display");
		if (display2 != null) {
			System.out.println("display-->"+display2);
			//cl.log.info("display -->"+ display2);
	        //cl.ActualTestDataValue = "Display";
	    	//cl.result("Verified, Display= "+ display2, "" , "Pass", "", 1, "VERIFY");
		}
		String Openflexdirection = OpenBarTable.getCssValue("flex-direction");
		System.out.println("flexdirection= " + Openflexdirection);
		if (Openflexdirection != null) {
			//cl.log.info("flexdirection -->"+ Openflexdirection);
	        //cl.ActualTestDataValue = "Flex Direction";
	    	//cl.result("Verified, Flex Direction= "+ Openflexdirection, "" , "Pass", "", 1, "VERIFY");
		}
		String Openjustifycontent = OpenBarTable.getCssValue("justify-content");
		System.out.println("justifycontent= " + Openjustifycontent);
		if (Openjustifycontent != null) {
			//cl.log.info("justifycontent -->"+ Openjustifycontent);
		    //cl.ActualTestDataValue = "Justify Content";
			//cl.result("Verified, Justify Content= "+ Openjustifycontent, "" , "Pass", "", 1, "VERIFY");
		}
		String Openoverflowx = OpenBarTable.getCssValue("overflow-x");
		System.out.println("overflowx= " + Openoverflowx);
		if (Openoverflowx != null) {
			//cl.log.info("overflowx -->"+ Openoverflowx);
	        //cl.ActualTestDataValue = "OverFlowx";
	    	//cl.result("Verified, OverFlowx= "+ Openoverflowx, "" , "Pass", "", 1, "VERIFY");
		}
		String Openbackgroundcolor = OpenBarTable.getCssValue("background-color");
		System.out.println("backgroundcolor= " + Openbackgroundcolor);
		if (Openbackgroundcolor != null) {
			//cl.log.info("backgroundcolor -->"+ Openbackgroundcolor);
	        //cl.ActualTestDataValue = "Side Bar Background Color";
	    	//cl.result("Verified, Side Bar Background Color= "+ Openbackgroundcolor, "" , "Pass", "", 1, "VERIFY");
		}
		String Opencolor = OpenBarTable.getCssValue("color");
		System.out.println("color= " + Opencolor);
		if (Opencolor != null) {
			//cl.log.info("color -->"+ Opencolor);
	        //cl.ActualTestDataValue = "Side Bar color";
	    	//cl.result("Verified, Side bar= "+ Opencolor, "" , "Pass", "", 1, "VERIFY");
		}
		String Openfontsize = OpenBarTable.getCssValue("font-size");
		System.out.println("fontsize= " + Openfontsize);
		if (Openfontsize != null) {
			//cl.log.info("fontsize -->"+ Openfontsize);
	        //cl.ActualTestDataValue = "Side Font Size";
	    	//cl.result("Verified, Side bar= "+ Openfontsize, "" , "Pass", "", 1, "VERIFY");
		}
		String Openfontweight = OpenBarTable.getCssValue("font-weight");
		System.out.println("fontweight= " + Openfontweight);
		if (Openfontweight != null) {
			//cl.log.info("fontweight -->"+ Openfontweight);
	        //cl.ActualTestDataValue = "Side bar fornweight";
	    	//cl.result("Verified, Side bar fornweight= "+ Openfontweight, "" , "Pass", "", 1, "VERIFY");
		}
		
	}
}
