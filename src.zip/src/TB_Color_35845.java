import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_Color_35845 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		WebElement BeforeCanalPortColor = driver.findElement(By.xpath("//div[@class='q-card portBlock default resizable']"));
		String BeforeCanalPortColorValue = BeforeCanalPortColor.getCssValue("background-color");
		System.out.println("CanalPortColorValue= " + BeforeCanalPortColorValue);
		 if(BeforeCanalPortColorValue !=null){
	        	//cl.log.info("Color Code Default PortColor -->"+ BeforeCanalPortColorValue);
	            //cl.ActualTestDataValue = "Color Code";
	    	    //cl.result("Verifyed, Default Port Color code is= "+ BeforeCanalPortColorValue, "" , "Pass", "", 1, "VERIFY");
	       }
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("PAPCN");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement CanalPortColor = driver.findElement(By.xpath("//div[@class='q-card portBlock canal resizable']"));
		String CanalPortColorValue = CanalPortColor.getCssValue("background-color");
		System.out.println("CanalPortColorValue= " + CanalPortColorValue);
        
        
        if(!(BeforeCanalPortColorValue.equals(CanalPortColorValue))){
        	//cl.log.info("Color Code for Canal Port-->"+ CanalPortColorValue);
            //cl.ActualTestDataValue = "Color Code";
    	    //cl.result("Verifyed, Canal Port Color code is"+ CanalPortColorValue, "" , "Pass", "", 1, "VERIFY");
       }else {
    	 //cl.log.info("Color Code for Canal Port-->"+ CanalPortColorValue);
    	   //cl.ActualTestDataValue = "Color Code";
   	       //cl.result("Verifyed, Canal Port Color code is"+ CanalPortColorValue, "" , "Fail", "", 1, "VERIFY");
       }
	}
}
