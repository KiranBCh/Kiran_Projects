import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TB_51881_51882_Delta2 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(4000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("BangaloreVessel");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'BangaloreVessel')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
		Robot robot = new Robot();
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("CAPE FLORES");
		Thread.sleep(5000);
	
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("1");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("1");
		Thread.sleep(5000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(8000);
        for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
        /*
        WebDriverWait wait = new WebDriverWait(driver, 20);
        WebElement ClearCycle = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[10]//input"));
        ClearCycle.click();
        Thread.sleep(3000);
        ClearCycle.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
        Thread.sleep(3000);
       */
        List<WebElement> cycle = driver.findElements(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[10]//input"));
        int cyclecount=cycle.size();
        //cl.log.info("cyclecount-->"+cyclecount);
        int count=0;
        int Current = 0;
        int next=0;
        System.out.println("Size-->"+cyclecount);
        System.out.println("start loop");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        for (int i = 0; i < (cyclecount-1); i++) {
        	jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", cycle.get(i));
        	System.out.println("text-->"+cycle.get(i).getAttribute("value"));
        	Current=Integer.parseInt(cycle.get(i).getAttribute("value"));
        	System.out.println("Current-->"+Current);
        	next=Integer.parseInt(cycle.get((i+1)).getAttribute("value"));
        	System.out.println("next-->"+next);
        	if(Current == (next-1)) {
        		count++;
        	}
        }
        System.out.println("end count-->"+count);
		if (cyclecount == (count-1)) {
			System.out.println("passed");
			//cl.result("Verified Cycle are increased"+ , "" , "Pass", "", 1, "VERIFY");
		}
		else {
			System.out.println("fail");
			//cl.result("Verified the Cycle are not increased", "" , "Fail", "", 1, "VERIFY");
		}
        
	}
        
}
