import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SM_49299_Delta2 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Robot robot = new Robot();
		
		driver.findElement(By.xpath("//button[@id='btnLoadExistingSchedule']")).click();
		Thread.sleep(3000);
		Thread.sleep(8000);
		driver.findElement(By.xpath("(//div[@class='q-tree__children']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense q-tree__tickbox'])[2]")).click();
		
		driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle q-btn--actionable q-focusable q-hoverable buttons-cancel']")).click();
		
		driver.findElement(By.xpath("//button[@id='btnScheduleEditing']")).click();
		Thread.sleep(7000);
		WebElement ChangePortName = driver.findElement(By.xpath("(//div[@class='service-lanes']//div[@class='service-lane'])[2]//div[@portindex='37']//div[@class='displayLabelGrid']//input"));
		ChangePortName.click();
		Thread.sleep(3000);
		ChangePortName.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		Thread.sleep(3000);
		ChangePortName.sendKeys("AEAJM");
		Thread.sleep(7000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		driver.findElement(By.xpath("//button[@id='btnScheduleMenu']")).click();
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("//div[@id='itmUploadSchedule']")).click();
		Thread.sleep(6000);
		
		WebElement Colorverification = driver.findElement(By.xpath("//div[@class='q-banner row items-center q-banner--top-padding text-white bg-red']"));
		boolean falg = Colorverification.getAttribute("class").contains("red");
	
        if(falg){
        	cl.ActualTestDataValue = "Errors verifying";
        	cl.result("Verified all Errors", "" , "Pass", "", 1, "VERIFY");
        	List<WebElement> value = driver.findElements(By.xpath("//div[@class='q-banner row items-center q-banner--top-padding text-white bg-red']//div[@class=\"q-banner__content col text-body2\"]//div"));
        	for (WebElement webElement : value) {
        		JavascriptExecutor jse = (JavascriptExecutor) driver;
        		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
			}
       }else {
    	   cl.ActualTestDataValue = "Errors verifying";
   	       cl.result("Verified all Errors", "" , "Fail", "", 1, "VERIFY");
       }
		
	}	
		
}

