import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hwpf.model.ListData;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CM_31139_31143_31144 {
	private static final String Vessel = null;

	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://thebridgeuatcapacity.x-pressfeeders.com/";//"https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		//WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		//ClickVessel.click();
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(3000);
		Robot robot = new Robot();
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(2000);
		String Vessel = "ONE MATRIX";
		VesselClick_Search.sendKeys(Vessel);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(7000);

		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Search')]")).click();
		Thread.sleep(7000);
		
		Thread.sleep(6000);
		WebElement VesselClick = driver.findElement(By.xpath("//span[contains(text(),'" + Vessel + "')]"));
		Thread.sleep(2000);
		VesselClick.click();
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		Thread.sleep(8000);
		/*
		ArrayList<String> stuff = new ArrayList<>();
	stuff.add("Load");
	stuff.add("Discharge");
	stuff.add("ROB");
	*/
		List<WebElement> PortNamesSize= driver.findElements(By.xpath("//div[@class='q-scrollarea__content absolute']//div[@class='q-scrollarea']//div[contains(@class, 'port-summary-card')]"));
		System.out.println("SizeOfPortnames= " + PortNamesSize.size());
		String OrginalTUEs="";
		String OriginalTons="";
	/*
		String clcik_stuff="";
		for(int j=0; j<stuff.size(); j++)
		{
			 clcik_stuff = stuff.get(j);
	*/
		for(int i=0; i<PortNamesSize.size();i++) {
			PortNamesSize.get(i).click();
			//System.out.println("--------------------------"+clcik_stuff+"---------------------");
			Thread.sleep(500);
			OrginalTUEs=driver.findElement(By.xpath("(//div[contains(@class,'port-summary-card')]//table[@class='port-summary-data__table'])["+(i+1)+"]//tbody//tr[1]//td[3]")).getText();
			OriginalTons=driver.findElement(By.xpath("(//div[contains(@class,'port-summary-card')]//table[@class='port-summary-data__table'])["+(i+1)+"]//tbody//tr[1]//td[4]")).getText();	
			System.out.println("value1-->"+OriginalTons);
			System.out.println("value2-->"+OriginalTons);
			try {
				//String tue_H = driver.findElement(By.xpath("(((//span[normalize-space(text())='"+clcik_stuff+"'])["+(i+1)+"]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[2]")).getText();
				//String ton_H = driver.findElement(By.xpath("(((//span[normalize-space(text())='"+clcik_stuff+"'])["+(i+1)+"]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[3]")).getText();
				String tue_H = driver.findElement(By.xpath("(((//span[normalize-space(text())='Load'])["+(i+1)+"]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[2]")).getText();
				String ton_H = driver.findElement(By.xpath("(((//span[normalize-space(text())='Load'])["+(i+1)+"]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[3]")).getText();
				System.out.println("tue_H-->"+tue_H);
				System.out.println("ton_H-->"+ton_H);

				if(OrginalTUEs.equalsIgnoreCase(tue_H) && OriginalTons.equalsIgnoreCase(ton_H) )
				{
					System.out.println("varified value and table ");
				}
				else
				{
					System.out.println("fail to verify");
				}
			}
			catch (Exception e) {
				System.out.println("table values are empty no need to varify "+"iteration-->"+i);
			}
		}
		
		//WebElement VesselNameHeading = driver.findElement(By.xpath("(//div[@class='cm_page_port_summaries']//div[@class='port-summary-header port-summary-card-planned'])[1]"));
		//VesselNameHeading.click();
		//Thread.sleep(2000);
		
		/*
		 //div[@class='port-section-with-table-repeated']//div[@class='row-container section-total-row' and contains(@style,'grid')]//div
(//span[normalize-space(text())='Load'])[1]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']
(((//span[normalize-space(text())='Load'])[1]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[2]
(((//span[normalize-space(text())='Load'])[1]/ancestor::div[@class='table-container']//div[@class='pairing-allocation-table']//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[3]
		 */
		
	/*	//LoadOriginal
		WebElement LoadOriginalTues = driver.findElement(By.xpath("//div[@class='port-summary-card-selected port-summary-card-planned-selected port-summary-card-planned port-summary']//table[@class='port-summary-data__table']//tr[1]//td[3]"));
		String LoadOriginalTuesValue = LoadOriginalTues.getText();
		System.out.println("LoadOriginalTuesValue=" + LoadOriginalTuesValue);
		WebElement LoadOriginalTons = driver.findElement(By.xpath("//div[@class='port-summary-card-selected port-summary-card-planned-selected port-summary-card-planned port-summary']//table[@class='port-summary-data__table']//tr[1]//td[4]"));
		String LoadOriginalTonsValue = LoadOriginalTons.getText();
		System.out.println("LoadOriginalTonsValue=" + LoadOriginalTonsValue);
		
		//Load
		WebElement LoadClick = driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--unelevated q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--no-uppercase accordian-button'])[1]"));
		LoadClick.click();
		Thread.sleep(3000);
		
		WebElement LoadTues = driver.findElement(By.xpath("((//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[2]"));
		String LoadTuesValue = LoadTues.getText();
		System.out.println("LoadTuesValue=" + LoadTuesValue);
		Thread.sleep(3000);
		WebElement LoadTons = driver.findElement(By.xpath("((//div[@class='row-container section-total-row'])[2]//div[@class='cell-content'])[3]"));
		String LoadTonsValue = LoadTons.getText();
		System.out.println("LoadTonsValue=" + LoadTonsValue);
		
		/*
		//DischargeOriginal
		WebElement DischargeOriginalTues = driver.findElement(By.xpath("//div[@class='port-summary-card-selected port-summary-card-planned-selected port-summary-card-planned port-summary']//table[@class='port-summary-data__table']//tr[2]//td[3]"));
		String DischargeOriginalTuesValue = DischargeOriginalTues.getText();
		System.out.println("LoadOriginalTuesValue=" + DischargeOriginalTuesValue);
		WebElement DischargeOriginalTons = driver.findElement(By.xpath("//div[@class='port-summary-card-selected port-summary-card-planned-selected port-summary-card-planned port-summary']//table[@class='port-summary-data__table']//tr[2]//td[4]"));
		String DischargeOriginalTonsValue = DischargeOriginalTons.getText();
		System.out.println("LoadOriginalTonsValue=" + DischargeOriginalTonsValue);
		//Discharge
		WebElement DischargeClick = driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--unelevated q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--no-uppercase accordian-button'])[2]"));
		DischargeClick.click();
		Thread.sleep(3000);
		WebElement DischargeTues = driver.findElement(By.xpath("(((//div[@class='equipment_info_table_layout'])[1]//div[@class='table-container'])[2]//div[@class='cell-content'])[7]"));
		String DischargeTuesValue = DischargeTues.getText();
		System.out.println("DischargeTuesValue=" + DischargeTuesValue);
		Thread.sleep(3000);
		WebElement DischargeTons = driver.findElement(By.xpath("(((//div[@class='equipment_info_table_layout'])[1]//div[@class='table-container'])[2]//div[@class='cell-content'])[8]"));
		String DischargeTonsValue = DischargeTons.getText();
		System.out.println("DischargeTonsValue=" + DischargeTonsValue);
		
		//ROBOriginal
		WebElement ROBOriginalTues = driver.findElement(By.xpath("//div[@class='port-summary-card-selected port-summary-card-planned-selected port-summary-card-planned port-summary']//table[@class='port-summary-data__table']//tr[2]//td[3]"));
		String ROBOriginalTuesValue = ROBOriginalTues.getText();
		System.out.println("ROBOriginalTuesValue=" + ROBOriginalTuesValue);
		WebElement ROBOriginalTons = driver.findElement(By.xpath("//div[@class='port-summary-card-selected port-summary-card-planned-selected port-summary-card-planned port-summary']//table[@class='port-summary-data__table']//tr[2]//td[4]"));
		String ROBOriginalTonsValue = ROBOriginalTons.getText();
		System.out.println("ROBOriginalTonsValue=" + ROBOriginalTonsValue);
		//ROB
		WebElement ROBClick = driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--unelevated q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--no-uppercase accordian-button'])[3]"));
		ROBClick.click();
		Thread.sleep(3000);
		WebElement ROBTues = driver.findElement(By.xpath("(((//div[@class='equipment_info_table_layout'])[1]//div[@class='table-container'])[3]//div[@class='cell-content'])[7]"));
		String ROBTuesValue = ROBTues.getText();
		Thread.sleep(3000);
		System.out.println("ROBTuesValue=" + ROBTuesValue);
		
		WebElement ROBTons = driver.findElement(By.xpath("(((//div[@class='equipment_info_table_layout'])[1]//div[@class='table-container'])[3]//div[@class='cell-content'])[8]"));
		String ROBTonsValue = ROBTons.getText();
		Thread.sleep(3000);
		System.out.println("ROBTonsValue=" + ROBTonsValue);
		
		if (LoadOriginalTuesValue.equals(LoadTuesValue)){
			System.out.println("Load TUEs Values" +LoadOriginalTuesValue +" " + LoadTuesValue);
            //cl.ActualTestDataValue = "Load TUEs";
	        //cl.result("Verifyed Tues "+LoadOriginalTuesValue+ " TUEs " + LoadTuesValue , "Load TUEs" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Load TUEs Values" +LoadOriginalTuesValue +" " + LoadTuesValue);
            //cl.ActualTestDataValue = "Load TUEs";
	        //cl.result("Verifyed Tues "+LoadOriginalTuesValue+ " TUEs " + LoadTuesValue , "Load TUEs" , "Fail", "", 1, "VERIFY");
        }
		if (LoadOriginalTonsValue.equals(LoadTonsValue)){
			System.out.println("Load Tons Values" +LoadOriginalTonsValue +" " + LoadTonsValue);
            //cl.ActualTestDataValue = "Load Tons ";
	        //cl.result("Verifyed Tons "+LoadOriginalTonsValue+ " Tons " + LoadTonsValue , "Load Tons" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Load Tons Values" +LoadOriginalTonsValue +" " + LoadTonsValue);
            //cl.ActualTestDataValue = "Load Tons ";
	        //cl.result("Verifyed Tons "+LoadOriginalTonsValue+ " Tons " + LoadTonsValue , "Load Tons" , "Fail", "", 1, "VERIFY");
        }
		/*
		if (DischargeOriginalTuesValue.equals(DischargeTuesValue)){
			System.out.println("Discharge TUEs Values" +DischargeOriginalTuesValue +" " + DischargeTuesValue);
            //cl.ActualTestDataValue = "Discharge TUEs";
	        //cl.result("Verifyed Tues "+DischargeOriginalTuesValue+ " TUEs " + DischargeTuesValue , "Discharge TUEs" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Discharge TUEs Values" +DischargeOriginalTuesValue +" " + DischargeTuesValue);
            //cl.ActualTestDataValue = "Discharge TUEs";
	        //cl.result("Verifyed Tues "+DischargeOriginalTuesValue+ " TUEs " + DischargeTuesValue , "Discharge TUEs" , "Fail", "", 1, "VERIFY");
        }
		if (DischargeOriginalTonsValue.equals(DischargeTonsValue)){
			System.out.println("Discharge Tons Values" +DischargeOriginalTonsValue +" " + DischargeTonsValue);
            //cl.ActualTestDataValue = "Discharge Tons ";
	        //cl.result("Verifyed Tons "+DischargeOriginalTonsValue+ " Tons " + DischargeTonsValue , "Discharge Tons" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Discharge Tons Values" +DischargeOriginalTonsValue +" " + DischargeTonsValue);
            //cl.ActualTestDataValue = "Discharge Tons ";
	        //cl.result("Verifyed Tons "+DischargeOriginalTonsValue+ " Tons " + DischargeTonsValue , "Discharge Tons" , "Fail", "", 1, "VERIFY");
        }
		
		if (ROBOriginalTuesValue.equals(ROBTuesValue)){
			System.out.println("ROB TUEs Values" +ROBOriginalTuesValue +" " + ROBTuesValue);
            //cl.ActualTestDataValue = "ROB TUEs";
	        //cl.result("Verifyed Tues "+ROBOriginalTuesValue+ " TUEs " + ROBTuesValue , "ROB TUEs" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("ROB TUEs Values" +ROBOriginalTuesValue +" " + ROBTuesValue);
            //cl.ActualTestDataValue = "ROB TUEs";
	        //cl.result("Verifyed Tues "+ROBOriginalTuesValue+ " TUEs " + ROBTuesValue , "ROB TUEs" , "Fail", "", 1, "VERIFY");
        }
		if (ROBOriginalTonsValue.equals(ROBTonsValue)){
			System.out.println("ROB Tons Values" +ROBOriginalTonsValue +" " + ROBTonsValue);
            //cl.ActualTestDataValue = "ROB Tons ";
	        //cl.result("Verifyed Tons "+ROBOriginalTonsValue+ " Tons " + ROBTonsValue , "ROB Tons" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("ROB Tons Values" +ROBOriginalTonsValue +" " + ROBTonsValue);
            //cl.ActualTestDataValue = "ROB Tons ";
	        //cl.result("Verifyed Tons "+ROBOriginalTonsValue+ " Tons " + ROBTonsValue , "ROB Tons" , "Fail", "", 1, "VERIFY");
        }
		*/
	}
}
