import java.awt.AWTException;
import java.awt.RenderingHints.Key;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SM_man_Arrival_edit_46651 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(3000);
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("ALS KRONOS");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//span[text()='GENERATE']")).click();
		Thread.sleep(2000);
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//div[@class='q-item__section column q-item__section--main justify-center'])[3]")).click();
		Thread.sleep(3000);
		
		//Arrival start
		WebElement ArrivalTime = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='0']//div[@id='port-arrival-001']"));
		actions.moveToElement(ArrivalTime).doubleClick().perform();
		Thread.sleep(4000);
		/*
	    WebElement arrivalhrs = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='5']"));
	    arrivalhrs.click();
		WebElement arrivalmins = driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']"));
		arrivalmins.click();
		*/

		WebElement ArrivalHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeArrivalHours = new Select(ArrivalHours);
	    ChangeArrivalHours.selectByValue("5");
	    Thread.sleep(2000);
	    robot.keyPress(KeyEvent.VK_TAB);
	    robot.keyRelease(KeyEvent.VK_TAB);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']")).click();
	    Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(), 'Sailing Schedule')]")).click();
		
		//Arrival Code end
		//Depa
		WebElement DepartureTime = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='0']//div[@id='port-departure-001']"));
		actions.moveToElement(DepartureTime).doubleClick().perform();
		Thread.sleep(4000);
		/*
		WebElement departurehrs = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='17']"));
		departurehrs.click();
		WebElement departuremins = driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']"));
		departuremins.click();
		*/
		WebElement DepartureHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeDepartureHours = new Select(DepartureHours);
	    ChangeDepartureHours.selectByValue("17");
	    Thread.sleep(2000);
	    robot.keyPress(KeyEvent.VK_TAB);
	    robot.keyRelease(KeyEvent.VK_TAB);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']")).click();
	    Thread.sleep(2000);
	    
		driver.findElement(By.xpath("//div[contains(text(), 'Sailing Schedule')]")).click();
		//Depa Code end
		
		Thread.sleep(4000);
		// Berth Start
		WebElement BerthTime = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='terminal']//div[@id='term-berth-0001']"));
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String doubleClickScript = "var element = arguments[0];" +
                "var mouseEvent = document.createEvent('MouseEvents');" +
                "mouseEvent.initEvent('dblclick', true, true);" +
                "element.dispatchEvent(mouseEvent);";
        jsExecutor.executeScript(doubleClickScript, BerthTime);
		Thread.sleep(4000);
		/*
		WebElement berthhrs = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='4']"));
		berthhrs.click();
		WebElement berthmins = driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']"));
		berthmins.click();
		*/
		WebElement BerthHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeBerthHours = new Select(BerthHours);
	    ChangeBerthHours.selectByValue("4");
	    Thread.sleep(2000);
	    robot.keyPress(KeyEvent.VK_TAB);
	    robot.keyRelease(KeyEvent.VK_TAB);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']")).click();
	    Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(), 'Sailing Schedule')]")).click();
		// Berth Code end
		//Unberth Start
		WebElement UnberthTime = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='terminal']//div[@id='term-unberth-0001']"));
		//actions.moveToElement(UnberthTime).doubleClick().perform();
        String doubleClickScripTt = "var element = arguments[0];" +
                "var mouseEvent = document.createEvent('MouseEvents');" +
                "mouseEvent.initEvent('dblclick', true, true);" +
                "element.dispatchEvent(mouseEvent);";
        jsExecutor.executeScript(doubleClickScripTt, UnberthTime);
		Thread.sleep(4000);
		/*
		WebElement unberthhrs = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='14']"));
		unberthhrs.click();
		WebElement unberthmins = driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']"));
		unberthmins.click();
		*/
		WebElement UnBerthHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeUnBerthHours = new Select(UnBerthHours);
	    ChangeUnBerthHours.selectByValue("14");
	    Thread.sleep(2000);
	    robot.keyPress(KeyEvent.VK_TAB);
	    robot.keyRelease(KeyEvent.VK_TAB);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//select[@id='gantt-min']//option[@value='30']")).click();
	    Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(), 'Sailing Schedule')]")).click();
		//Unberth Code end
		
	}
}
