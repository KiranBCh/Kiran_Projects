import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_19295 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(2000);
        Actions actions = new Actions(driver);
		Robot robot = new Robot();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        for (int i = 0; i <5; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
        driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(3000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement PilotIn_ARKS = driver
				.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver
				.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver
				.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		System.out.println("PilotIn-->"+PilotIn.getText());
		int pilotInText = Integer.parseInt(PilotIn.getText());
		WebElement PilotOut = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td[25]"));
		
		int PilotOutText = Integer.parseInt(PilotOut.getText());
		int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
		int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
		int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
		int ARKS_Shifting_AllTerminals = 0;
		int ShiftingTimeValue = 0;
		int PortBuffer = pilotInText + (PilotOutText) + ShiftingTimeValue - PilotInARKSText - PilotOutARKSText
				- ARKS_Shifting_AllTerminals;

		if (bufferTimeValueText == PortBuffer) {
			System.out.println("new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals)-->" + PortBuffer);
			//cl.log.info("new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals) -->"+ bufferTimeValue.getText());
	        //cl.ActualTestDataValue = "Port Buffer Of Second Terminal";
	    	//cl.result("Verified", "" , "Pass", "", 1, "VERIFY");
	   }else {
		 //cl.log.info("new Port Buffer (hours) = Pilot In + Pilot Out + Shifting (all terminals) - ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals) -->"+ bufferTimeValue.getText());
	        //cl.ActualTestDataValue = "Port Buffer Of Second Terminal";
	    	//cl.result("Verified", "" , "Fail", "", 1, "VERIFY"); 
	   }
		WebElement BufferTime = driver
				.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[3]//td[17]"));
		int BufferTimeValue = Integer.parseInt(BufferTime.getText());
		WebElement TerminalStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[15]"));       
        WebElement TerminalOperation = driver.findElement(By.xpath(
				"//th[normalize-space()='Operation Time']//following::tr[3]//td[16]//label//div//input[@class='q-field__native q-placeholder text-center']"));

		int TerminalStayText = Integer.parseInt(TerminalStay.getText());
		int TerminalOperationText = Integer.parseInt(TerminalOperation.getAttribute("value"));
		int TerminalBufferHours = TerminalStayText - TerminalOperationText;
		if (BufferTimeValue == TerminalBufferHours) {
			System.out.println("TerminalBufferHours-->"+TerminalBufferHours);
			//cl.ActualTestDataValue = "Terminal Buffer hrs";
	    	//cl.result("Verified Terminal Buffer Times "+BufferTimeValue +" TerminalBufferHours "+TerminalBufferHours, "" , "Pass", "", 1, "VERIFY");
		} else {
			System.out.println("TerminalBufferHours-->"+TerminalBufferHours);
			//cl.ActualTestDataValue = "Terminal Buffer hrs";
	    	//cl.result("Verified Terminal Buffer Times "+BufferTimeValue +" TerminalBufferHours "+TerminalBufferHours, "" , "Fail", "", 1, "VERIFY"); 
		}
		/*
		WebElement PortTerminal = driver.findElement(By.xpath("(//div[@class='q-pa-md']//tr//td)[1]"));
		boolean PortTerminalValue = PortTerminal.isDisplayed();
		if (PortTerminalValue) {
			System.out.println("PortTerminalValue-->"+PortTerminalValue);
			//cl.ActualTestDataValue = "Port and Terminal Displayed";
	    	//cl.result("Verified", "" , "Pass", "", 1, "VERIFY");
		} else {
			//cl.ActualTestDataValue = "Port and Terminal Displayed";
	    	//cl.result("Verified", "" , "Fail", "", 1, "VERIFY"); 
		}
		WebElement Leg = driver.findElement(By.xpath("(//div[@class='q-pa-md']//tr//td)[2]"));
		boolean LegValue = Leg.isDisplayed();
		if (LegValue) {
			System.out.println("LegValue-->"+LegValue);
			//cl.ActualTestDataValue = "Leg";
	    	//cl.result("Verified", "" , "Pass", "", 1, "VERIFY");
		} else {
			//cl.ActualTestDataValue = "Leg";
	    	//cl.result("Verified", "" , "Pass", "", 1, "VERIFY"); 
		}*/
	}
}
