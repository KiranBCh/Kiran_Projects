import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TB_15090 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		Thread.sleep(9000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Robot robot = new Robot();
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("AEAJM");
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", AddPort);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		for (int i = 0; i <= 3 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement TotalRowVerification = driver.findElement(By.xpath("//tr[contains(@style, 'bottom') and contains(@style, 'font-weight')]"));
		js.executeScript("arguments[0].setAttribute('style', 'border:4x solid yellow')", TotalRowVerification);
		boolean TotalRow = TotalRowVerification.isEnabled();//TotalRowVerification.getAttribute("style").contains("font-weight");
		if (TotalRow == true) {
			System.out.println("TotalRow= " + TotalRow);
			//cl.log.info("TotalRow -->"+ TotalRow);
	        //cl.ActualTestDataValue = "Total Row Verification";
	    	//cl.result("Yes, it has been verified. In Testbed, the total row is enabled., "" , "Pass", "", 1, "VERIFY");
		} else {
			//cl.log.info("TotalRow -->"+ TotalRow);
	        //cl.ActualTestDataValue = "Total Row Verification";
	    	//cl.result("Yes, it has been verified. In Testbed, the total row is enabled., "" , "Fail", "", 1, "VERIFY");
		}
		WebElement TableLayout = driver.findElement(By.xpath("//table[@class='data-table']"));
		String marginright = TableLayout.getCssValue("margin-right");
		//System.out.println("marginright= " + marginright);
		if (marginright != null) {
			//cl.log.info("marginright -->"+ marginright);
	        //cl.ActualTestDataValue = "Table Margin Right";
	    	//cl.result("Verified, Table Margin Right= "+ marginright, "" , "Pass", "", 1, "VERIFY");
		}
		String maxheight = TableLayout.getCssValue("max-height");
		System.out.println("maxheight= " + maxheight);
		if (maxheight != null) {
			//cl.log.info("maxheight -->"+ maxheight);
	        //cl.ActualTestDataValue = "Table Max Height";
	    	//cl.result("Verified, Table Max Height= "+ maxheight, "" , "Pass", "", 1, "VERIFY");
		}
		String tablelayout = TableLayout.getCssValue("table-layout");
		System.out.println("tablelayout= " + tablelayout);
		if (tablelayout != null) {
			//cl.log.info("tablelayout -->"+ tablelayout);
		    //cl.ActualTestDataValue = "Table Layout";
			//cl.result("Verified, Table Layout= "+ tablelayout, "" , "Pass", "", 1, "VERIFY");
		}
		String wordbreak = TableLayout.getCssValue("word-break");
		System.out.println("wordbreak= " + wordbreak);
		if (wordbreak != null) {
			//cl.log.info("wordbreak -->"+ wordbreak);
	        //cl.ActualTestDataValue = "Table Word Break";
	    	//cl.result("Verified, Table Word Break= "+ wordbreak, "" , "Pass", "", 1, "VERIFY");
		}
		String backgroundcolor = TableLayout.getCssValue("background-color");
		System.out.println("backgroundcolor= " + backgroundcolor);
		if (backgroundcolor != null) {
			//cl.log.info("backgroundcolor -->"+ backgroundcolor);
	        //cl.ActualTestDataValue = "Table Background Color";
	    	//cl.result("Verified, Table Background Color= "+ backgroundcolor, "" , "Pass", "", 1, "VERIFY");
		}
		String fontfamily = TableLayout.getCssValue("font-family");
		System.out.println("fontfamily= " + fontfamily);
		if (fontfamily != null) {
			//cl.log.info("fontfamily -->"+ fontfamily);
	        //cl.ActualTestDataValue = "Total Font Family";
	    	//cl.result("Verified, Table Font Family= "+ fontfamily, "" , "Pass", "", 1, "VERIFY");
		}
		String textalign = TableLayout.getCssValue("text-align");
		System.out.println("textalign= " + textalign);
		if (textalign != null) {
			//cl.log.info("textalign -->"+ textalign);
	        //cl.ActualTestDataValue = "Total Text Align";
	    	//cl.result("Verified, Table Text Align= "+ textalign, "" , "Pass", "", 1, "VERIFY");
		}
		String border = TableLayout.getCssValue("border");
		System.out.println("border= " + border);
		if (border != null) {
			//cl.log.info("border -->"+ border);
	        //cl.ActualTestDataValue = "Total Border";
	    	//cl.result("Verified, Table Border= "+ border, "" , "Pass", "", 1, "VERIFY");
		}
		String fontweight = TableLayout.getCssValue("font-weight");
		System.out.println("fontweight= " + fontweight);
		if (fontweight != null) {
			//cl.log.info("fontweight -->"+ fontweight);
	        //cl.ActualTestDataValue = "Total Font Weight";
	    	//cl.result("Verified, Table Font Weight= "+ fontweight, "" , "Pass", "", 1, "VERIFY");
		}
		String borderspacing = TableLayout.getCssValue("border-spacing");
		System.out.println("borderspacing= " + borderspacing);
		if (borderspacing != null) {
			//cl.log.info("borderspacing -->"+ borderspacing);
	        //cl.ActualTestDataValue = "Total Border Spacing";
	    	//cl.result("Verified, Table Border Spacing= "+ borderspacing, "" , "Pass", "", 1, "VERIFY");
		}
		
	}
}
