import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Twine_CM {
public static void main(String[] args) throws Throwable{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://dev01twinesitstapp.z23.web.core.windows.net/");
 
		driver.manage().window().maximize();
		Thread.sleep(7000);
		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
	    Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		Thread.sleep(3000);
		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");	

 
		Thread.sleep(3000);
		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
 
		Thread.sleep(6000);
		driver.navigate().refresh();
		Thread.sleep(5000);
		Actions actions = new Actions(driver);
		Thread.sleep(9000);
		WebElement srearchbox = driver.findElement(By.xpath("//i[normalize-space()='search']"));
		Thread.sleep(9000);
		actions.moveToElement(srearchbox).perform();
		srearchbox.click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("(//div[@class='subtitle-container'])[1]")).click();
		Thread.sleep(9000);
        WebElement searchboxEnter = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
        //ssearchboxEnter.click();
        searchboxEnter.sendKeys("A LA MARINE");
        Thread.sleep(3000);
        //searchboxEnter.click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//div[@class='q-option-header']")).click();
        Thread.sleep(3000);
    	driver.findElement(By.xpath("//input[@placeholder='Search external voyage number']")).sendKeys("02W");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@data-test-id='SS-Apply-Button-id']")).click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("(//span[text()=' View Load Summary '])[1]")).click();
		
		
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, 190);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='el-loading-mask is-fullscreen']")));
		
		//Function start
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("document.body.style.zoom='70%'");
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='el-loading-mask is-fullscreen']")));
		Thread.sleep(17000);
		driver.findElement(By.xpath("//button[@data-test-id='BS-Add-Row-Button-id']")).click();
		

		WebElement orders = driver.findElement(By.xpath("//div[@class='summary--fixed-left']/table/tbody[last()]"));
		WebElement contractual = orders.findElement(By.xpath(".//td[2]//input"));
		contractual.sendKeys("A");
		contractual.sendKeys(Keys.ENTER);
		WebElement directTbl = orders.findElement(By.xpath(".//td[3]//input"));
		directTbl.sendKeys("T");
		directTbl.sendKeys(Keys.ENTER);
		try {
				Thread.sleep(3000);
				WebElement ori = orders.findElement(By.xpath(".//td[4]//input"));
				ori.click();
				Thread.sleep(3000);
				WebElement oriPortal = wait.until(ExpectedConditions.refreshed(
					    ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@id,'q-portal--menu')]//div[@clickable='true'][1]"))));
				oriPortal.click();
			} catch (Exception e) {
				
			}
		try {
				WebElement dest = orders.findElement(By.xpath(".//td[5]//input"));
				dest.click();
				Thread.sleep(3000);
				WebElement destPortal = wait.until(ExpectedConditions.refreshed(
					    ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@id,'q-portal--menu')]//div[@clickable='true'][1]"))));	
				destPortal.click();
			} catch (Exception e) {
				
			}
		Thread.sleep(3000);
		WebElement expandCheck = driver.findElement(By.xpath("//button/span/u/span"));
		if (expandCheck.getText().equals("Expand")) {
				driver.findElement(By.xpath("//u/span[text()='Expand']")).click();
			}
		Thread.sleep(3000);
		try {
				Thread.sleep(3000);
				WebElement standard = driver.findElement(By.xpath("//div[@class='summary--middle']/div[1]//div[@class='scoped'][1]//tbody[last()-1]"));
				Thread.sleep(2000);
				standard.findElement(By.xpath(".//td[1]//input")).sendKeys("4");
				Thread.sleep(2000);
				standard.findElement(By.xpath(".//td[2]//input")).sendKeys("4");
				Thread.sleep(2000);
				standard.findElement(By.xpath(".//td[3]//input")).sendKeys("4");
				Thread.sleep(2000);
				standard.findElement(By.xpath(".//td[4]//input")).sendKeys("4");
				driver.findElement(By.xpath("(//input[@data-test-id='BS-BR-0'])[3]")).sendKeys("KiranBabuCh");
			} catch (Exception e) {
		
			}

		Thread.sleep(10000);
		
		
	}
}
