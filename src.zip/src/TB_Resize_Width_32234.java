import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_Resize_Width_32234 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
				
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		//Port Width Change
		WebElement resizableElementPort = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='q-card portBlock default resizable']"));
		Thread.sleep(5000);
		String newStyle = "width: 100px; height: 50px;";
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		String script = "arguments[0].setAttribute('style', arguments[1]);";
		jsExecutor.executeScript(script, resizableElementPort, newStyle);
		WebElement resizableElement1 = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='q-card portBlock default resizable']"));
		String currentStyle1 = resizableElement1.getAttribute("style");
		System.out.println(currentStyle1);
		if (currentStyle1 != null){
			System.out.println("Terminal After Change Port Width "+ currentStyle1);
            cl.ActualTestDataValue = "Size(width) of the Port and Terminal are increased ";
	        cl.result("Verifyed, After Change The Port Width "+ currentStyle1, "" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Terminal After Change Port Width "+ currentStyle1);
            cl.ActualTestDataValue = "Size(width) of the Port and Terminal are increased ";
	        cl.result("Not Verifyed, After Change The Port Width "+ currentStyle1, "" , "Fail", "", 1, "VERIFY");
        }
		//Terminal Width Change
		WebElement resizableElementTerminal = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='terminal']//div[@class='q-card terminalBlock stretch resizable']"));
		Thread.sleep(5000);
		String newStyle1 = "width: 100px; height: 50px;";
		String script1 = "arguments[0].setAttribute('style', arguments[1]);";
		jsExecutor.executeScript(script1, resizableElementTerminal, newStyle1);
		WebElement resizableElementTerminalV = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='terminal']//div[@class='q-card terminalBlock stretch resizable']"));
		String currentStyle2 = resizableElementTerminalV.getAttribute("style");
		System.out.println(currentStyle2);
		if (currentStyle2 != null){
			System.out.println("Terminal After Change Width "+ currentStyle2);
            cl.ActualTestDataValue = "Size(width) of the port and terminal are increased ";
	        cl.result("Verifyed, After Change The Terminal Width "+ currentStyle2, "" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Terminal After Change Width "+ currentStyle2);
            cl.ActualTestDataValue = "Size(width) of the port and terminal are increased ";
	        cl.result("Not Verifyed, After Change The Terminal Width "+ currentStyle2, "" , "Fail", "", 1, "VERIFY");
        }
}
}
