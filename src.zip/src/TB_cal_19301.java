import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TB_cal_19301 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Robot robot = new Robot();
		
		WebElement itmScheduleInformationNavigation = driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']"));
        itmScheduleInformationNavigation.click();
		Thread.sleep(7000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']"));
		AddPortButton.click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort1.click();		
		Thread.sleep(3000);
		
		Thread.sleep(3000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPortButton2.click();
		Thread.sleep(4000);
		 
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("LKCMB");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		WebElement enterTerminal1 = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered'])[2]//div[@class='q-field__native row items-center']//input)[1]"));
		enterTerminal1.click();
		enterTerminal1.sendKeys("JCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[2]//td//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']")).click();
		
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		WebElement enterTerminal2 = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered'])[3]//div[@class='q-field__native row items-center']//input)[1]"));
		enterTerminal2.click();
		enterTerminal2.sendKeys("SGT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		WebElement enterTerminal3 = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered'])[4]//div[@class='q-field__native row items-center']//input)[1]"));
		enterTerminal3.click();
		enterTerminal3.sendKeys("CIC");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//tr[@class='data-table__port-row selected-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']")).click();
		//Change the BerthTime
		WebElement BerthTime = driver.findElement(By.xpath("(//div[@class='clickable'])[3]//p"));
		String BerthTimeValue = BerthTime.getText();
		if (BerthTimeValue != null){
            System.out.println("Before Berth Time= " + BerthTimeValue);
            //cl.ActualTestDataValue ="Before Berth Time";
	        //cl.result("Verifyed Before Berth Time= "+  BerthTimeValue, "Berth Time" , "Pass", "", 1, "VERIFY");
        }
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Unberth Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
	    WebElement ChangeBerthTime = driver.findElement(By.xpath("(//div[@class='clickable'])[3]"));
	    ChangeBerthTime.click();
	    /*
		WebElement ChangeTime = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));
		ChangeTime.click();
		WebElement BerthHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeBerthHours = new Select(BerthHours);
	    ChangeBerthHours.selectByValue("14");
	    Thread.sleep(2000);
	    */
	    WebElement ChangeTime = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));
		ChangeTime.click();
		ChangeTime.sendKeys("14");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//th[normalize-space()='Berth Time']")).click();
	    Thread.sleep(3000);
	    WebElement AfterBerthTime = driver.findElement(By.xpath("(//div[@class='clickable'])[3]//p"));
		String AfterBerthTimeValue = AfterBerthTime.getText();
		if (AfterBerthTimeValue != null){
            System.out.println("After Berth Time= " + AfterBerthTimeValue);
            //cl.ActualTestDataValue ="After Berth Time= ";
	        //cl.result("Verifyed After Berth Time= "+  AfterBerthTimeValue, " Berth Time" , "Pass", "", 1, "VERIFY");
        }
		
 }
}
