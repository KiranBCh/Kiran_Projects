import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TB_Edit_port_20691 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Robot robot = new Robot();
		
		WebElement itmScheduleInformationNavigation = driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']"));
        itmScheduleInformationNavigation.click();
		Thread.sleep(7000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']"));
		AddPortButton.click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort1.click();		
		Thread.sleep(3000);
		
		Thread.sleep(3000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPortButton2.click();
		Thread.sleep(4000);
		 
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPortButton3.click();
		Thread.sleep(3000);
		/*	
		WebElement AddPort3 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort3.click();		
		Thread.sleep(3000);
		
		AddPort3.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		*/
		
		WebElement ChangePort2 = driver.findElement(By.xpath("((//tr[@class='data-table__port-row'])[2]//td//input)[2]"));
		ChangePort2.click();		
		Thread.sleep(3000);
		ChangePort2.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(4000);
		ChangePort2.sendKeys("ITRAN");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement ExitPortRow = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[1]"));
		WebElement ExitTerminalRow = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]"));
		
		//Edit Arrival time for first port
		WebElement SeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[15]")); 
		String SeatimeValue = SeaTime.getText();
		System.out.println("SeaTime=" + SeatimeValue);
		
		WebElement ArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p")); 
		String ArrivalTimeValue = ArrivalTime.getText();
		System.out.println("ArrivalTime=" + ArrivalTimeValue);
		
		WebElement ChangeArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']"));
		ChangeArrivalTime.click();
		WebElement ChangeTime = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));
		ChangeTime.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']")).click();
		Thread.sleep(5000);
		WebElement AfterSeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[15]")); 
		String AfterSeatimeValue = AfterSeaTime.getText();
		System.out.println("AfterSeaTime=" + AfterSeatimeValue);
		
		WebElement AfterArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p")); 
		String AfterArrivalTimeValue = AfterArrivalTime.getText();
		System.out.println("ArrivalTime=" + AfterArrivalTimeValue);
		if (SeatimeValue.equals(AfterSeatimeValue)){
            System.out.println("Verify SeaTime Re-calculated= " + SeatimeValue);
            //cl.ActualTestDataValue ="Edit Arrival time for first port";
	        //cl.result("Verifyed Before SeaTime Calculation= "+ SeatimeValue, "After SeaTime Calclulation " + AfterSeatimeValue , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("Not Verify SeaTime Re-calculated= " + SeatimeValue);
            //cl.ActualTestDataValue ="Edit Arrival time for first port";
	        //cl.result("Not Verifyed Before SeaTime Calculation= "+ SeatimeValue, "After SeaTime Calclulation " + AfterSeatimeValue , "Fail", "", 1, "VERIFY");
        }
		
		//2 verification
		List<WebElement> DistanceGet = driver.findElements(By.xpath("//th[normalize-space()='Distance (NM)']//following::tr[4]//td[12]//input[@class='q-field__input q-placeholder col']"));
		String DistanceAfterValue = "";
		for(WebElement value : DistanceGet) {
			if(value.getAttribute("value") != null) {				
				DistanceAfterValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> SpeedneedCheck = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedAfterValue = "";
		for(WebElement value : SpeedneedCheck) {
			if(value.getAttribute("value") != null) {				
				SpeedAfterValue = value.getAttribute("value");
				break;
			}
		}
		WebElement SeaTimeVeri = driver.findElement(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td[15]"));
		String seaTimeString = SeaTimeVeri.getText();
		double seaTimeDouble = Double.parseDouble(seaTimeString);
		double roundedNumber = Math.round(seaTimeDouble);
		
		double DistanceCal1 = Double.valueOf(DistanceAfterValue);
		double AfterSeatimeValueCa11 = Double.valueOf(SpeedAfterValue);
		double SpeedCalculation = (DistanceCal1) / (AfterSeatimeValueCa11);
		double final_cal = Math.round(SpeedCalculation);
		
		//Verify Speed Calculation
		if (roundedNumber == final_cal){
            System.out.println("Edit Arrival time of any other port apart from last port= " + final_cal);
            //cl.ActualTestDataValue ="Edit Arrival time of any other port apart from last port";
	        //cl.result("Verifyed Speed Before Calculation= "+ seaTimeString, "After Speed Calclulation " + roundedNumber , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("Not Edit Arrival time of any other port apart from last port= " + final_cal);
            //cl.ActualTestDataValue ="Edit Arrival time of any other port apart from last port";
	        //cl.result("Not Verifyed Speed Before Calculation= "+ seaTimeString, "After Speed Calclulation " + roundedNumber , "Fail", "", 1, "VERIFY");
        }
		
		//Edit Arrival time of any other port apart from last port
		
		WebElement ChangeArrivalTime2 = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[19]//div[@class='clickable']"));
		ChangeArrivalTime2.click();
		WebElement ChangeTime2 = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));
		ChangeTime2.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']")).click();
		Thread.sleep(5000);
		
		WebElement ArrivalTime2PortVerification = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[19]//div[@class='clickable']//p"));
		String ArrivalTime2PortValueVerification = ArrivalTime2PortVerification.getText();
		System.out.println("ArrivalTime2PortValueVerification= "+ArrivalTime2PortValueVerification);
		Thread.sleep(5000);
		
		WebElement ArrivalTime3Port = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][3]//td[19]//div[@class='clickable']//p"));
		String ArrivalTime3PortValue = ArrivalTime3Port.getText();
		System.out.println("ArrivalTime3PortValue= "+ArrivalTime3PortValue);
		WebElement DepartureTime2Port = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[22]//div[@class='clickable']//p"));
		String DepartureTime2PortValue = DepartureTime2Port.getText();
		System.out.println("DepartureTime2PortValue= "+DepartureTime2PortValue);
		
        SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        long hours = 0;
        try {
            // Parse the times into Date objects
            Date date1 = dateFormat.parse(ArrivalTime3PortValue);
            Date date2 = dateFormat.parse(DepartureTime2PortValue);

            // Calculate the time difference in milliseconds
            long timeDifference = date1.getTime() - date2.getTime();

            // Convert the time difference to hours and minutes
            hours = (timeDifference / (60 * 60 * 1000 ));
            
            System.out.println("Time Difference: " + hours + " hours ");
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        
        if (hours == seaTimeDouble){
            System.out.println("Recalculate SeaTime = Arrival Time of next port - Departure Time of previous port= " + hours);
            //cl.ActualTestDataValue ="Recalculate SeaTime = Arrival Time of next port - Departure Time of previous port";
	        //cl.result("Verifyed ArrivalTime = "+ ArrivalTime3PortValue, " Departure Time" + DepartureTime2PortValue , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("Not Recalculate SeaTime = Arrival Time of next port - Departure Time of previous port= " + hours);
            //cl.ActualTestDataValue ="Recalculate SeaTime = Arrival Time of next port - Departure Time of previous port";
	        //cl.result("Verifyed ArrivalTime = "+ ArrivalTime3PortValue, " Departure Time" + DepartureTime2PortValue , "Fail", "", 1, "VERIFY");
        }
	}
}
