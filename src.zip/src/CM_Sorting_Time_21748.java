import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import java.text.ParseException;
import java.text.SimpleDateFormat;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CM_Sorting_Time_21748 {
		public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		//"https://thebridgeuatcapacity.x-pressfeeders.com/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		Thread.sleep(3000);
		driver.navigate().refresh();
		Thread.sleep(8000);
		Thread.sleep(8000);
		Thread.sleep(8000);
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(2000);
		Thread.sleep(2000);
		Thread.sleep(8000);
		Robot robot = new Robot();
		String VesselName = "A FUKU";
		Thread.sleep(2000);
		VesselClick_Search.sendKeys(VesselName);
		Thread.sleep(2000);
		Thread.sleep(2000);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(8000);
		Thread.sleep(8000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Search= driver.findElement(By.xpath("//span[contains(text(),'Search')]"));
		Search.click();
		
		Thread.sleep(8000);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Search);
		Thread.sleep(6000);
		Thread.sleep(6000);
		
		WebElement VeseelNameenter = driver.findElement(By.xpath("//span[contains(text(), 'A FUKU')]"));
		Thread.sleep(6000);
		VeseelNameenter.click();
		driver.navigate().refresh();
		Thread.sleep(8000);
		Thread.sleep(6000);
		Thread.sleep(6000);
		List<WebElement> ETATimes = driver.findElements(By.xpath("//p[contains(text(), 'ETA')]//following-sibling::p[@class='port-detail-info vert-line']"));
		Thread.sleep(6000);
		Thread.sleep(6000);
		int ETATimesValues = ETATimes.size();
		Thread.sleep(6000);
		System.out.println("Times-->"+ETATimesValues);
		Thread.sleep(6000);
		List<String> dateStrings = new ArrayList<>();
		for (int i = 0; i < ETATimesValues; i++) {
			System.out.println(ETATimes.get(i).getText()); 
			dateStrings.add(ETATimes.get(i).getText());
		}
		//List<Date> dates = parseDates(dateStrings);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		List<Date> dates = new ArrayList<>();
        for (String dateString : dateStrings) {
            Date date = dateFormat.parse(dateString);
            dates.add(date);
        }
        for (int i = 0; i < dates.size(); i++) {
        	String formattedDate = new SimpleDateFormat("yyyy-MM-dd").format(dates.get(i));
        	System.out.println("OriginalDate-->"+formattedDate);
            String eachdate = "";
            WebElement PortNamesSize= driver.findElement(By.xpath("//div[@class='q-scrollarea__content absolute']//div[@class='q-scrollarea']//div[contains(@class, 'port-summary-card')]["+(i+1)+"]"));
            PortNamesSize.click();
            Thread.sleep(500);
            eachdate = driver.findElement(By.xpath("(//p[contains(text(), 'ETA')]//following-sibling::p[@class='port-detail-info vert-line'])["+(i+1)+"]")).getText();
            Date date1 = dateFormat.parse(eachdate);
            SimpleDateFormat outFormat = new SimpleDateFormat("yyyy-MM-dd");
            String outString = outFormat.format(date1);
            System.out.println(outString);
            Thread.sleep(500);
            if (formattedDate.equals(outString)){
            	System.out.println("The headings of the cards in the order by Arrival times.");
                //cl.ActualTestDataValue = "Arrival Time";
        	    //cl.result("Verifyed Arrival Time are ordered", "", "Pass", "", 1, "VERIFY");
            }else {
                //cl.ActualTestDataValue = "Arrival Time";
        	    //cl.result("Not Verifyed Arrival Time are ordered", "", "Fail", "", 1, "VERIFY");
            }
        }
	}
}