import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class TB_31788_Cascade {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 150)","");
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		AddPortName2.sendKeys("BDMGL");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		Thread.sleep(3000);
		Thread.sleep(4000);
		driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--outline q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense cascade_btn'])[2]")).click();
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//div[@id='port-departure-00']")).click();
		Thread.sleep(4000);
		
		WebElement change = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar gantt']//select[@id='gantt-hours']//option[@value='23']"));
		Thread.sleep(2000);
		change.click();
		//change.sendKeys(Keys.ENTER);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[text()='Wed'])[1]")).click();
		Thread.sleep(2000);
		/*
		WebElement DepartureTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeDepartureTimeHours = new Select(DepartureTimeHours);
	    //ChangeDepartureTimeHours.selectByValue("23");
	    ChangeDepartureTimeHours.selectByVisibleText("23");
		Thread.sleep(5000);
		*/
		//robot.keyPress(KeyEvent.VK_TAB);
	    //robot.keyRelease(KeyEvent.VK_TAB);
		
		/*
		driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']")).click();
		Thread.sleep(5000);
		
		WebElement DepartureTimeBefore = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
		String GetDepartureTime = DepartureTimeBefore.getText();
		
        WebElement DepartureTime = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
        actions.moveToElement(DepartureTime).doubleClick().perform();
        WebElement DepartureTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeDepartureTimeHours = new Select(DepartureTimeHours);
	    ChangeDepartureTimeHours.selectByValue("14");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
	    Thread.sleep(2000);
	    WebElement DepartureTimeAfter = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
		String GetDepartureTimeAfter = DepartureTimeAfter.getText();
		if (!(GetDepartureTime).equals(GetDepartureTimeAfter)){
			System.out.println("Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours");
			//cl.result("Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours", "", "Pass", "46653", 1, "Verify");
		}
        else {
        	System.out.println("Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours");
			//cl.result("Not_Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours", "", "Fail", "46653", 1, "Verify");
		}  
		
		driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
		Thread.sleep(2000);
		*/
	}
}
