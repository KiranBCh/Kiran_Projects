import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class TB_26591 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(4000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);

		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(5000);
        driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort1.click();		
		Thread.sleep(3000);
		
		Thread.sleep(3000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(4000);
		 
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement add_port_third_option_terminal= driver.findElement(By.xpath("(//i[text()='arrow_drop_down'])[14]"));
		scrollIntoView(add_port_third_option_terminal,driver);
		add_port_third_option_terminal.click();
 
		Thread.sleep(2000);
		WebElement add_port_third_option_terminal_option= driver.findElement(By.xpath("//div[text()='Ajman']"));
		scrollIntoView(add_port_third_option_terminal_option,driver);
		add_port_third_option_terminal_option.click();
		//Step 1 : Sum total should be displayed in the fields:
 
		List<WebElement> Distance_P1 = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String Distancevalue = "";
		for(WebElement value : Distance_P1) {
			if(value.getAttribute("value") != null) {				
				Distancevalue = value.getAttribute("value");
				break;
			}
		}
		String D1=Distancevalue;
		double Dis_1 = Double.valueOf(D1);
		System.out.println("D1 ===>"+Dis_1);
		Thread.sleep(1000);
		List<WebElement> Distance_P2 = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[6]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String Distance = "";
		for(WebElement value : Distance_P2) {
			if(value.getAttribute("value") != null) {				
				Distance = value.getAttribute("value");
				break;
			}
		}
		String D2=Distance;
		double Dis_2 = Double.valueOf(D1);
		System.out.println("D2 ===>"+Dis_2);
		WebElement Total_Distance= driver.findElement(By.xpath("(//tr[last()])[2]//td[3]"));
		String total_distance=Total_Distance.getText();
		Double Total_dis=Double.valueOf(total_distance);
		System.out.println("Total Distance : "+Total_dis);
		//compare logic
		//a. total Distance
		if((Dis_1+Dis_2)==Total_dis) {
			System.out.println("PASSED");
			//cl.ActualTestDataValue=Total_dis;
			//cl.result("Validation : Total Distance ", "", "Pass", "", 1,"Verify");
		}else {
			System.out.println("Failed");
			//cl.ActualTestDataValue=Total_dis;
			//cl.result("Validation : Total Distance ", "", "Fail", "", 1,"Verify");
		}
		//b. Distance SECA
		WebElement SECA_1= driver.findElement(By.xpath("//tr[3]//td[13]"));
		String seca_1=SECA_1.getText();
		int Seca_1=Integer.parseInt(seca_1);
		System.out.println("Seca_1 Distance : "+Seca_1);
		WebElement SECA_2= driver.findElement(By.xpath("//tr[5]//td[13]"));
		String seca_2=SECA_2.getText();
		int Seca_2=Integer.parseInt(seca_2);
		System.out.println("Seca_2 Distance : "+Seca_2);
		WebElement Total_SECA= driver.findElement(By.xpath("(//tr[last()])[2]//td[4]"));
		String total_seca=Total_SECA.getText();
		int Total_seca=Integer.parseInt(total_seca);
		System.out.println("Total Distance : "+Total_seca);
		if((Seca_1+Seca_2)==Total_seca) {
			System.out.println("PASSED");
			//cl.ActualTestDataValue=Total_seca;
			//cl.result("Validation : Total SECA ", "", "Pass", "", 1,"Verify");
		}else {
			System.out.println("Failed");
			//cl.ActualTestDataValue=Total_seca;
			//cl.result("Validation : Total SECA ", "", "Fail", "", 1,"Verify");
		}
		//c. SEA Time
		WebElement sea_time_1= driver.findElement(By.xpath("//tr[3]//td[15]"));
		String Sea_time_1=sea_time_1.getText();
		int SEA_time_1=Integer.parseInt(Sea_time_1);
		System.out.println("SEA_time_1 Distance : "+Seca_1);
 
		WebElement sea_time_2= driver.findElement(By.xpath("//tr[5]//td[15]"));
		String Sea_time_2=sea_time_2.getText();
		int SEA_time_2=Integer.parseInt(Sea_time_2);
		System.out.println("SEA_time_2 Distance : "+SEA_time_2);
 
		WebElement Total_Sea_Time= driver.findElement(By.xpath("(//tr[last()])[2]//td[6]"));
		String total_sea_Time=Total_Sea_Time.getText();
		int Total_SEA_Time=Integer.parseInt(total_sea_Time);
		System.out.println("Total SEA Time : "+Total_SEA_Time);
 
		if((SEA_time_1+SEA_time_2)==Total_SEA_Time) {
			System.out.println("PASSED");
			//cl.ActualTestDataValue=Total_SEA_Time;
			//cl.result("Validation : Total SECA ", "", "Pass", "", 1,"Verify");
		}else {
			System.out.println("Failed");
			//cl.ActualTestDataValue=Total_SEA_Time;
			//cl.result("Validation : Total SECA ", "", "Fail", "", 1,"Verify");
		}
 
		//d.Operation Time
		Thread.sleep(1000);
		List<WebElement> operation_time = driver.findElements(By.xpath("//th[normalize-space()='Operation Time']//following::tr[3]//td[16]//input"));
		String Operation_time = "";
		for(WebElement value : operation_time) {
			if(value.getAttribute("value") != null) {				
				Operation_time = value.getAttribute("value");
				break;
			}
		}
		WebElement Operation_1= driver.findElement(By.xpath("//tr[2]//td[16]"));
		scrollIntoView(Operation_1,driver);
		String operation_1=Operation_time;
		int Operation_one=Integer.parseInt(operation_1);
		System.out.println("SEA_time_1 Distance : "+Operation_one);
		Thread.sleep(1000);
		List<WebElement> operation_time_2 = driver.findElements(By.xpath("//th[normalize-space()='Operation Time']//following::tr[5]//td[16]//input"));
		String Operation_time_2= "";
		for(WebElement value : operation_time_2) {
			if(value.getAttribute("value") != null) {				
				Operation_time_2 = value.getAttribute("value");
				break;
			}
		}
		//WebElement Operation_1= driver.findElement(By.xpath("//tr[2]//td[16]"));
		scrollIntoView(Operation_1,driver);
		String operation_2=Operation_time_2;
		int Operation_two=Integer.parseInt(operation_2);
		System.out.println("SEA_time_1 Distance : "+Operation_two);

		Thread.sleep(1000);
		List<WebElement> operation_time_3 = driver.findElements(By.xpath("//th[normalize-space()='Operation Time']//following::tr[7]//td[16]//input"));
		String Operation_time_3= "";
		for(WebElement value : operation_time_3) {
			if(value.getAttribute("value") != null) {				
				Operation_time_3 = value.getAttribute("value");
				break;
			}
		}
		//WebElement Operation_1= driver.findElement(By.xpath("//tr[2]//td[16]"));
		scrollIntoView(Operation_1, driver);
		String operation_3=Operation_time_3;
		int Operation_three=Integer.parseInt(operation_3);
		System.out.println("Operation_three Distance : "+Operation_three);

		WebElement Total_Operation_Time= driver.findElement(By.xpath("(//tr[last()])[2]//td[8]"));
		String total_Operation_Time=Total_Operation_Time.getText();
		int total_operation_tme=Integer.parseInt(total_Operation_Time);
		System.out.println("Total SEA Time : "+total_operation_tme);
		if((Operation_one+Operation_two+Operation_three)==total_operation_tme) {
			System.out.println("PASSED");
			//cl.ActualTestDataValue=total_operation_tme;
			//cl.result("Validation : Total SECA ", "", "Pass", "", 1,"Verify");
		}else {
			System.out.println("Failed");
			//cl.ActualTestDataValue=total_operation_tme;
			//cl.result("Validation : Total SECA ", "", "Fail", "", 1,"Verify");
		}
		/*
		WebElement Colorverification = driver.findElement(By.xpath("//div[@class='q-banner row items-center q-banner--top-padding text-white bg-red']"));
		boolean falg=Colorverification.getAttribute("class").contains("red");
	
        if(falg){
        	//cl.result("Verifyed, Red dot indicator is displayed in long term", "" , "Pass", "", 1, "VERIFY");
        	List<WebElement> value = driver.findElements(By.xpath("//div[@class='q-banner row items-center q-banner--top-padding text-white bg-red']//div[@class=\"q-banner__content col text-body2\"]//div"));
        	for (WebElement webElement : value) {
        		HighLight(webElement, driver);
			}
        	
            
       }else {
    	   System.out.println("Color Verification Pass");
    	   //cl.ActualTestDataValue = "Color Code";
   	       //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Fail", "", 1, "VERIFY");
       }*/
	}

public static void HighLight(WebElement ele,WebDriver driver) {
	try {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')",ele);
	}catch (Exception e) {
	}
}
	public static void scrollIntoView(WebElement ele,WebDriver driver) {
		try {
			HighLight(ele,driver);
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'})", ele);
		}catch (Exception e) {
		}
	}
}
