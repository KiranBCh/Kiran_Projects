import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TB_SM_Remove_36786 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		Thread.sleep(9000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Robot robot = new Robot();
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("AEAJM");
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddPort);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		for (int i = 0; i <= 4 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement TotalRowVerification = driver.findElement(By.xpath("//tr[contains(@style, 'bottom')]//following-sibling::tr[1]"));
		boolean TotalRow = TotalRowVerification.isDisplayed();
		if (TotalRow == true) {
			System.out.println("TotalRow--->"+TotalRow);
			//cl.log.info("TotalRow -->"+ TotalRow);
	        //cl.ActualTestDataValue = "Total Row Verification";
	    	//cl.result("Yes, it has been verified. In Testbed, the total row is enabled., "" , "Pass", "", 1, "VERIFY");
		} else {
			//cl.log.info("TotalRow -->"+ TotalRow);
	        //cl.ActualTestDataValue = "Total Row Verification";
	    	//cl.result("Yes, it has been verified. In Testbed, the total row is enabled., "" , "Fail", "", 1, "VERIFY");
		}
	}
}
