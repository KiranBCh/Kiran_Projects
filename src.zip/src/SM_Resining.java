
import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;


public class SM_Resining {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		//System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,105)","");
		Thread.sleep(3000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		Thread.sleep(5000);
		//Resize
		Thread.sleep(5000);
		WebElement Drag3 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[3]"));
		System.out.println(Drag3.getLocation());
		Thread.sleep(3000);
		//actions.clickAndHold(Drag3).moveByOffset(10, 30).release().build().perform();
		//actions.clickAndHold(Drag3).moveByOffset(10, 30).release().build().perform();
		
		
		
		WebElement Drag2 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[2]"));
		System.out.println(Drag2.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
		
		
		WebElement Drag1 = driver.findElement(By.xpath("(//div[@id='portDblClick'])[1]"));
		//System.out.println(Drag1.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		actions.clickAndHold(Drag1).moveByOffset(10, 40).release().build().perform();
		
		WebElement ArrivalTimeChange = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='1']//div[@id='port-arrival-01']"));
		actions.moveToElement(ArrivalTimeChange).doubleClick().perform();
		//actions.doubleClick(ArrivalTimeChange).build().perform();
		
		WebElement timeclick = driver.findElement(By.xpath("//select[@id='gantt-hours']//option[@value='0']"));
		actions.doubleClick(timeclick).build().perform();
		/*
		WebElement ArrivalTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeArrivalTimeHours = new Select(ArrivalTimeHours);
	    ChangeArrivalTimeHours.selectByValue("0");
	    actions.doubleClick(ArrivalTimeHours).build().perform();
	    Thread.sleep(6000);
	    */
		WebElement statusmsg = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Arrival "+statusmsg.getText());
	    Thread.sleep(6000);
	    
	    driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(6000);
	    
	    WebElement DepartureTimeChange = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@portindex='1']//div[@id='port-departure-01']"));
		//actions.moveToElement(DepartureTimeChange).doubleClick().perform();
	    actions.doubleClick(DepartureTimeChange).build().perform();
		
		WebElement DepartureTimeChangeeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select DepartureTimeHours = new Select(DepartureTimeChangeeHours);
	    DepartureTimeHours.selectByValue("23");
	    actions.doubleClick(DepartureTimeChangeeHours).build().perform();
	    Thread.sleep(6000);
	    
		WebElement statusmsg1 = driver.findElement(By.xpath("//div[@class='error-list time-only']//ul//li"));
		System.out.println("Error Departure "+statusmsg1.getText());
	}

}
