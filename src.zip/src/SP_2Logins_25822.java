import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SP_2Logins_25822 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Schedule Publishing')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("(//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Add service']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//th[text()=' Select Service Code ( ']/div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Add Service Codes']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[2]")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("(//a[contains(text(), 'ANBIEN BAY')])[1]")).click();
		Thread.sleep(5000);
		
		WebElement R_button0 = driver.findElement(By.xpath("(//tr[2]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center'])[1]"));
		String staus = R_button0.getAttribute("aria-checked");
		System.out.println("Status of R_buton0 "+ staus);
		boolean R_button0_status = Boolean.parseBoolean(staus);
		
		WebElement R_button1 = driver.findElement(By.xpath("(//tr[2]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center'])[2]"));
		String staus1 = R_button1.getAttribute("aria-checked");
		System.out.println("Status of R_buton1 "+ staus1);
		boolean R_button1_status = Boolean.parseBoolean(staus1);
		
		WebElement R_button2 = driver.findElement(By.xpath("(//tr[2]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center'])[3]"));
		String staus2 = R_button2.getAttribute("aria-checked");
		System.out.println("Status of R_buton2 "+ staus2);
		boolean R_button2_status = Boolean.parseBoolean(staus2);
		
		if (R_button0_status == true) {
			R_button1.click();
		}else if (R_button1_status == true){
			R_button2.click();
		}
		else if (R_button2_status == true){
			R_button0.click();
		}
		WebElement EditedByName = driver.findElement(By.xpath("//div[@id='header']//p[child::strong[contains(text(),'Last edited by')]]"));
		String EditeByNameValue = EditedByName.getText();
		System.out.println("EditedByName "+ EditeByNameValue);
		WebElement SaveButton = driver.findElement(By.xpath("(//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row'])[3]"));
		SaveButton.click();
		Thread.sleep(7000);
		/*
		boolean ChangeTerminalSettingstrue3 = false;
		List<WebElement> R_button = driver.findElements(By.xpath("//tr[@class='terminal-row'][1]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center' and @role]"));
		System.out.println("Size " + R_button.size());
		for (int i = 0; i < R_button.size(); i++) {
			if(R_button.get(i).getAttribute("aria-checked").contains("true")) {
				System.out.println("Size " + i);
				R_button.get((i+1)).click();
				ChangeTerminalSettingstrue3 = R_button.get((i+1)).getAttribute("aria-checked").contains("true");
				System.out.println(ChangeTerminalSettingstrue3);	
				break;
			}
			else if(i==2)
			{
				R_button.get((i-1)).click();
				break;
			}
		}
		
		*/
		Actions actions = new Actions(driver);
		WebElement Logout = driver.findElement(By.xpath("(//div[@class='q-item__section column q-item__section--side justify-center q-item__section--avatar xpf-menu-item__icon'])[7]"));
		actions.moveToElement(Logout).perform();
		Logout.click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("(//i[normalize-space()='logout'])[1]")).click();
		Thread.sleep(7000);
		
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("testiamsagarmatha@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("VeryComplexPassword1");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		Thread.sleep(3000);
		WebElement Services1 = driver.findElement(By.xpath("//li[contains(text(),'Schedule Publishing')]"));
		je.executeScript("arguments[0].click();", Services1);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("(//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[2]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//a[contains(text(), 'ANBIEN BAY')])[1]")).click();
		Thread.sleep(5000);
		WebElement EditedByName1 = driver.findElement(By.xpath("//div[@id='header']//p[child::strong[contains(text(),'Last edited by')]]"));
		System.out.println("EditedByName1 "+ EditedByName1.getText());
		String EditedByName1Value = EditedByName1.getText();
		
		if (!(EditeByNameValue.equals(EditedByName1Value))) {
			System.out.println("Verifyed, Changed The Subscription Settings = ");
			 //cl.ActualTestDataValue = "Subscription Settings Change using Two Logins";
        	//cl.result("Verifyed Changed The Subscription Settings Before "+ EditedByName.getText()+ " After Change The Login " + EditedByName1.getText(), "", "Pass", "25822", 1, "Verify");
		}
		else {
			System.out.println("Not Verifyed, changed The Subscription Settings = ");
			//cl.ActualTestDataValue = "Subscription Settings Change using Two Logins";
			//cl.result("Not Verifyed Changed The Subscription Settings Before "+ EditedByName.getText()+ " After Change The Login " + EditedByName1.getText(), "", "Fail", "25822", 1, "Verify");
		}
	}
}
