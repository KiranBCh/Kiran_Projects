import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TB_51880_51884_Delta2 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(4000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);

		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(5000);
        driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort1.click();		
		Thread.sleep(3000);
		
		Thread.sleep(3000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(4000);
		 
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(3000);
			
		WebElement AddPort3 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort3.click();		
		Thread.sleep(3000);
		AddPort3.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		//UtilizationCheckBox
		driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='row-grouping']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]")).click();
		//External
		driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[1]")).click();
		//Internall
		driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[2]")).click();
		
		//ServiceRotation
		WebElement ServiceRotation = driver.findElement(By.xpath("(//td[@class='highlight row-grouping']//input[@class='q-field__input q-placeholder col'])[1]"));
		ServiceRotation.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		//Leg
		WebElement Leg = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[1]"));
		Leg.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement LegMiddle = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[2]"));
		LegMiddle.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement LegLast = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[3]"));
		LegLast.click();
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		
		//WebDriverWait wait = new WebDriverWait(driver, 20);
		//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='q-notification__content row items-center col']//div[text()='Data was saved']"))));
		//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='q-notification__content row items-center col']//div[text()='Data was updated']"))));
		
		
		WebElement InputVesselName = driver.findElement(By.xpath("(//div[@class='inputs']//div[@class='q-field__inner relative-position col self-stretch']//input[@class='q-field__native q-placeholder'])"));		
		Thread.sleep(2000);
		String FileName = "Kiran002name2";
		actions.moveToElement(InputVesselName).doubleClick().perform();
		InputVesselName.sendKeys(Keys.CONTROL, "a",Keys.DELETE);
		InputVesselName.sendKeys(FileName);

		driver.findElement(By.xpath("//button[@id='btnSaveLocal']")).click();
		driver.findElement(By.xpath("//button[@id='btnSaveCentral']")).click();
		
		//String titleName = driver.findElement(By.xpath("//div[@class='page-title' and text()]")).getText();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--round q-btn--actionable q-focusable q-hoverable q-btn--dense']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--round q-btn--actionable q-focusable q-hoverable q-btn--dense']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle q-btn--actionable q-focusable q-hoverable buttons-cancel'])[2]")).click();
		Thread.sleep(2000);
		//Select ServiceCyclerotation
		//(//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[4]//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy']
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys(FileName);
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'"+ FileName+"')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("CAPE FLORES");
		Thread.sleep(5000);
	
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        
        WebElement Colorverification = driver.findElement(By.xpath("((((//div[@id='block'])[1]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[1])//div[@class='timing'])[2]//div[@class='indicator-container isOmitted']"));
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String script = "return window.getComputedStyle(arguments[0], ':before').getPropertyValue('background-color')";
        String FetchValue = (String) jsExecutor.executeScript(script, Colorverification);
        System.out.println(FetchValue);
        
        String expected_color="rgb(203, 60, 68)";
        if(expected_color.equals(FetchValue)){
        	System.out.println("Color Verification Pass" + FetchValue);
            //cl.ActualTestDataValue = "Color Code";
    	    //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Pass", "", 1, "VERIFY");
       }else {
    	   System.out.println("Color Verification Pass" + FetchValue);
    	   //cl.ActualTestDataValue = "Color Code";
   	       //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Fail", "", 1, "VERIFY");
       }
        
        WebElement CycleBlank = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[10]"));
        WebElement VesselPositionBlank = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[11]"));
        boolean CycleBlankVerification = CycleBlank.getText().isEmpty();
        if (CycleBlankVerification) {
        	System.out.println("CycleBlankVerification");
            //cl.ActualTestDataValue = "Cycle Blank";
    	    //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Pass", "", 1, "VERIFY");
        }
        else {
     	   System.out.println("Color Verification Pass" + FetchValue);
     	   //cl.ActualTestDataValue = "Color Code";
    	       //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Fail", "", 1, "VERIFY");
        }
       List<WebElement> cycle = driver.findElements(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[10]"));
       int cyclecount=cycle.size();
       cl.log.info("cyclecount-->"+cyclecount);
       int count=0;
       
       for (WebElement webElement : cycle) {
    	  if(!(webElement.getTagName().equals("input"))){
    		  cyclecount--;
    	  }
       }
       cl.log.info("end-loop-cyclecount-->"+cyclecount);
       if (cyclecount==0) {
   	    cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Pass", "", 1, "VERIFY");
       }
       else {
   	       cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Fail", "", 1, "VERIFY");
       }
       WebElement Colorverification = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]"));
       Thread.sleep(3000);
       Colorverification.getCssValue("background-color");
	}
	
}
