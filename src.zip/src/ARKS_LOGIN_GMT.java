import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import javax.sound.sampled.Port;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.WebElement;


public class ARKS_LOGIN_GMT {
	public static void main(String[] args) throws InterruptedException, AWTException {
	System.out.println("****************************");
	System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

	ChromeDriver driver = new ChromeDriver();
	String domain_url = "https://arksuat.feederit.com/ARKS/Account/Login.aspx";
	driver.get(domain_url);
	WebDriverWait wait = new WebDriverWait(driver, 20);         
	
	driver.manage().window().maximize();
	driver.findElement(By.xpath("//div[@class='nav-wrapper']//button[@id='details-button']")).click();
	driver.findElement(By.xpath("//p//a[@id='proceed-link']")).click();
	driver.findElement(By.xpath("//input[@id='tbUserName']")).sendKeys("alumini");
	driver.findElement(By.xpath("//input[@name='tbPassword']")).sendKeys("P#s23bt78Q");		

	driver.findElement(By.xpath("//div[@class='col_half topmargin bottommargin']")).click();
	
	String MasterPortReport = "https://arksuat.feederit.com/ARKS/Biz%20Modules/Reports/Master%20Report/MasterPortReport.aspx";
	driver.get(MasterPortReport);
	
	//Port Name
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@class='mainautoinput ui-autocomplete-input'])[1]"))).sendKeys("INMAA");
	Robot robot = new Robot();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@data-bind='click: Proceed']"))).click();
	
	//PortCode
	WebElement PortCode = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@dir='LTR']//tr[3]//tr[3]//td)[1]//div")));
	String PortCodeValue = PortCode.getText();
	System.out.println("Port Code ="+ PortCodeValue);
	
	//GMT Difference
	WebElement GMTDifference = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@dir='LTR']//tr[3]//tr[3]//td)[4]//div")));
	String GMTDifferenceValue = GMTDifference.getText();
	System.out.println("GMT Difference Time ="+ GMTDifferenceValue);
	
	//Logout
	WebElement LogoutARKS = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@href, 'Logout')]")));
	LogoutARKS.click();
	
	}
}
