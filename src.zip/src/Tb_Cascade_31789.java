import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Tb_Cascade_31789 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 150)","");
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		AddPortName2.sendKeys("BDMGL");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		
		WebElement SpeedCha = driver.findElement(By.xpath("//div[@class='q-card']//input"));
		String SpeedChaValue = SpeedCha.getAttribute("value");
		double ChangeSpeeddouble = Double.parseDouble(SpeedChaValue);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", SpeedCha);
		if(SpeedChaValue != null){
        	System.out.println("Speed= " + SpeedChaValue);
        	//cl.log.info("Speed Default-->"+ SpeedChaValue);
            //cl.ActualTestDataValue = "Speed in GanttChart";
    	    //cl.result("Verifyed, Speed= "+ SpeedChaValue, "" , "Pass", "", 1, "VERIFY");
       }
		
		WebElement SpeedChangeGantt = driver.findElement(By.xpath("//div[@class='q-card']//input"));
		SpeedChangeGantt.click();
		SpeedChangeGantt.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		Thread.sleep(3000);
		double addextra = 200;
		double finalvalue = ChangeSpeeddouble + addextra;
		String str = new Double(finalvalue).toString();
		SpeedChangeGantt.sendKeys(str);
		
		
		driver.findElement(By.xpath("//i[@class='q-icon notranslate material-icons readMoreIcon icon']")).click();
		Thread.sleep(4000);
		
		WebElement SeaTime = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[2]//td[15]"));
		String	SeaTimeValue = SeaTime.getText();
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", SeaTime);
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		Thread.sleep(4000);
		if(SeaTimeValue !=null){
        	//cl.log.info("SeaTime -->"+ SeaTimeValue);
            //cl.ActualTestDataValue = "SeaTime";
    	    //cl.result("Verifyed, SeaTime= "+ SeaTimeValue, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement ArrivalTime = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[2]//td[19]//div[@class='clickable']//p"));
		String	ArrivalTimeValueUpwards = ArrivalTime.getText();
		System.out.println("ArrivalTimeValueUpwards= "+ ArrivalTimeValueUpwards);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ArrivalTime);
		if(ArrivalTimeValueUpwards !=null){
        	//cl.log.info("ArrivalTime -->"+ ArrivalTimeValueUpwards);
            //cl.ActualTestDataValue = "Drag port upwards ArrivalTime";
    	    //cl.result("Verifyed, ArrivalTime= "+ ArrivalTimeValueUpwards, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement DepartureTime = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[2]//td[22]//div[@class='clickable']//p"));
		String	DepartureTimeValueUpwards = DepartureTime.getText();
		System.out.println("DepartureTimeValueUpwards= "+ DepartureTimeValueUpwards);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", DepartureTime);
		if(DepartureTimeValueUpwards !=null){
        	//cl.log.info("DepartureTime -->"+ DepartureTimeValueUpwards);
            //cl.ActualTestDataValue = "Drag port upwards DepartureTime";
    	    //cl.result("Verifyed, DepartureTime= "+ DepartureTimeValueUpwards, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement BerthTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]//td[19]//div[@class='clickable']//p"));
		String	BerthTimeValueUpwards = BerthTime.getText();
		System.out.println("BerthTimeValueUpwards= "+ BerthTimeValueUpwards);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", BerthTime);
		if(BerthTimeValueUpwards !=null){
        	//cl.log.info("BerthTime -->"+ BerthTimeValueUpwards);
            //cl.ActualTestDataValue = "Drag port upwards BerthTime";
    	    //cl.result("Verifyed, BerthTime= "+ BerthTimeValueUpwards, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement UnberthTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[2]//td[20]//div[@class='clickable']//p"));
		String	UnberthTimeValueUpwards = UnberthTime.getText();
		System.out.println("UnberthTimeValueUpwards= "+ UnberthTimeValueUpwards);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", UnberthTime);
		if(UnberthTimeValueUpwards !=null){
        	//cl.log.info("UnberthTime -->"+ UnberthTimeValueUpwards);
            //cl.ActualTestDataValue = "Drag port upwards UnberthTime";
    	    //cl.result("Verifyed, UnberthTime= "+ UnberthTimeValueUpwards, "" , "Pass", "", 1, "VERIFY");
       }
		/*
	   driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons'])[1]"));
	   
	   WebElement Drag3 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		System.out.println(Drag3.getLocation());
		Thread.sleep(4000);
		for (int i = 0; i < 3; i++) {
			actions.clickAndHold(Drag3).moveByOffset(10, 30).release().build().perform();
		}
		
		driver.findElement(By.xpath("//i[@class='q-icon notranslate material-icons readMoreIcon icon']")).click();
		Thread.sleep(4000);
		WebElement SeaTimeA = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[2]//td[15]"));
		String	SeaTimeValueA = SeaTimeA.getText();
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", SeaTimeA);
		if(SeaTimeA !=null){
        	cl.log.info("AfterSeaTime -->"+ SeaTimeValueA);
            cl.ActualTestDataValue = "After SeaTime";
    	    cl.result("Verifyed, SeaTime= "+ SeaTimeValueA, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement ArrivalTimeA = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[1]//td[19]//div[@class='clickable']//p"));
		String	ArrivalTimeValueUpwardsA = ArrivalTimeA.getText();
		System.out.println("ArrivalTimeValueDownwardsA= "+ ArrivalTimeValueUpwardsA);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ArrivalTimeA);
		if(ArrivalTimeValueUpwardsA !=null){
        	cl.log.info("ArrivalTime -->"+ ArrivalTimeValueUpwardsA);
            cl.ActualTestDataValue = "Drag port downwards ArrivalTime";
    	    cl.result("Verifyed, ArrivalTime= "+ ArrivalTimeValueUpwardsA, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement DepartureTimeA = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'])[1]//td[22]//div[@class='clickable']//p"));
		String	DepartureTimeValueUpwardsA = DepartureTimeA.getText();
		System.out.println("DepartureTimeValueUpwards= "+ DepartureTimeValueUpwardsA);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", DepartureTimeA);
		if(DepartureTimeValueUpwardsA !=null){
        	cl.log.info("DepartureTime -->"+ DepartureTimeValueUpwardsA);
            cl.ActualTestDataValue = "Drag port downwards DepartureTime";
    	    cl.result("Verifyed, DepartureTime= "+ DepartureTimeValueUpwardsA, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement BerthTimeA = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[19]//div[@class='clickable']//p"));
		String	BerthTimeValueUpwardsA = BerthTimeA.getText();
		System.out.println("BerthTimeValueUpwards= "+ BerthTimeValueUpwardsA);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", BerthTimeA);
		if(BerthTimeValueUpwardsA !=null){
        	cl.log.info("After BerthTime -->"+ BerthTimeValueUpwardsA);
            cl.ActualTestDataValue = "Drag port downwards BerthTime";
    	    cl.result("Verifyed, BerthTime= "+ BerthTimeValueUpwardsA, "" , "Pass", "", 1, "VERIFY");
       }
		WebElement UnberthTimeA = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered'])[1]//td[20]//div[@class='clickable']//p"));
		String	UnberthTimeValueUpwardsA = UnberthTimeA.getText();
		System.out.println("UnberthTimeValueUpwards= "+ UnberthTimeValueUpwards);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", UnberthTimeA);
		if(UnberthTimeValueUpwardsA !=null){
        	cl.log.info("UnberthTime -->"+ UnberthTimeValueUpwardsA);
            cl.ActualTestDataValue = "Drag port downwards UnberthTime";
    	    cl.result("Verifyed, UnberthTime= "+ UnberthTimeValueUpwardsA, "" , "Pass", "", 1, "VERIFY");
       }
		if(SeaTimeValueA.equals(SeaTimeValue)){
        	cl.log.info("SeaTime Drag Port upwards and downwards-->"+ SeaTimeValueA);
            cl.ActualTestDataValue = "SeaTime Drag Port upwards and downwards";
    	    cl.result("Verifyed, SeaTime Drag Port upwards and downwards are same"+ SeaTimeValueA, "" , "Pass", "", 1, "VERIFY");
       }else {
    	   cl.log.info("SeaTime Drag Port upwards and downwards-->"+ SeaTimeValueA);
           cl.ActualTestDataValue = "SeaTime Drag Port upwards and downwards";
   	    cl.result("Verifyed, SeaTime Drag Port upwards and downwards are same"+ SeaTimeValueA, "" , "Fail", "", 1, "VERIFY");
       }*/
	}
}
