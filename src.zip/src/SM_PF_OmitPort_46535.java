import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_PF_OmitPort_46535 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);
		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(7000);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("ALS KRONOS");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
		Actions actions = new Actions(driver);
		
		WebElement Lane = driver.findElement(By.xpath("(((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]//div[@class='timing'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);

		WebElement OmitPort = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[@class='q-item q-item-type row no-wrap q-item--clickable q-link cursor-pointer q-focusable q-hoverable item'])[1]//div[@class='q-item__section column q-item__section--main justify-center header']"));
		OmitPort.click();
		Thread.sleep(4000);
		
		WebElement OmitAlert = driver.findElement(By.xpath("//div[@class='modal']//div[@class=\"q-field__control-container col relative-position row no-wrap q-anchor--skip\"]//input"));
		OmitAlert.click();
		OmitAlert.sendKeys("first");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		WebElement remarkinput = driver.findElement(By.xpath("//div//textarea"));
		remarkinput.sendKeys("This is");
		Thread.sleep(4000);
		driver.findElement(By.xpath("(//button[@class=\"q-btn q-btn-item non-selectable no-outline q-btn--standard q-btn--rectangle q-btn--actionable q-focusable q-hoverable\"])[2]")).click();
		
		WebElement Colorverification = driver.findElement(By.xpath("((((//div[@id='block'])[1]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[1])//div[@class='timing'])[2]//div[@class='indicator-container isOmitted']"));
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String script = "return window.getComputedStyle(arguments[0], ':before').getPropertyValue('background-color')";
        String FetchValue = (String) jsExecutor.executeScript(script, Colorverification);
        System.out.println(FetchValue);
        
        String expected_color="rgb(203, 60, 68)";
        if(expected_color.equals(FetchValue)){
        	System.out.println("Color Verification Pass" + FetchValue);
            //cl.ActualTestDataValue = "Color Code";
    	    //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Pass", "", 1, "VERIFY");
       }else {
    	   System.out.println("Color Verification Pass" + FetchValue);
    	   //cl.ActualTestDataValue = "Color Code";
   	       //cl.result("Verifyed, Red dot indicator is displayed in long term"+ FetchValue, "" , "Fail", "", 1, "VERIFY");
       }
        
	}
				
}
