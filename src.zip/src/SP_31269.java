import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class SP_31269 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Schedule Publishing')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(9000);
		
		driver.findElement(By.xpath(
				"(//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Add service']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(
				"//th[text()=' Select Service Code ( ']/div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Add Service Codes']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//i[text()='expand_more'])[3]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//a[contains(text(), 'ANBIEN BAY')])[2]")).click();
		Thread.sleep(5000);
		boolean ChangeTerminalSettingstrue3 = false;
		List<WebElement> R_button = driver.findElements(By.xpath("//tr[@class='terminal-row'][1]//div[@class='q-radio cursor-pointer no-outline row inline no-wrap items-center' and @role]"));
		System.out.println("Size " + R_button.size());
		for (int i = 0; i < R_button.size(); i++) {
			if(R_button.get(i).getAttribute("aria-checked").contains("true")) {
				System.out.println("Size " + i);
				R_button.get((i+1)).click();
				ChangeTerminalSettingstrue3  = R_button.get((i+1)).getAttribute("aria-checked").contains("true");
				System.out.println(ChangeTerminalSettingstrue3);	
				break;
			}
			else if(i==2)
			{
				R_button.get((i-1)).click();
				break;
			}
		}
		/*WebElement SaveButton = driver.findElement(By.xpath("(//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row'])[3]"));
		SaveButton.click();
		driver.findElement(By.xpath("(//i[text()='expand_more'])[1]")).click();
		driver.findElement(By.xpath("(//i[text()='expand_more'])[3]")).click();
		driver.findElement(By.xpath("(//a[contains(text(), 'ALGOL')])[1]")).click();*/
		
		if (ChangeTerminalSettingstrue3==true) {
			System.out.println("Verifyed, Changed The Subscription Settings = "+ ChangeTerminalSettingstrue3);
			 //cl.ActualTestDataValue = "Subscription Settings";
        	//cl.result("Verifyed Changed The Subscription Settings "+ChangeTerminalSettingstrue3, "", "Pass", "31269", 1, "Verify");
		}
		else {
			System.out.println("Not Verifyed, changed The Subscription Settings = "+ ChangeTerminalSettingstrue3);
			//cl.ActualTestDataValue = "Subscription Settings";
        	//cl.result("Not Verifyed Changed The Subscription Settings "+ChangeTerminalSettingstrue3, "", "Fail", "31269", 1, "Verify");
		}
		
		
	}
}
