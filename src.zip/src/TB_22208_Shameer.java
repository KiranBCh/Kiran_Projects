import java.awt.AWTException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TB_22208_Shameer {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		Object inputFormatter;
		/*
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='btnLoadExistingSchedule']//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("((//div[@class='q-tree__children']//div[@class='q-tree__node-collapsible'])[1]//div[@class='q-tree__children']//div//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense q-tree__tickbox'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),'Load RC')]")).click();
		Thread.sleep(3000);
		
		WebElement ScheduleHeader = driver.findElement(By.xpath("//div[@class='schedulHeaderText']"));
		boolean ScheduleHeaderStatus = ScheduleHeader.isDisplayed();
		if (ScheduleHeaderStatus) {
			System.out.println("Verify that selected template is displayed in schedule lane-->"+ScheduleHeaderStatus);
			//cl.result("Verifiyed that selected template is displayed in schedule lane", "", "Pass", "", 1,  "VERIFY");
		} else {
			System.out.println("Verify that selected template is displayed in schedule lane-->"+ScheduleHeaderStatus);
			//cl.result("Verifiyed that selected template is displayed in schedule lane", "", "Fail", "", 1,  "VERIFY");
		}
		driver.findElement(By.xpath("//i[normalize-space()='read_more']")).click();
		Thread.sleep(9000);
		
		WebElement SaveButton = driver.findElement(By.xpath("//button[@id='btnSaveLocal']"));
		boolean SaveButtonStatus = SaveButton.getAttribute("aria-disabled").contains("true");
		if (SaveButtonStatus) {
			System.out.println("Save Button Not Visible in View Only Access-->"+ SaveButtonStatus);
			//cl.result("Save Button Not Visible and Click in View Only Access", "", "Pass", "", 1,  "VERIFY");
		} else {
			System.out.println("Save Button is Visible in View Only Access");
			//cl.result("Save Button is Visible and Click in View Only Access", "", "Fail", "", 1,  "VERIFY");
		}
		} 
	*/
		Date inputDate = inputFormatter.parse(inputDateString);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(inputDate);
        int updateWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int updateMonth = calendar.get(Calendar.MONTH);
	}
}
