import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.eo.Do;

public class SM_Manual_38081 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		driver.navigate().refresh();
		Thread.sleep(3000);
		String response = driver.getPageSource();
		System.out.println("response--->"+response);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		String response1 = driver.getPageSource();
		System.out.println("response--->"+response1);
		Set<Cookie> cookies = driver.manage().getCookies();
		for (Cookie cookie : cookies) {
            System.out.println("Cookie Name: " + cookie.getName());
            System.out.println("Cookie Value: " + cookie.getValue());
            System.out.println("Domain: " + cookie.getDomain());
            System.out.println("Path: " + cookie.getPath());
            System.out.println("Expiry: " + cookie.getExpiry());
            System.out.println("Secure: " + cookie.isSecure());
            System.out.println("HttpOnly: " + cookie.isHttpOnly());
            System.out.println("----------");
        }
		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		/*
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		//Actions actions = new Actions(driver);
		Thread.sleep(3000);
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("ALS KRONOS");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(5000);
		WebElement CLickPortTerminal = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		CLickPortTerminal.click();
		Thread.sleep(3000);
		WebElement CLickPortTermina2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		CLickPortTermina2.click();
		Thread.sleep(3000);
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement SeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[2]//td[22]"));
        String SeaTimeValue = SeaTime.getText();
        if (SeaTimeValue == "" || SeaTimeValue.isEmpty()){
			System.out.println("SeaTime Pass " + SeaTimeValue);
            //cl.ActualTestDataValue = "Sea Time Blank";
	        //cl.result("Verifyed,  Sea Time Blank "+ SeaTimeValue, "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println("SeaTime Fail " + SeaTimeValue);
            //cl.ActualTestDataValue = "Sea Time Blank";
	        //cl.result("Not Verifyed,  Sea Time Blank "+ SeaTimeValue, "" , "Fail", "38081", 1, "VERIFY");
        }
        
        WebElement Distance = driver.findElement(By.xpath("//th[normalize-space()='Distance (NM)']//following::tr[2]//td[19]"));
        String DistanceValue = Distance.getText();
        if (DistanceValue == "" || DistanceValue.isEmpty()) {
        	System.out.println("Distance Pass" + DistanceValue);
            //cl.ActualTestDataValue = "Distance Blank";
	        //cl.result("Verifyed,  Distance Blank "+ DistanceValue, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("Distance Fail " + DistanceValue);
            //cl.ActualTestDataValue = "Distance Blank";
	        //cl.result("Not Verifyed,  Distance Blank "+ DistanceValue, "" , "Fail", "38081", 1, "VERIFY");
        }
        WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[42]"));
        int pilotInText = Integer.parseInt(PilotIn.getText());
        if (pilotInText == 1) {
        	System.out.println("PilotIn Pass " + pilotInText);
            //cl.ActualTestDataValue = "Pilot In ";
	        //cl.result("Verifyed,  Pilot In "+ pilotInText, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("PilotIn Fail " + pilotInText);
            //cl.ActualTestDataValue = "Pilot In ";
	        //cl.result("Not Verifyed,  Pilot In "+ pilotInText, "" , "Fail", "38081", 1, "VERIFY");
        }
        WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[44]"));
        int PilotOutText = Integer.parseInt(PilotOut.getText());
        if (PilotOutText == 1) {
        	System.out.println("PilotOut Pass " + PilotOutText);
            //cl.ActualTestDataValue = "Pilot Out ";
	        //cl.result("Verifyed,  Pilot Out "+ PilotOutText, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("PilotOut Fail " + PilotOutText);
            //cl.ActualTestDataValue = "Pilot Out ";
	        //cl.result("Not Verifyed,  Pilot Out "+ PilotOutText, "" , "Fail", "38081", 1, "VERIFY");
        }
        WebElement PortStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[23]"));
        int PortStayText = Integer.parseInt(PortStay.getText());
        if (PortStayText == 12) {
        	System.out.println("Port Stay Pass " + PortStayText);
            //cl.ActualTestDataValue = "Port Stay ";
	        //cl.result("Verifyed,  Port Stay "+ PortStayText, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("Port Stay Fail " + PortStayText);
            //cl.ActualTestDataValue = "Port Stay ";
	        //cl.result("Not Verifyed,  Port Stay "+ PortStayText, "" , "Fail", "38081", 1, "VERIFY");
        }
     
        WebElement TerminalStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[22]"));
        int TerminalStayText = Integer.parseInt(TerminalStay.getText());
        if (TerminalStayText == 10) {
        	System.out.println("Terminal Stay Pass " + TerminalStayText);
            //cl.ActualTestDataValue = "Terminal Stay ";
	        //cl.result("Verifyed,  Terminal Stay "+ TerminalStayText, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("Terminal Stay Pass " + TerminalStayText);
            //cl.ActualTestDataValue = "Terminal Stay ";
	        //cl.result("Not Verifyed,  Terminal Stay "+ TerminalStayText, "" , "Fail", "38081", 1, "VERIFY");
        }
        List<WebElement> TerminalOperationsTime = driver.findElements(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[23]//input"));
        String TerminalOperationsTimeValue = "";
		for(WebElement value : TerminalOperationsTime) {
			if(value.getAttribute("value") != null) {				
				TerminalOperationsTimeValue = value.getAttribute("value");
				break;
			}
		}
		int TerminalOperationsTimeValueint = Integer.parseInt(TerminalOperationsTimeValue);
        if (TerminalOperationsTimeValueint == 8) {
        	System.out.println("Terminal Operations Time Pass " + TerminalOperationsTimeValue);
            //cl.ActualTestDataValue = "Terminal Operations Time ";
	        //cl.result("Verifyed,  Terminal Operations Time "+ TerminalOperationsTimeValue, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("Terminal Operations Time Fail " + TerminalOperationsTimeValue);
            //cl.ActualTestDataValue = "Terminal Operations Time ";
	        //cl.result("Not Verifyed,  Terminal Operations Time "+ TerminalOperationsTimeValue, "" , "Fail", "38081", 1, "VERIFY");
        }
        WebElement ArrivalTime = driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']//following::tr[1]//td[30]"));
        String ArrivalTimeValue = ArrivalTime.getText();
        if (ArrivalTimeValue != null) {
        	System.out.println("ArrivalTime Pass " + ArrivalTimeValue);
            //cl.ActualTestDataValue = "Arrival Time ";
	        //cl.result("Verifyed,  Arrival Time "+ ArrivalTimeValue, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("ArrivalTime Fail " + ArrivalTimeValue);
            //cl.ActualTestDataValue = "Arrival Time ";
	        //cl.result("Not Verifyed,  Arrival Time "+ ArrivalTimeValue, "" , "Fail", "38081", 1, "VERIFY");
        }
        WebElement DapartureTime = driver.findElement(By.xpath("//th[normalize-space()='Departure Time']//following::tr[1]//td[33]"));
        String DapartureTimeValue = DapartureTime.getText();
        if (DapartureTimeValue != null) {
        	System.out.println("Daparture Time Pass " + DapartureTimeValue);
            //cl.ActualTestDataValue = "Daparture Time ";
	        //cl.result("Verifyed,  Daparture Time "+ DapartureTimeValue, "" , "Pass", "38081", 1, "VERIFY");
        }
        else {
        	System.out.println("Daparture Time Fail " + DapartureTimeValue);
            //cl.ActualTestDataValue = "Daparture Time ";
	        //cl.result("Not Verifyed,  Daparture Time "+ DapartureTimeValue, "" , "Fail", "38081", 1, "VERIFY");
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE dd MMM yyyy HH:mm");
        LocalDateTime originalDateTime = LocalDateTime.parse(ArrivalTimeValue, formatter);
        LocalDateTime newDateTime = originalDateTime.plusHours(PortStayText);
        //String result = newDateTime.format(formatter);
        String DepartureTimeCalculation = newDateTime.format(formatter);
        //System.out.println("Original Date and Time: " + originalDateTime.format(formatter));
        //System.out.println("New Date and Time (+12 hours): " + result);
        //LocalDateTime date2DapartureTimeValue = LocalDateTime.parse(DapartureTimeValue, formatter);
        boolean isEqual = DepartureTimeCalculation.equals(DapartureTimeValue);
        if (isEqual){
        	System.out.println("Daparture Time + Port Stay Pass" + DapartureTimeValue);
            //cl.ActualTestDataValue = "Daparture Time Calculation ";
	        //cl.result("Verifyed,  Arrival Time "+ ArrivalTimeValue + " Port Stay "+PortStayText, "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println("Daparture Time + Port Stay Fail" + DapartureTimeValue);
            //cl.ActualTestDataValue = "Daparture Time Calculation ";
	        //cl.result("Not Verifyed,  Arrival Time "+ ArrivalTimeValue + " Port Stay "+PortStayText, "" , "Fail", "38081", 1, "VERIFY");
        }
        //Berth Time =Arrival Time + Pilot in Time
        WebElement BerthTime = driver.findElement(By.xpath("//th[normalize-space()='Berth Time']//following::tr[2]//td[30]"));
        String BerthTimeValue = BerthTime.getText();
        LocalDateTime originalDateTimeBer = LocalDateTime.parse(BerthTimeValue, formatter);
        LocalDateTime newDateTimePilotIn = originalDateTimeBer.plusHours(pilotInText);
        String BerthTimeCalculation = newDateTimePilotIn.format(formatter);
        boolean isEqual1 = BerthTimeCalculation.equals(BerthTimeValue);
        if (isEqual1){
        	System.out.println("Arrival Time + Pilot in Time Pass" + DapartureTimeValue);
            //cl.ActualTestDataValue = "Berth Time Calculation ";
	        //cl.result("Verifyed,  Arrival Time "+ ArrivalTimeValue + " Pilot In "+ pilotInText, "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println("Arrival Time + Pilot in Time Fail" + DapartureTimeValue);
            //cl.ActualTestDataValue = "Berth Time Calculation ";
	        //cl.result("Not Verifyed,  Arrival Time "+ ArrivalTimeValue + " Pilot In "+ pilotInText, "" , "Fail", "38081", 1, "VERIFY");
        }
        //Unberth Time=Departure - Pilot out Time
        WebElement UnberthTime = driver.findElement(By.xpath("//th[normalize-space()='Berth Time']//following::tr[2]//td[31]"));
        String UnberthTimeValue = UnberthTime.getText();
        LocalDateTime originalDateTimeUnber = LocalDateTime.parse(DapartureTimeValue, formatter);
        LocalDateTime newDateTimePilotOut = originalDateTimeUnber.minusHours(PilotOutText);
        String UnBerthTimeCalculation = newDateTimePilotOut.format(formatter);
        boolean isEqual2 = UnBerthTimeCalculation.equals(UnberthTimeValue);
        if (isEqual2){
        	System.out.println(" Departure - Pilot out Time Pass" + UnBerthTimeCalculation);
            //cl.ActualTestDataValue = "UnBerth Time Calculation ";
	        //cl.result("Verifyed,  Departure Time "+ DapartureTimeValue + " Pilot Out "+ PilotOutText, "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println("Departure Time + Pilot Out Time Fail" + UnBerthTimeCalculation);
            //cl.ActualTestDataValue = "UnBerth Time Calculation ";
	        //cl.result("Not Verifyed,  Departure Time "+ DapartureTimeValue + " Pilot Out "+ PilotOutText, "" , "Fail", "38081", 1, "VERIFY");
        }
        //Port Buffer Time = Pilot In + Pilot Out + Shifting Time
        WebElement PortBufferTime = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[25]"));
        String PortBufferTimeValue = PortBufferTime.getText();
        int PortBufferTimeValueOrg = Integer.parseInt(PortBufferTimeValue);
        int PortBufferTimeCal = pilotInText + PilotOutText + 0;
        if (PortBufferTimeValueOrg == PortBufferTimeCal){
        	System.out.println(" Pilot In + Pilot Out + Shifting Time " + PortBufferTimeCal);
            //cl.ActualTestDataValue = "Port Buffer Time Calculation ";
	        //cl.result("Verifyed, Pilot In "+ pilotInText + " Pilot Out "+ PilotOutText + "Shifting Time", "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println(" Pilot In + Pilot Out + Shifting Time " + PortBufferTimeCal);
            //cl.ActualTestDataValue = "Port Buffer Time Calculation ";
	        //cl.result("Not Verifyed, Pilot In "+ pilotInText + " Pilot Out "+ PilotOutText + "Shifting Time", "" , "Fail", "38081", 1, "VERIFY");
        }
        //Terminal Buffer Time = Terminal Stay - Terminal Operations Time
        WebElement TerminalBufferTime = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[3]//td[24]"));
        String TerminalBufferTimeValue = TerminalBufferTime.getText();
        int TerminalBufferTimeValueOrg = Integer.parseInt(TerminalBufferTimeValue);
        int TerminalOperationsTimeValueCl = Integer.parseInt(TerminalOperationsTimeValue);
        int TerminalBufferTimeCal = TerminalStayText - TerminalOperationsTimeValueCl;
        if (TerminalBufferTimeValueOrg == TerminalBufferTimeCal){
        	System.out.println(" Terminal Stay - Terminal Operations Time " + TerminalBufferTimeCal);
            //cl.ActualTestDataValue = "Terminal Buffer Time Calculation ";
	        //cl.result("Verifyed, Terminal Stay "+ TerminalStayText + " Terminal Operations Time "+ TerminalOperationsTimeValue, "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println(" Terminal Stay - Terminal Operations Time " + TerminalBufferTimeCal);
            //cl.ActualTestDataValue = "Terminal Buffer Time Calculation ";
	        //cl.result("Verifyed, Terminal Stay "+ TerminalStayText + " Terminal Operations Time "+ TerminalOperationsTimeValue, "" , "Fail", "38081", 1, "VERIFY");
        }
        //Speed =12
        //Distance = Sea Time * Speed
        List<WebElement> DistanceGet = driver.findElements(By.xpath("//th[normalize-space()='Distance (NM)']//following::tr[4]//td[19]//input"));
		String DistanceAfterValue = "";
		for(WebElement value : DistanceGet) {
			if(value.getAttribute("value") != null) {				
				DistanceAfterValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> Speed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td[21]//input"));
		String SpeedAfterValue = "";
		for(WebElement value : Speed) {
			if(value.getAttribute("value") != null) {				
				SpeedAfterValue = value.getAttribute("value");
				break;
			}
		}
		WebElement beforeSeaTimeCal = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[22]"));
		String beforeSeaTimeCalVal = beforeSeaTimeCal.getText();
		//long beforeSeaTimeCalValcon = Long.parseLong(beforeSeaTimeCalVal);
		double DistanceCal1 = Double.valueOf(DistanceAfterValue);
		//double AfterSeatimeValueCa11 = Double.valueOf(SpeedAfterValue);
		double beforeSeaTimeCalVal1 = Double.valueOf(beforeSeaTimeCalVal);
		//double SpeedCalculation = (DistanceCal1) / (AfterSeatimeValueCa11);
		//double final_cal = Math.round(SpeedCalculation);
		double DistanceCal = beforeSeaTimeCalVal1 * 12;
		if (DistanceCal1 == DistanceCal){
        	System.out.println("Sea Time * Speed " + PortBufferTimeCal);
            //cl.ActualTestDataValue = "Distance Calculation ";
	        //cl.result("Verifyed, Sea Time "+ beforeSeaTimeCalVal + " Speed 12", "" , "Pass", "38081", 1, "VERIFY");
        }else {
        	System.out.println("Sea Time * Speed " + PortBufferTimeCal);
            //cl.ActualTestDataValue = "Distance Calculation ";
	        //cl.result("Not Verifyed, Sea Time "+ beforeSeaTimeCalVal + " Speed 12", "" , "Fail", "38081", 1, "VERIFY");
        }
        */
  }
}
