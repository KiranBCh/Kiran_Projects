import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SP_32229 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Schedule Publishing')]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(9000);
			
		WebElement BusinessPartner = driver.findElement(By.xpath("((//div[@class='q-tree__node relative-position q-tree__node--parent'])[1]//i[@class='q-icon notranslate material-icons q-tree__arrow'])[1]"));
		BusinessPartner.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", BusinessPartner);
		Thread.sleep(3000);
		WebElement Service = driver.findElement(By.xpath("((//div[@class='q-tree__node relative-position q-tree__node--parent'])[1]//i[@class='q-icon notranslate material-icons q-tree__arrow'])[1]"));
		Service.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", Service);
		Thread.sleep(3000);
		WebElement Vessels = driver.findElement(By.xpath("(//div[@style='cursor: pointer;'])[1]//a[@class='disabled']"));
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid yellow')", Vessels);
		
		//Destru
		WebElement ServiceD = driver.findElement(By.xpath("//div[@class='q-tree__children']//i[@class='q-icon notranslate material-icons q-tree__arrow q-tree__arrow--rotate']"));
		ServiceD.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid Red')", ServiceD);
		Thread.sleep(3000);
		
		WebElement BusinessPartnerD = driver.findElement(By.xpath("(//div[@class='q-tree__node relative-position q-tree__node--parent']//i[@class='q-icon notranslate material-icons q-tree__arrow q-tree__arrow--rotate'])[1]"));
		BusinessPartnerD.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:4px solid Red')", BusinessPartnerD);
		Thread.sleep(3000);
	}
}
