import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_32238_Week_day_increa {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		List<WebElement> week = driver.findElements(By.xpath("//div[@class='weekColumn']//div[@class='weekBlock']"));
		int count = 0;
		int weeksize = week.size();
		String  weekheightValue = "";
		String  weekwidthValue = "";
		for (WebElement webElement : week) {
			weekheightValue = webElement.getCssValue("height");
			weekwidthValue = webElement.getCssValue("width");
			System.out.println("Width--->"+weekwidthValue);
			System.out.println("Height--->"+weekheightValue);
	    	js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    	if((weekheightValue.equals("840px"))&&(weekwidthValue.equals("42.5px"))) {
	    		count++;
	    		cl.ActualTestDataValue = "Week";
	    		cl.result("Verifyed, week Height= " +weekheightValue + "Width= "+weekwidthValue, "" , "Pass", "", 1, "VERIFY");
	    	}else {
	    		cl.ActualTestDataValue = "Week";
	    		cl.result("Verifyed, week Height= " +weekheightValue + "Width= "+weekwidthValue, "" , "Fail", "", 1, "VERIFY");
	    	}
		}
		/*
		if(count==weeksize)
		{
			System.out.println("All are Same Width and Height");
		}*/
		
		List<WebElement> day = driver.findElements(By.xpath("//div[@class='dayColumn']//div[@class='dayBlock']"));
		int count1 = 0;
		int daysize = day.size();
		String daywidthValue = "";
		for (WebElement webElement : day) {
			//dayheightValue = webElement.getCssValue("height");
			daywidthValue = webElement.getCssValue("width");
			System.out.println("Width--->"+daywidthValue);
			//System.out.println("Height--->"+dayheightValue);
	    	js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", webElement);
	    	if(daywidthValue.equals("42.5px")) {
	    		count1++;
	    		//cl.ActualTestDataValue = "Day";
	    		//cl.result("Verifyed, Day= "+ daywidthValue, "" , "Pass", "", 1, "VERIFY");
	    	}else {
	    		//cl.ActualTestDataValue = "Day";
	    		//cl.result("Verifyed, Day= "+ daywidthValue, "" , "Fail", "", 1, "VERIFY");
	    	}	
		}
	    
 	}
}
