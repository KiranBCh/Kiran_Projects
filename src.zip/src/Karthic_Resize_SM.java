import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Karthic_Resize_SM {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
	WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
	Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

	Thread.sleep(5000);
	WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
	Pass.sendKeys("Alumni@2023");
	Thread.sleep(5000);
	WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
	Signin.click();

	Actions action = new Actions(driver);

	Thread.sleep(9000);
	driver.navigate().refresh();
	Thread.sleep(9000);
	// *********** Home Page ******************//

	WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
	JavascriptExecutor je = (JavascriptExecutor) driver;
	je.executeScript("arguments[0].click();", Services);
	Thread.sleep(10000);

	WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
	newSailing.click();
	Thread.sleep(8000);

	WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
	profomaname.click();
	Thread.sleep(5000);

	WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
	TxtboxProfoma.sendKeys("DontDeleteActiveTemplate");
	Thread.sleep(4000);

	WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'DontDeleteActiveTemplate')]"));
	VerifyProfoma.click();
	Thread.sleep(3000);

	WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
	Clickves.click();
	Clickves.sendKeys("KMTC NINGBO (KMNGB 9626405)");
	Thread.sleep(5000);
	Robot robot = new Robot();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(3000);

	WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
	Thread.sleep(2000);
	Operator.click();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	Thread.sleep(1000);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	Thread.sleep(1000);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(4000);

//	WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
//	Cycle.click();
//	Cycle.sendKeys("5");
//	Thread.sleep(3000);
//
//	WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
//	Vesselpos.click();
//	Vesselpos.sendKeys("4");
//	Thread.sleep(3000);

	WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
	Characters.click();
	Thread.sleep(3000);
	robot.keyPress(KeyEvent.VK_BACK_SPACE);
	robot.keyRelease(KeyEvent.VK_BACK_SPACE);
	Characters.sendKeys("7");
	Thread.sleep(3000);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(3000);

	WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
	StartingNum.click();
	StartingNum.sendKeys("2");
	Thread.sleep(3000);

	WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
	Prefix.sendKeys("HH");
	Thread.sleep(3000);

	WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
	Suffix.sendKeys("20");
	Thread.sleep(3000);

	WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
	Generate.click();
	Thread.sleep(8000);

	for (int i = 0; i <6; i++) {
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_SUBTRACT);
		robot.keyRelease(KeyEvent.VK_SUBTRACT);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	driver.findElement(By.xpath("(//i[text()='edit'])[1]")).click();
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("(//span[text()='CONFIRM'])[1]")).click();
	Thread.sleep(3000);
	Actions actions = new Actions(driver);
	WebElement Port2 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[2]"));
	//action.moveToElement(Port2).perform();
	Port2.click();
	System.out.println(Port2.getLocation());
	Thread.sleep(3000);
	actions.clickAndHold(Port2).moveByOffset(10, 30).release().build().perform();
	//actions.clickAndHold(Port2).moveByOffset(10, 30).release().build().perform();
	/*
	WebElement Port3 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[3]"));
	action.moveToElement(Port3).perform();
	Thread.sleep(3000);
	
	for (int i = 0; i <= 10; i++) {
		action.clickAndHold(Port2).moveByOffset(10, 70).release().build().perform();
	}*/
	
	
}
}
