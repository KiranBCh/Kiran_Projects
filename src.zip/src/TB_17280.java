import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_17280 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(9000);
		driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']")).click();
		Thread.sleep(9000);
		Thread.sleep(9000);
		Thread.sleep(9000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Robot robot = new Robot();
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort.click();		
		Thread.sleep(3000);
		AddPort.sendKeys("BDCGP");
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddPort);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		for (int i = 0; i <= 3 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
				
		WebElement SelectTerminal = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectTerminal.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[@id='btnAddTerminal']")).click();
		Thread.sleep(3000);

		WebElement AddTerminalName = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='highlight data-table__sub-td']//input)[1]"));
		AddTerminalName.click();
		Thread.sleep(3000);
		AddTerminalName.sendKeys("CGP");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName);
		
		WebElement AddTerminalName2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='highlight data-table__sub-td']//input)[1]"));
		AddTerminalName2.click();
		Thread.sleep(3000);
		AddTerminalName2.sendKeys("CCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", AddTerminalName2);
				
		WebElement UnSelectPort = driver.findElement(By.xpath("//tr[@class='data-table__port-row selected-row']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		UnSelectPort.click();
		Thread.sleep(3000);
		
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Unberth Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
		
		WebElement SelectTerminal1 = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//div[@class='data-table__sub-td']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
		SelectTerminal1.click();
		Thread.sleep(3000);
		
		WebElement unSelect1Terminal = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//div[@class='data-table__sub-td']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense']"));
	    unSelect1Terminal.click();
	    Thread.sleep(3000);
	       
		WebElement ChangeArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p"));
		ChangeArrivalTime.click();
		Thread.sleep(3000);
		WebElement ChangeArrivalT = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']//option[@value='14']"));
		ChangeArrivalT.click();
		Actions actions = new Actions(driver);
		actions.moveToElement(ChangeArrivalT).doubleClick().perform();
		Thread.sleep(3000);
		WebElement OutsideClick = driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']"));
		OutsideClick.click();
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ChangeArrivalTime);
		
		WebElement PortStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[16]"));
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement TerminalStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[15]"));
		js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", ChangeArrivalTime);
		String PortStayText = PortStay.getText();
		String pilotInText = PilotIn.getText();
		String TerminalStayText = TerminalStay.getText();
		
		int pilotInValue = Integer.parseInt(pilotInText);
		int PortStayValue = Integer.parseInt(PortStayText);
		int TerminalStayValue = Integer.parseInt(TerminalStayText);
		//System.out.println("PilotIn= " + pilotInText + " PilotOut= " + pilotOutText + " TerminalStay= "+TerminalStayText);
		//1. New Departure = new Arrival + Port Stay
		WebElement ScrollRight1 = driver.findElement(By.xpath("//th[normalize-space()='Departure Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight1);
		WebElement DepartureTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[22]//div[@class='clickable']//p"));
		String DepartureTimeValue = DepartureTime.getText();
		Thread.sleep(3000);
		WebElement AfterArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p"));
		String AfterArrivalTimeValue = AfterArrivalTime.getText();
		Thread.sleep(3000);
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
		Date date1 = dateFormat.parse(AfterArrivalTimeValue);
		Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(Calendar.HOUR_OF_DAY, PortStayValue);
        Date newDate = calendar.getTime();
        String result = dateFormat.format(newDate);
        if (DepartureTimeValue.equals(result)) {
        	System.out.println("1.DepartureTime Calculate in hours: " + result + " result");
		   	//cl.log.info("New Departure = new Arrival + Port Stay -->"+ result);
	        //cl.ActualTestDataValue = "new Arrival and Port Stay";
	    	//cl.result("Verified, New Arrival Time = "+ AfterArrivalTimeValue + " Port Stay= " + PortStayText+ " Departure Time= "+DepartureTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Departure = new Arrival + Port Stay -->"+ result);
	        //cl.ActualTestDataValue = "new Arrival and Port Stay";
	    	//cl.result("Verified, New Arrival Time = "+ AfterArrivalTimeValue + " Port Stay= " + PortStayText+ " Departure Time= "+DepartureTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
       //2. New Berth Time of first terminal = new Arrival Time + Pilot In
        Thread.sleep(3000);
        WebElement BirthTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='clickable'])[1]"));
        String BirthTimeValue = BirthTime.getText();
        Date date2 = dateFormat.parse(AfterArrivalTimeValue);
        calendar.setTime(date2);
        calendar.add(Calendar.HOUR_OF_DAY, pilotInValue);
        Date newDate2 = calendar.getTime();
        String result2 = dateFormat.format(newDate2);
        if (BirthTimeValue.equals(result2)) {
        	System.out.println("2.BerthTime Calculate in hours: " + result2 + " result");
		   	//cl.log.info("New Berth Time of first terminal = new Arrival Time + Pilot In -->"+ result2);
	        //cl.ActualTestDataValue = "new Arrival Time and Pilot In";
	    	//cl.result("Verified, New Arrival Time = "+ AfterArrivalTimeValue + " Pilot In= " + pilotInText+ " BirthTime= "+BirthTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Berth Time of first terminal = new Arrival Time + Pilot In -->"+ result2);
	        //cl.ActualTestDataValue = "new Arrival Time and Pilot In";
	    	//cl.result("Verified, New Arrival Time = "+ AfterArrivalTimeValue + " Pilot In= " + pilotInText+ " BirthTime= "+BirthTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
        //3.New Unberth Time of first terminal = new Berth Time + Terminal Stay
        WebElement UnBirthTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[20]//div[@class='clickable'])[1]"));
        String UnBirthTimeValue = UnBirthTime.getText();
        Date date3 = dateFormat.parse(BirthTimeValue);
        calendar.setTime(date3);
        calendar.add(Calendar.HOUR_OF_DAY, TerminalStayValue);
        Date newDate3 = calendar.getTime();
        String result3 = dateFormat.format(newDate3);
        if (UnBirthTimeValue.equals(result3)) {
        	System.out.println("3.UnBerthTime Calculate in hours: " + result3 + " result");
		   	//cl.log.info("New Unberth Time of first terminal = new Berth Time + Terminal Stay -->"+ result3);
	        //cl.ActualTestDataValue = "new Berth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue + " Terminal Stay= " + TerminalStayText+ " UnBirth Time= "+UnBirthTimeValue, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Unberth Time of first terminal = new Berth Time + Terminal Stay -->"+ result3);
	        //cl.ActualTestDataValue = "new Berth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue + " Terminal Stay= " + TerminalStayText+ " UnBirth Time= "+UnBirthTimeValue, "" , "Fail", "", 1, "VERIFY"); 
	   }
       //4.New Berth Time of second terminal or subsequent terminals = New Unberth Time of earlier terminal + Shifting
       WebElement BirthTime2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='clickable'])[2]"));
       String BirthTimeValue2 = BirthTime2.getText();
       
       WebElement UnBirthTime2 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[20]//div[@class='clickable'])[1]"));
       String UnBirthTimeValue2 = UnBirthTime2.getText();
       
       WebElement ShiftingTime = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[26])[2]"));
       String ShiftingTimeText = ShiftingTime.getText();
       int ShiftingTimeValue = Integer.parseInt(ShiftingTimeText);
       Date date4 = dateFormat.parse(UnBirthTimeValue2);
       calendar.setTime(date4);
       calendar.add(Calendar.HOUR_OF_DAY, ShiftingTimeValue);
       Date newDate4 = calendar.getTime();
       String result4 = dateFormat.format(newDate4);
       if (BirthTimeValue2.equals(result4)) {
       		System.out.println("4.New Berth Time of second terminal or subsequent terminals: " + result4 + " result");
       		//cl.log.info("New Berth Time of second terminal or subsequent terminals = New Unberth Time of earlier terminal + Shifting -->"+ result4);
	        //cl.ActualTestDataValue = "New Unberth Time of earlier terminal and Shifting";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue2 + " Shifting Time= " + ShiftingTimeText+ " UnBirth Time= "+UnBirthTimeValue2, "" , "Pass", "", 1, "VERIFY");
	   }else {
		   	//cl.log.info("New Berth Time of second terminal or subsequent terminals = New Unberth Time of earlier terminal + Shifting -->"+ result4);
	        //cl.ActualTestDataValue = "New Unberth Time of earlier terminal and Shifting";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue2 + " Shifting Time= " + ShiftingTimeText+ " UnBirth Time= "+UnBirthTimeValue2, "" , "Fail", "", 1, "VERIFY"); 
	   }
       //5.New Unberth Time of second terminal or subsequent terminals = new Berth Time + Terminal Stay
       WebElement UnBirthTime3 = driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//td[20]//div[@class='clickable'])[2]"));
       String UnBirthTimeValue3 = UnBirthTime3.getText();
       WebElement TerminalStay2 = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[4]//td[15]"));
       String TerminalStayText2 = TerminalStay2.getText();
       int TerminalStayValue2 = Integer.parseInt(TerminalStayText2);
       Date date5 = dateFormat.parse(BirthTimeValue2);
       calendar.setTime(date5);
       calendar.add(Calendar.HOUR_OF_DAY, TerminalStayValue2);
       Date newDate5 = calendar.getTime();
       String result5 = dateFormat.format(newDate5);
       if (UnBirthTimeValue3.equals(result5)) {
      		System.out.println("5.New Unberth Time of second terminal or subsequent terminals = new Berth Time + Terminal Stay " + result5 + " result");
      		//cl.log.info("New Unberth Time of second terminal or subsequent terminals = new Berth Time + Terminal Stay -->"+ result5);
	        //cl.ActualTestDataValue = "new Berth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue2 + " Terminal Stay= " + TerminalStayText2+ " UnBirth Time= "+UnBirthTimeValue3, "" , "Pass", "", 1, "VERIFY");
	   }else {
		 //cl.log.info("New Unberth Time of second terminal or subsequent terminals = new Berth Time + Terminal Stay -->"+ result5);
	        //cl.ActualTestDataValue = "new Berth Time and Terminal Stay";
	    	//cl.result("Verified, New Birth Time = "+ BirthTimeValue2 + " Terminal Stay= " + TerminalStayText2+ " UnBirth Time= "+UnBirthTimeValue3, "" , "Fail", "", 1, "VERIFY"); 
	   }
       
	}
}
