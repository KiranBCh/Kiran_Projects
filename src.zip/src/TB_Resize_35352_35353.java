import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class TB_Resize_35352_35353 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		Actions actions = new Actions(driver);
				
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement ArriavlTimeB = driver.findElement(By.xpath("//div[@id='port-arrival-00']"));
		String ArriavlTimeBValue = ArriavlTimeB.getText();
		
		WebElement DepartureTimeB = driver.findElement(By.xpath("//div[@id='port-departure-00']"));
		String DepartureTimeBValue = DepartureTimeB.getText();
		
		WebElement BerthTimeB = driver.findElement(By.xpath("//div[@id='term-berth-000']"));
		String BerthTimeBValue = BerthTimeB.getText();
		
		WebElement UnBerthTimeB = driver.findElement(By.xpath("//div[@id='term-unberth-000']"));
		String UnBerthTimeBValue = UnBerthTimeB.getText();
		
		Thread.sleep(3000);
		WebElement Drag2 = driver.findElement(By.xpath("//div[@class='timing']"));
		System.out.println(Drag2.getLocation());
		Thread.sleep(3000);
		actions.clickAndHold(Drag2).moveByOffset(10, 40).release().build().perform();
		//actions.clickAndHold(Drag2).moveByOffset(10, 30).release().build().perform();
	    	    
	    driver.findElement(By.xpath("(//div[@class='dayBlockText'])[3]")).click();
	    Thread.sleep(3000);
	    
		WebElement ArriavlTimeA = driver.findElement(By.xpath("//div[@id='port-arrival-00']"));
		String ArriavlTimeAValue = ArriavlTimeA.getText();
		
		WebElement DepartureTimeA = driver.findElement(By.xpath("//div[@id='port-departure-00']"));
		String DepartureTimeAValue = DepartureTimeA.getText();
		
		WebElement BerthTimeA = driver.findElement(By.xpath("//div[@id='term-berth-000']"));
		String BerthTimeAValue = BerthTimeA.getText();
		
		WebElement UnBerthTimeA = driver.findElement(By.xpath("//div[@id='term-unberth-000']"));
		String UnBerthTimeAValue = UnBerthTimeA.getText();
		
		if (ArriavlTimeBValue != ArriavlTimeAValue){
			System.out.println("Change the Arrival" +ArriavlTimeBValue +" " + ArriavlTimeAValue);
            //cl.ActualTestDataValue = "Arrival Time Change ";
	        //cl.result("Verifyed After "+ArriavlTimeBValue+ " Before " + ArriavlTimeAValue , "Arrival Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Change the Arrival" +ArriavlTimeBValue +" " + ArriavlTimeAValue);
           // cl.ActualTestDataValue = "Arrival Time Change ";
	        //cl.result("Verifyed After "+ArriavlTimeBValue+ " Before " + ArriavlTimeAValue , "Arrival Time" , "Fail", "", 1, "VERIFY");
        }
		
		if (DepartureTimeAValue != DepartureTimeBValue){
			System.out.println("Change the Departure" +DepartureTimeBValue +" " + DepartureTimeBValue);
            //cl.ActualTestDataValue = "Departure Time Change ";
	        //cl.result("Verifyed After "+DepartureTimeAValue+ " Before " + DepartureTimeBValue , "Departure Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Change the Departure" +DepartureTimeBValue +" " + DepartureTimeBValue);
            //cl.ActualTestDataValue = "Departure Time Change ";
	        //cl.result("Verifyed After "+DepartureTimeAValue+ " Before " + DepartureTimeBValue , "Departure Time" , "Fail", "", 1, "VERIFY");
        }
		
		if (BerthTimeBValue != BerthTimeAValue){
			System.out.println("Change the Berth" +BerthTimeBValue +" " + BerthTimeAValue);
            //cl.ActualTestDataValue = "Berth Time Change ";
	        //cl.result("Verifyed After "+BerthTimeBValue + " Before " + BerthTimeAValue , "Berth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Change the Berth" +BerthTimeBValue +" " + BerthTimeAValue);
            //cl.ActualTestDataValue = "Berth Time Change ";
	        //cl.result("Verifyed After "+BerthTimeBValue + " Before " + BerthTimeAValue , "Berth Time" , "Fail", "", 1, "VERIFY");
        }
		if (UnBerthTimeBValue != UnBerthTimeAValue){
			System.out.println("Change the UnBerth" +UnBerthTimeBValue +" " + UnBerthTimeAValue);
            //cl.ActualTestDataValue = "UnBerth Time Change ";
	        //cl.result("Verifyed After "+UnBerthTimeBValue+ " Before " + UnBerthTimeAValue , "UnBerth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Change the UnBerth" +UnBerthTimeBValue +" " + UnBerthTimeAValue);
            //cl.ActualTestDataValue = "UnBerth Time Change ";
	        //cl.result("Verifyed After "+UnBerthTimeBValue+ " Before " + UnBerthTimeAValue , "UnBerth Time" , "Fail", "", 1, "VERIFY");
        }
 }
}
