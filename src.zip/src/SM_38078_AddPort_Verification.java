import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_38078_AddPort_Verification {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);
		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(7000);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("Testperforma");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'Testperforma')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("CAPE FLORES");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
		
        driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(5000);
        
        WebElement table = driver.findElement(By.xpath("//table[@class='data-table']"));
		List<WebElement> InputDatas = table.findElements(By.tagName("tr"));
		int rowSize = InputDatas.size();
		System.out.println("SizeOfTable before= "+ rowSize);
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[@class='data-table__sticky-column_2']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy']")).click();
        Thread.sleep(3000);	
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		driver.findElement(By.xpath("//div[@class='q-card__actions justify-start q-card__actions--horiz row']//button[2]")).click();	

		WebElement table1 = driver.findElement(By.xpath("//table[@class='data-table']"));
		List<WebElement> InputDatas1 = table1.findElements(By.tagName("tr"));

		int rowSize1 = InputDatas1.size();
		System.out.println("SizeOfTable After= "+ rowSize1);
		
		if ((rowSize + 2) == rowSize1) {
			System.out.println("Row Created Pass "+ (rowSize + 2) + "  After Rows= " + rowSize1);
			cl.ActualTestDataValue ="New Rows Added";
        	cl.result("Verifyed, Before RowCount"+ (rowSize + 2) + "  After Rows Count " + rowSize1, "", "Pass", "", 1, "Verify");
			
		} else {
			System.out.println("Row Created Pass "+ (rowSize + 2) + "  After Rows= " + rowSize1);
			cl.ActualTestDataValue ="New Rows Added";
        	cl.result("Verifyed, Before RowCount"+ (rowSize + 2) + "  After Rows Count " + rowSize1, "", "Pass", "", 1, "Verify");
		}
		
	}
}
