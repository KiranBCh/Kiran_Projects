import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_48544_48545_Restu {
	public static void main(String[] args) throws InterruptedException, AWTException {
		 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
 
		Thread.sleep(6000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
 
		
		WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
		
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch1.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("HYUNDAI MERCURY");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		//robot.keyPress(KeyEvent.VK_DOWN);
		//robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		/*
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(5000);
		*/
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        Prefix.sendKeys("HH");
        Thread.sleep(4000);
      
        WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        Suffix.sendKeys("20");
        Thread.sleep(8000);
 
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        Actions act = new Actions(driver);
        WebElement element2 = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		act.moveToElement(element2).build().perform();
		Thread.sleep(8000);
		WebElement Port = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::div[@class='q-field__native row items-center'])[1]"));
		act.contextClick(Port).build().perform();
		Thread.sleep(4000);
 
		WebElement RestructureButton = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[1][@class='q-item__section column q-item__section--main justify-center header'])[4]"));
		RestructureButton.click();
		Thread.sleep(4000);
		
		WebElement profomaname1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname1.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[8]"));
		TxtboxProfoma1.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement Sch11 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch11.click();
		Thread.sleep(3000);
		Thread.sleep(3000);
		WebElement Characters2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
		Characters2.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters2.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
		
        WebElement StartingNumnew = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        StartingNumnew.click();
        StartingNumnew.sendKeys("2");
        Thread.sleep(2000);
        
        WebElement Prefixnew = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[8]"));
        Prefixnew.sendKeys("HH");
        Thread.sleep(2000);
        
        WebElement increment = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        increment.click();
        increment.sendKeys("2");
        Thread.sleep(2000);
        
        WebElement Suffixnew = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[10]"));
        Suffixnew.sendKeys("20");
        Thread.sleep(2000);
		
        WebElement Textareaenter = driver.findElement(By.xpath("//div[@class='q-pa-md']//textarea[@name='port-remarks']"));
        Textareaenter.sendKeys("This is new");
        
        WebElement Generatenew = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generatenew.click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//div[@class='btn1']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--standard q-btn--rectangle q-btn--actionable q-focusable q-hoverable']")).click();
        Thread.sleep(2000);
        
        WebElement SailingSchedule = driver.findElement(By.xpath("//div[contains(text(), 'Sailing Schedule')]"));
        int SailingSchedulelocation = SailingSchedule.getLocation().getX();
        js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", SailingSchedule);
        System.out.println("SailingSchedulelocation= " + SailingSchedulelocation);
        
        WebElement Restructured = driver.findElement(By.xpath("//div[contains(text(), 'Restructured')]"));
        int RestructuredLocation = Restructured.getLocation().getX();
        js.executeScript("arguments[0].setAttribute('style', 'border:2px solid yellow')", Restructured);
        System.out.println("RestructuredLocation= " + RestructuredLocation);
        
        if (SailingSchedulelocation<RestructuredLocation){
        	//cl.log.info("Sailing Schedule and Restructured-->"+ SailingSchedulelocation);
            //cl.ActualTestDataValue = "Restructure Schedule lane is created next to the Sailing Schedule";
    	    //cl.result("Verifyed, SailingSchedule= "+SailingSchedulelocation + " " +"Restructured= "+RestructuredLocation,"", "Pass", "", 1, "VERIFY");
       }else {
    	   //cl.log.info("Sailing Schedule and Restructured-->"+ SailingSchedulelocation);
           //cl.ActualTestDataValue = "Restructure Schedule lane is created next to the Sailing Schedule";
   	    	//cl.result("Verifyed, SailingSchedule= "+SailingSchedulelocation + " " +"Restructured= "+RestructuredLocation,"", "Pass", "", 1, "VERIFY");
       }
        WebElement newSailing1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing1.click();
		Thread.sleep(8000);
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
	
		//Actions actions = new Actions(driver);
		Thread.sleep(3000);
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("HYUNDAI MERCURY");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//span[text()='GENERATE']")).click();
		Thread.sleep(2000);
		Actions actions = new Actions(driver);
		
		WebElement Lane2 = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(3000);
		
		
		WebElement AddPortName = driver.findElement(By.xpath("//div[@class=\"q-card portBlock default adHoc resizable\"]//input"));
		Thread.sleep(2000);
		act.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
        /*
        WebElement element2 = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[4]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		act.moveToElement(element2).build().perform();
		Thread.sleep(8000);
		WebElement Port = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[4]//following::div[@class='q-field__native row items-center'])[1]"));
		act.contextClick(Port).build().perform();
		Thread.sleep(4000);
 
		WebElement PhaseOutClick = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[1][@class='q-item__section column q-item__section--main justify-center header'])[4]"));
		PhaseOutClick.click();
		Thread.sleep(4000);
		
		WebElement profomanamenew = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomanamenew.click();
		Thread.sleep(5000);
		
		WebElement DropDownMenu = driver.findElement(By.xpath("//div[@class='q-tree q-tree--standard q-tree--no-connectors']"));
		DropDownMenu.click();
		Thread.sleep(5000);
		
		WebElement RepVesseTrue = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap']"));
		RepVesseTrue.click();
		Thread.sleep(4000);
		
		
		Thread.sleep(3000);
		WebElement Cancel = driver.findElement(By.xpath("//span[contains(text(),'CANCEL')]"));
		Cancel.click();
		Thread.sleep(4000);
		*/
		/*
		WebElement newSailing1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
	
	   WebElement Toggle = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'][1]"));
	   Toggle.click();
	   
	   WebElement vessel_click = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		vessel_click.click();
		Thread.sleep(2000);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		
		for (int i = 0; i <= 2 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane'])[2]"));
		
	    WebElement Lane1 = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane'])[2]"));
	    act.click(Lane).build().perform();
		Thread.sleep(3000);
		act.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("//div[@class=\"columnbackground schedule-lane\"][2]//following::div[@class=\"service-lane\"][2]//div[@class=\"displayLabelGrid\"]//input[@class='q-field__input q-placeholder col']"));
		Thread.sleep(2000);
		act.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
				
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,200)","");
		
		Thread.sleep(3000);
		act.click(Lane1).build().perform();
		Thread.sleep(3000);
		act.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		/*
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class=\"columnbackground schedule-lane\"][2]//following::div[@class=\"service-lane\"][2]//div[@class=\"displayLabelGrid\"]//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		act.moveToElement(AddPortName2).doubleClick().perform();
		
		AddPortName2.sendKeys("INNSA");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(9000);
		
		WebElement PortManual = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[209]"));
		act.contextClick(PortManual).build().perform();
		Thread.sleep(4000);
		
		WebElement Phase2 = driver.findElement(By.xpath("//div[contains(text(),'Phase out after port')]"));
		Phase2.click();
		Thread.sleep(4000);
		
		WebElement RepToggleTrue1 = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap']"));
		RepToggleTrue1.click();
		Thread.sleep(4000);
		
		
	 */
	
  }
}
