def function(first_name=None, last_name=None, age=None):
    return {"first_name": first_name,
            "last_name": last_name,
            "age": age}

print(function("kiranbabu", "chiluvuru", 35))

