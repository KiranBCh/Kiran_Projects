from typing import Union
from fastapi import FastAPI
import pymongo
import json

name = "CarYak"
client = pymongo.MongoClient(f'mongodb://dbadmin:Tx5Yh9gYzq1@crawlerdbcluster.c3yhtms4nrye.us-east-1.docdb.amazonaws.com:27017/?tls=true&tlsCAFile=rds-combined-ca-bundle.pem')
db = client[name]
result1 = db["cars"]
#client = pymongo.MongoClient("mongodb://localhost:27017")
#mongodb_dbname = "OfferResults"
#db = client[mongodb_dbname]
#recards = db["test_name"]

app = FastAPI()
#select created_on::date as createdOn,max(offer_price::numeric) as offerPrice,batch_com as batchCom from tbl_offer_summary where vin_number=:vin and created_by=:createdBy and offer_price ~ '[0-9]' GROUP BY created_on::date,batch_com ORDER BY created_on::date"
    
@app.get("/allrecords/")
def read_root():
    result = []
    for data in result1.find({"batch_com": 657501179}):
        print(data) 
        result.append({k: str(v) for k, v in data.items()})
    return result

@app.post("/vin_number/{vin_number}")
def vin_details():
    pass

"""
@app.get("/items/{item_id}")
def read_item(item_id: int, q: Union[str, None] = None):
    return {"item_id": item_id, "q": q}
"""

