package com.onetx.selenium.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class selected_proforma_33954 {
	public static void main(String[] args) throws InterruptedException {
	System.out.println("****************************");
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();

	String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
	driver.get(domain_url);
	driver.manage().window().maximize();
	Thread.sleep(3000);

	WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
	Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
	Thread.sleep(3000);

	WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
	Pass.sendKeys("Alumni@2023");		
	Thread.sleep(3000);

	WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
	Signin.click();
	Thread.sleep(3000);
	String string1 = domain_url + "/schedule/services/gantt";
	driver.get(string1);
	
	Thread.sleep(7000);
	WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
	Thread.sleep(7000);
	
	vessle_click.click();
	Thread.sleep(7000);
	WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
	Actions ac = new Actions(driver);
	Thread.sleep(4000);
	ac.click(searchBox1).perform();
	Thread.sleep(4000);
	WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
	searchBox2.sendKeys("VerifyProfomaSearch1");
	Thread.sleep(7000);
	WebElement selectname = driver.findElement(By.xpath("//div[text()='VerifyProfomaSearch1']"));
	selectname.click();
	Thread.sleep(7000);
	WebElement date_picker = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
	date_picker.click();
	Thread.sleep(7000);
	WebElement select_date_picker = driver.findElement(By.xpath("//p[@class='proforma-text']"));
	
	//String select_date_picker_ele = select_date_picker.getText();
	//System.out.println("Select Date Picker Text: " + select_date_picker_ele);
	boolean isEnabled = select_date_picker.isEnabled();
    if (isEnabled){
    	System.out.println(select_date_picker.getText());
    }
    else {
    	System.out.println("Not Selected Proforma Start Time");
    }
	}
}
