package com.onetx.selenium.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class selection_of_date_33955 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(7000);
		
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement date_picker = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
		date_picker.click();
		Thread.sleep(3000);
		
		WebElement dateElement = driver.findElement(By.xpath("//span[@class='block'][normalize-space()='2']"));
		Thread.sleep(3000);
        dateElement.click();
        
        boolean isEnabled = dateElement.isEnabled();
        if (isEnabled) {
        	System.out.println("Date is allowed selection");
        }
        Thread.sleep(7000);
	}
}
