package com.onetx.selenium.main;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SM_Great_then_Dates {
	/*
	public static void main(String[] args) {
		/*
        // Date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");

        // Parse the date strings to LocalDateTime objects
        LocalDateTime date1 = LocalDateTime.parse("05 Dec 2023 00:00", formatter);
        LocalDateTime date2 = LocalDateTime.parse("08 Dec 2023 00:00", formatter);

        // Compare the two dates
        if (date1.isBefore(date2)) {
            System.out.println("Kiran");
        } else if (date1.isAfter(date2)) {
            System.out.println("babu");
        } else {
            System.out.println("Both are same");
        }
        
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Week' W, E HH:mm");

	        // Parse the dates
	     LocalDateTime date1 = LocalDateTime.parse("Week 1, Tue 02:00", formatter);
	     LocalDateTime date2 = LocalDateTime.parse("Week 1, Mon 23:00", formatter);

	        // Calculate the difference in hours
	        //long hoursDifference = calculateHoursDifference(date1, date2);
	        Duration duration = Duration.between(date1, date2);

	        // Get the difference in hours
	        long hoursDifference = Math.abs(duration.toHours());
	        // Print the result
	        System.out.println("Difference in hours: " + hoursDifference + " hours");
    }
	*/
	public static void main(String[] args) {
        // Define the date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Week' W, E HH:mm");

        // Parse the dates
        LocalDateTime date1 = LocalDateTime.parse("Week 1, Tue 02:00", formatter);
        LocalDateTime date2 = LocalDateTime.parse("Week 1, Mon 23:00", formatter);

        // Calculate the difference in hours
        //long hoursDifference = calculateHoursDifference(date1, date2);
        Duration duration = Duration.between(date1, date2);

        // Get the difference in hours
        long hoursDifference = Math.abs(duration.toHours());
        // Print the result
	       System.out.println("Difference in hours: " + hoursDifference + " hours");
	}
}
