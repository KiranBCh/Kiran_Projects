package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Calculation_16468 {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);

		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement ClickNewSchedule = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		ClickNewSchedule.click();
		Thread.sleep(7000);
		//Robot robot = new Robot();
		
		WebElement ScheduleInformation = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		ScheduleInformation.click();
		Thread.sleep(4000);
		
		WebElement AddPortTerminal = driver.findElement(By.xpath("//span[@class='block']"));
		Thread.sleep(2000);
		AddPortTerminal.click();
		Thread.sleep(2000);
		
		WebElement AddPortTerminal1 = driver.findElement(By.xpath("//span[@class='block']"));
		Thread.sleep(2000);
		AddPortTerminal1.click();
		
		WebElement PortStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[16]"));
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
		
		String PortStayText = PortStay.getText();
		String pilotInText = PilotIn.getText();
		String pilotOutText = PilotOut.getText();
		
		int pilotInValue = Integer.parseInt(pilotInText);
		int pilotOutValue = Integer.parseInt(pilotOutText);
		int PortStayValue = Integer.parseInt(PortStayText);
		//System.out.println("pilotInValue= "+ pilotInValue);
		//System.out.println("pilotOutValue= "+ pilotOutValue);
		//System.out.println("PortStayValue= "+ PortStayValue);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
		WebElement ArrivalT = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[19]//div[@class='clickable']//p"));
		String inputTime = ArrivalT.getText();
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
		Date date1 = dateFormat.parse(inputTime);
		Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(Calendar.HOUR_OF_DAY, PortStayValue);
        Date newDate = calendar.getTime();
        String result = dateFormat.format(newDate);
        
        WebElement DepartureTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][1]//td[22]//div[@class='clickable']//p"));
        String DepartureTimeValue = DepartureTime.getText();
        if (result.equals(DepartureTimeValue)){
        	//cl.result("Verifyed_DepartureTime= "+ DepartureTime, "", "Pass", "16468", 1, "Verify");
        	System.out.println("Original Time1 " + result);
        }
        else {
        	System.out.println("Original Time: " + result);
        	//cl.result("Not_Verifyed_DepartureTime= "+ DepartureTime, "", "Fail", "16468", 1, "Verify");
        }
        
	}

}
