package com.onetx.selenium.main;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resizing_40928 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		
		WebElement Schedule1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Schedule1.click();
		Thread.sleep(9000);
        Actions actions = new Actions(driver);

		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.moveToElement(Lane).build().perform();
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(5000);
		//Port Width Change
		WebElement resizableElementPort = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='q-card portBlock default resizable']"));
		//String currentStyle = resizableElement.getAttribute("style");
		//System.out.println(currentStyle);
		//resizeElementWithStyle(driver, resizableElement, "width: 100px; height: 50px;");
		Thread.sleep(5000);
		String newStyle = "width: 100px; height: 50px;";
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		String script = "arguments[0].setAttribute('style', arguments[1]);";
	    jsExecutor.executeScript(script, resizableElementPort, newStyle);
	    WebElement resizableElement1 = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='q-card portBlock default resizable']"));
		String currentStyle1 = resizableElement1.getAttribute("style");
		System.out.println(currentStyle1);
		//Terminal Width Change
		WebElement resizableElementTerminal = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='terminal']//div[@class='q-card terminalBlock stretch resizable']"));
		Thread.sleep(5000);
		String newStyle1 = "width: 100px; height: 50px;";
		String script1 = "arguments[0].setAttribute('style', arguments[1]);";
	    jsExecutor.executeScript(script1, resizableElementTerminal, newStyle1);
	    WebElement resizableElementTerminalV = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='terminal']//div[@class='q-card terminalBlock stretch resizable']"));
		String currentStyle2 = resizableElementTerminalV.getAttribute("style");
		System.out.println(currentStyle2);
	}
}
/*
private static void resizeElementWithStyle(WebDriver driver, WebElement element, String newStyle) {
    // Create an instance of JavascriptExecutor
    JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

    // Set the new style attribute for resizing
    String script = "arguments[0].setAttribute('style', arguments[1]);";
    jsExecutor.executeScript(script, element, newStyle);
}
}
*/