package com.onetx.selenium.main;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

public class Date_Picker {
	public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalDate lastMonth = today.minusMonths(1);
        LocalDate lastMonthMonday = lastMonth.with(TemporalAdjusters.lastInMonth(DayOfWeek.MONDAY));

        System.out.println("Today: " + today);
        System.out.println("Last Month: " + lastMonth);
        System.out.println("Last Month's Last Monday: " + lastMonthMonday);
    }

}
