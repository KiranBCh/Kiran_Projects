package com.onetx.selenium.main;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Caryak_automation {
	public static void main(String[] args) throws InterruptedException {
	System.out.println("********Started Caryak Automation Script********************");
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();

	String domain_url = "https://cit.caryak.org/privateseller";
	driver.get(domain_url);
	driver.manage().window().maximize();
	Thread.sleep(3000);

	WebElement Vin_number = driver.findElement(By.xpath("//input[@placeholder='17 digit VIN *']"));
	Vin_number.sendKeys("WDDWJ8HB2HF515205");
	Thread.sleep(3000);

	WebElement Mileage = driver.findElement(By.xpath("//input[@name=\"milage\"]"));
	Mileage.sendKeys("25000");		
	Thread.sleep(3000);

	WebElement Zipcode = driver.findElement(By.xpath("//input[@name=\"zip_code\"]"));
	Zipcode.sendKeys("10006");		
	Thread.sleep(3000);
	
	WebElement mail_id = driver.findElement(By.xpath("//input[@name=\"email\"]"));
	mail_id.sendKeys("rajubabu@yahoo.in");		
	Thread.sleep(3000);
	
	WebElement condition = driver.findElement(By.xpath("//select[@name=\"condition\"]"));
	condition.sendKeys("Good");
	Thread.sleep(3000);
	
	WebElement checkbox = driver.findElement(By.xpath("//div[@class=\"checkBoxWrap\"]//input[@type=\"checkbox\"]"));
	if (!checkbox.isSelected()) {
        checkbox.click();
    }
	
	WebElement Signin = driver.findElement(By.xpath("//button[@class=\"btn addnewcarBtn btn-primary withLoadingIcon\"]"));
	Signin.click();
	Thread.sleep(70000);
	
	
	
	
	List<WebElement> website_names = driver.findElements(By.xpath("//section[@class=\"offerLists privateOfferList addnewcarOffer\"]//div[@class=\"offerCarImg\"]//img//@alt"));
	
	
	//ArrayList<String> stringList = new ArrayList<>();
	for (WebElement site : website_names) {
		
		//String inputValue = site.getText();
		//stringList.add(inputValue);
		System.out.println(site.getAttribute("alt"));
	}
 }
}
