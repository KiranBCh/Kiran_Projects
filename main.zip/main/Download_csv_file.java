package com.onetx.selenium.main;
import java.util.Scanner;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Download_csv_file {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement new_schedule_button = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		new_schedule_button.click();
		Thread.sleep(7000);
		
		String currentDirectory = System.getProperty("user.dir");
        String parentDirectory = new File(currentDirectory).getParent();
        String parentDirectory1 = new File(parentDirectory).getParent();
        String parentDirectory2 = parentDirectory1 + "/downloads/";
        File file = new File(parentDirectory2.replace("\\","/") + "Schedule1.xlsx");
        if (file.exists()) {
            // Attempt to delete the file
            boolean deleted = file.delete();
            System.out.println("File deleted successfully.");
            //cl.result("File_Deleted_successfully_InLocalVM", "", "Pass", "35165", 1, "File_Deleted_successfully_InLocalVM");
            
        }
        else {
            System.out.println("File not found.");
        	//cl.result("File_Not_Found_InLocalVM", "", "Fail", "35165", 1, "File_Not_Found_InLocalVM");
        }
        Thread.sleep(3000);
		WebElement Lane = driver.findElement(
				By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(4000);
		
		WebElement AddPortName = driver.findElement(By.xpath("//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col']"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("ITAOI");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement more_options = driver.findElement(By.xpath("//i[normalize-space()='more_vert']"));
		Thread.sleep(4000);
		more_options.click();
		Thread.sleep(4000);
		
		WebElement download_csv_file = driver.findElement(By.xpath("//div[normalize-space()='Download']"));
		Thread.sleep(2000);
		download_csv_file.click();
		Thread.sleep(2000);

        File f = new File(parentDirectory2.replace("\\","/") + "Schedule1.xlsx");
        Thread.sleep(4000);
		System.out.println(f);
		if (f.exists()) {
			System.out.println("File donwloaded in my local VM");
			//cl.result("DownloadedExcelFile_InLocalVM_Using_GanttChart", "", "Pass", "35165", 1, "DownloadedExcelFile_InLocalVM_Using_GanttChart");
		}
		else {
			//cl.result("Not_DownloadedExcelFile_InLocalVM_Using_GanttChart", "", "Fail", "35165", 1, "Not_DownloadedExcelFile_InLocalVM_Using_GanttChart");
		}
	}
}
