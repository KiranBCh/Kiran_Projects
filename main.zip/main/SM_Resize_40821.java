package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resize_40821 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		Actions actions = new Actions(driver);
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
	
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
	
		WebElement NewVessel = driver.findElement(By.xpath("//button[@id=\"btnCreateNewSchedule\"]"));
		NewVessel.click();
		Thread.sleep(5000);
	
		WebElement ManualToggle = driver.findElement(By.xpath("(//div[@class='q-toggle__track'])[1]"));
		actions.click(ManualToggle).perform();
		Thread.sleep(5000);
	
	WebElement ManualService = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[1]"));
	ManualService.click();
	ManualService.sendKeys("MAIKE D");
	Thread.sleep(2000);
	Robot robot = new Robot();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(2000);
	
	WebElement ManualOperator = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[2]"));
	ManualOperator.click();
	Thread.sleep(2000);
	
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	
	Thread.sleep(2000);
	
	WebElement ManualGenerate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
	ManualGenerate.click();
	Thread.sleep(5000);

	WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
	actions.moveToElement(Lane).build().perform();
	actions.contextClick(Lane).build().perform();
	Thread.sleep(5000);
	WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
	AddPortButton.click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("(//div[@class='q-item__section column q-item__section--main justify-center'])[3]")).click();
	Thread.sleep(5000);
	WebElement draggableElement = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='timing']")); 
	String currentStyle = draggableElement.getAttribute("style");
	System.out.println(currentStyle);
	Thread.sleep(5000);
	changeTopValueWithJavaScript(driver, draggableElement, "5px");
	Thread.sleep(5000);
	WebElement draggableElement1 = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class=\"terminal\"]"));
	changeTopValueWithJavaScript(driver, draggableElement1, "5px");
	Thread.sleep(5000);
	
}
private static void changeTopValueWithJavaScript(WebDriver driver, WebElement element, String newValue) {
// Create an instance of JavascriptExecutor
JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

// Execute JavaScript to change the "top" value
String script = "arguments[0].style.height = '" + newValue + "';";
jsExecutor.executeScript(script, element);

	}
}
