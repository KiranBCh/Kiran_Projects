package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;

public class SM_Man_Schedule_42578 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		String response = driver.getPageSource();
		System.out.println("Response1-->"+);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		//Actions actions = new Actions(driver);
		Thread.sleep(3000);
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("ALS KRONOS");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(3000);
		
		WebElement AddFirstPort = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		AddFirstPort.click();
		Thread.sleep(2000);
		AddFirstPort.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		/*
		WebElement AddFirstTerminal = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		AddFirstTerminal.click();
		Thread.sleep(2000);
		AddFirstTerminal.sendKeys("AJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(7000);
		*/
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(7000);
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddSecondPort = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[6]"));
		Thread.sleep(2000);
		AddSecondPort.click();
		Thread.sleep(3000);
		AddSecondPort.sendKeys("INNSA");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement AddSecondTerminal = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[8]"));
		Thread.sleep(2000);
		AddSecondTerminal.click();
		Thread.sleep(2000);
		AddSecondTerminal.sendKeys("JNP");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		List<WebElement> FirstPortName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		boolean ispresentflag = false;
		for(WebElement value : FirstPortName) {
			if(value.getAttribute("value").equals("Ajman (AEAJM)")) {				
				ispresentflag = true;
				System.out.println("FirstPortName= "+ispresentflag);
				//cl.result("Verified_FirstPortName Ajman (AEAJM)= " + ispresentflag , "", "Pass", "42578", 1, "Verify");
				break;
			}
			else {
				System.out.println("FirstPortName= "+ispresentflag);
				//cl.result("Not_Verified_FirstPortName Ajman (AEAJM)=" + ispresentflag , "", "Fail", "42578", 1, "Verify");
			}
		}
		List<WebElement> FirstTerminalName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		boolean ispresentflag1 = false;
		for(WebElement value : FirstTerminalName) {
			if(value.getAttribute("value").equals("AJMAN (AJM)")) {				
				ispresentflag1 = true;
				System.out.println("FirstTerminalName= "+ispresentflag1);
				//cl.result("Verified_FirstTerminalName AJMAN (AJM)=" + ispresentflag1 , "", "Pass", "42578", 1, "Verify");
				break;
			}
			else {
				System.out.println("FirstTerminalName= "+ispresentflag1);
				//cl.result("Not_Verified_FirstTerminalName AJMAN (AJM)=" + ispresentflag1 , "", "Fail", "42578", 1, "Verify");
			}
		}
		
		List<WebElement> SecondPortName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[6]"));
		boolean ispresentflag2 = false;
		for(WebElement value : SecondPortName) {
			if(value.getAttribute("value").equals("Nhava Sheva (INNSA)")) {				
				ispresentflag2 = true;
				System.out.println("SecondPortName= "+ispresentflag2);
				//cl.result("Verified_SecondPortName Nhava Sheva (INNSA)=" + ispresentflag2 , "", "Pass", "42578", 1, "Verify");
				break;
			}
			else {
				System.out.println("FirstTerminalName= "+ispresentflag2);
				//cl.result("Not_Verified_SecondPortName Nhava Sheva (INNSA)=" + ispresentflag2 , "", "Fail", "42578", 1, "Verify");
			}
		}
		
		List<WebElement> SecondTerminalName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[8]"));
		boolean ispresentflag3 = false;
		for(WebElement value : SecondTerminalName) {
			if(value.getAttribute("value").equals("JNPCT (JNP)")) {				
				ispresentflag3 = true;
				System.out.println("SecondTerminalName= "+ispresentflag3);
				//cl.result("Verified_SecondTerminalName JNPCT (JNP)=" + ispresentflag3 , "", "Pass", "42578", 1, "Verify");
				break;
			}
			else {
				System.out.println("FirstTerminalName= "+ispresentflag3);
				//cl.result("Not_Verified_SecondTerminalName JNPCT (JNP)=" + ispresentflag3 , "", "Fail", "42578", 1, "Verify");
			}
		}
	}

}
