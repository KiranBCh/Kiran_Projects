package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Download_35166_csv {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement new_schedule_button = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		new_schedule_button.click();
		Thread.sleep(7000);
		
		String currentDirectory = System.getProperty("user.dir");
        String parentDirectory = new File(currentDirectory).getParent();
        String parentDirectory1 = new File(parentDirectory).getParent();
        String currentDirectory_name = System.getProperty("user.name");
        String parentDirectory2 = parentDirectory1 +"/Users/"+ currentDirectory_name +"/downloads/";
        //cl.log.info("currentDirectory" + parentDirectory2);
        
        File file = new File(parentDirectory2.replace("\\","/") + "Schedule1.xlsx");
        
        if (file.exists()) {
            // Attempt to delete the file
            boolean deleted = file.delete();
            //cl.result("File_Deleted_successfully_InLocalVM", "", "Pass", "35165", 1, "File_Deleted_successfully_InLocalVM");
            System.out.println("File deleted successfully.");
        }
        Robot robot = new Robot();
	
		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(4000);
		
		WebElement add_port_terminal = driver.findElement(By.xpath("//span[@class='block']"));
		Thread.sleep(2000);
		add_port_terminal.click();
		Thread.sleep(2000);
		
		WebElement arrow_drop_down = driver.findElement(By.xpath("(//div[@class='q-field__native row items-center']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		arrow_drop_down.click();
		Thread.sleep(2000);
		arrow_drop_down.sendKeys("ITAOI");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		
		WebElement download_csv_file = driver.findElement(By.xpath("//i[normalize-space()='file_download']"));
		Thread.sleep(2000);
		download_csv_file.click();
		Thread.sleep(2000);
		System.out.println(parentDirectory2);
		File f = new File(parentDirectory2.replace("\\","/") + "Schedule1.xlsx");
        Thread.sleep(4000);
		if (f.exists()) {
			System.out.println("File deleted successfully.");
			//cl.result("DownloadedExcelFile_InLocalVM_Using_ScheduleInformation", "", "Pass", "35165", 1, "DownloadedExcelFile_InLocalVM_Using_ScheduleInformation");
		}
		else {
			//cl.result("Not_DownloadedExcelFile_InLocalVM_Using_ScheduleInformation", "", "Fail", "35165", 1, "Not_DownloadedExcelFile_InLocalVM_Using_ScheduleInformation");
			System.out.println("File deleted successfully.");
		}
		
	}

}
