package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestBed_19302 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(8000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Test Bed')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
			
		WebElement ScheduleInformation = driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']"));
		ScheduleInformation.click();
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		WebElement AddPortButton = driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']"));
		AddPortButton.click();
		Thread.sleep(7000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Unberth Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
		
		WebElement BirthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='clickable']//p"));
		String BirthTimeValue = BirthTime.getText();
		//System.out.println(BirthTimeValue);
		WebElement ChangeBirthTime = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='clickable']"));
		ChangeBirthTime.click();
		Thread.sleep(3000);
		 boolean isEnabled = ChangeBirthTime.isEnabled();
		if (isEnabled) {
			//System.out.println("Verify that Calendar Component opens and user able to input new BerthTime");
			cl.result("Verify that Calendar Component opens and user able to input new Berth time ", "", "Pass", "19302", 1, "Verify");
		}
		else {
			//System.out.println("Not Verify that Calendar Component opens and user able to input new BerthTime");
			cl.result("Verify that Calendar Component opens and user able to input new Berth time ", "", "Fail", "19302", 1, "Verify");
		}
		WebElement DepartureTimeHours = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));
		DepartureTimeHours.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	    
	    Thread.sleep(2000);
	    
		WebElement OutsideClick = driver.findElement(By.xpath("//th[normalize-space()='Berth Time']"));
		OutsideClick.click();
		Thread.sleep(2000);
		WebElement BirthTimea = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered']//td[19]//div[@class='clickable']//p"));
		String BirthTimeValuea = BirthTimea.getText();
		//System.out.println(BirthTimeValuea);
		WebElement ScrollRight2 = driver.findElement(By.xpath("//th[normalize-space()='Total']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight2);
		
		//New Port buffer (hours) = Pilot In + new Pilot Out + Shifting (all terminals) -ARKS Pilot In - ARKS Pilot Out - ARKS Shifting (all terminals)
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
		WebElement PilotIn_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		
		int pilotInText = Integer.parseInt(PilotIn.getText());
        int PilotOutText = Integer.parseInt(PilotOut.getText());
        int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
        int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
        int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
        int Shifting_AllTerminals = 0;
        int ARKS_Shifting_AllTerminals = 0;
        
        int PortBuffer = pilotInText + PilotOutText + Shifting_AllTerminals - PilotInARKSText - PilotOutARKSText - ARKS_Shifting_AllTerminals;
        
        if (bufferTimeValueText == PortBuffer) {
        	//System.out.println("Verifyed_PortBufferTime_Is_Equals(bufferTimeValue)");
        	cl.result("Verifyed New Port BufferTimings are Recalculated with above Logic BeforeBufferTime "+ bufferTimeValueText + " AfterBufferTime " + PortBuffer, "", "Pass", "19302", 1, "Verify");
        }
        else {
        	//System.out.println("Verifyed_PortBufferTime_Is_Not_Equals(bufferTimeValue)");
        	cl.result("Not Verifyed New Port BufferTimings are Recalculated with above Logic BeforeBufferTime "+ bufferTimeValueText + " AfterBufferTime " + PortBuffer, "", "Pass", "19302", 1, "Verify");
        }
		
	}
}
