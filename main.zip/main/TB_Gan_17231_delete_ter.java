package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_Gan_17231_delete_ter {
	public static void main(String[] args) throws InterruptedException, AWTException, ParseException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Test Bed')]"));
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		javascript.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		Actions actions = new Actions(driver);
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(5000);
		WebElement draggableElement = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='timing']")); 
		String currentStyle = draggableElement.getAttribute("style");
		System.out.println(currentStyle);
		javascript.executeScript("arguments[0].style.height = '200px'", draggableElement);
		Thread.sleep(5000);
		/*
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		*/
		/*
		driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']")).click();
		Thread.sleep(4000);
		
		WebElement add_port_terminal = driver.findElement(By.xpath("//span[@class='block']"));
		add_port_terminal.click();
		//DepartureTime
		Robot robot = new Robot();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
		
		WebElement DepartureTime = driver.findElement(By.xpath("(//div[@class='clickable'])[3]//p"));
		String DepartureTimeValue = DepartureTime.getText();
		if (DepartureTimeValue != null){
            System.out.println("Before Departure Time= " + DepartureTimeValue);
            cl.ActualTestDataValue ="Before Departure Time=";
	        cl.result("Verifyed Before Departure Time= "+  DepartureTimeValue, "Departure Time" , "Pass", "", 1, "VERIFY");
        }
	    WebElement ChangeDepartureTime = driver.findElement(By.xpath("(//div[@class='clickable'])[3]"));
		ChangeDepartureTime.click();
		WebElement ChangeTime = driver.findElement(By.xpath("//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));
		ChangeTime.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//th[normalize-space()='Departure Time']")).click();
	    Thread.sleep(3000);
	    WebElement DepartureTimeA = driver.findElement(By.xpath("(//div[@class='clickable'])[3]//p"));
		String DepartureTimeValueA = DepartureTimeA.getText();
		if (DepartureTimeValueA != null){
            System.out.println("After Departure Time= " + DepartureTimeValueA);
            cl.ActualTestDataValue ="After Departure Time= ";
	        cl.result("Verifyed After Departure Time= "+  DepartureTimeValueA, "Departure Time" , "Pass", "", 1, "VERIFY");
        }
		Thread.sleep(3000);
        WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
		WebElement PilotIn_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		
		int pilotInText = Integer.parseInt(PilotIn.getText());
		if (pilotInText >= 0){
            System.out.println("PilotIn= " + pilotInText);
            cl.ActualTestDataValue ="Pilot In= ";
	        cl.result("Verifyed Pilot In= "+  pilotInText, "Pilot In" , "Pass", "", 1, "VERIFY");
        }
        int PilotOutText = Integer.parseInt(PilotOut.getText());
        if (PilotOutText >= 0){
            System.out.println("PilotOut= " + PilotOutText);
            cl.ActualTestDataValue ="Pilot Out= ";
	        cl.result("Verifyed Pilot Out= "+  PilotOutText, "Pilot Out" , "Pass", "", 1, "VERIFY");
        }
        int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
        if (PilotInARKSText >= 0){
            System.out.println("Pilot In ARKS= " + PilotInARKSText);
            cl.ActualTestDataValue ="Pilot In ARKS= ";
	        cl.result("Verifyed Pilot In ARKS= "+  PilotInARKSText, "Pilot In ARKS" , "Pass", "", 1, "VERIFY");
        }
        int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
        if (PilotOutARKSText >= 0){
            System.out.println("Pilot Out ARKS= " + PilotOutARKSText);
            cl.ActualTestDataValue ="Pilot Out ARKS= ";
	        cl.result("Verifyed Pilot Out ARKS= "+  PilotOutARKSText, "Pilot Out ARKS" , "Pass", "", 1, "VERIFY");
        }
        int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
        int Shifting_AllTerminals = 0;
        if (Shifting_AllTerminals == 0){
            System.out.println("Shifting All Terminals= " + Shifting_AllTerminals);
            cl.ActualTestDataValue ="Shifting All Terminals= ";
	        cl.result("Verifyed Shifting All Terminals= "+  Shifting_AllTerminals, "Shifting All Terminals" , "Pass", "", 1, "VERIFY");
        }
        int ARKS_Shifting_AllTerminals = 0;
        if (ARKS_Shifting_AllTerminals == 0){
            System.out.println("ARKS Shifting All Terminals= " + ARKS_Shifting_AllTerminals);
            cl.ActualTestDataValue ="ARKS Shifting All Terminals= ";
	        cl.result("Verifyed ARKS Shifting All Terminals= "+  ARKS_Shifting_AllTerminals, "ARKS Shifting All Terminals" , "Pass", "", 1, "VERIFY");
        }
        int PortBuffer = pilotInText + PilotOutText + Shifting_AllTerminals - PilotInARKSText - PilotOutARKSText - ARKS_Shifting_AllTerminals;
        if (bufferTimeValueText == PortBuffer){
            System.out.println("Verify that new Pilot Out timing calculated= " + bufferTimeValueText);
            cl.ActualTestDataValue ="Verify that new Pilot Out timing calculated ";
	        cl.result("Verifyed "+ " BufferTime Hours After Calculation= "+  bufferTimeValueText, "After change the departure time " , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("Not Verify that new Pilot Out timing calculated as " + bufferTimeValueText);
            cl.ActualTestDataValue ="Not Verify that new Pilot Out timing calculated as";
	        cl.result("Not Verifyed "+ " BufferTime Hours After Calculation= "+  bufferTimeValueText, "After change the departure time " , "Fail", "", 1, "VERIFY");
        }
        //Calculation for Pilot OUT
        //DepartureTimeValueA
        WebElement UnberthTime = driver.findElement(By.xpath("(//div[@class='clickable'])[7]//p"));
        String UnberthTimeValue = UnberthTime.getText();
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        long hours = 0;
            // Parse the times into Date objects
        Date date1 = dateFormat.parse(DepartureTimeValueA);
        Date date2 = dateFormat.parse(UnberthTimeValue);
        long timeDifference = date1.getTime() - date2.getTime();
        hours = (timeDifference / (60 * 60 * 1000 ));
        System.out.println("Time Difference: " + hours + " hours");
        if (UnberthTimeValue != null){
            System.out.println("Unberth Time= " + UnberthTimeValue);
            cl.ActualTestDataValue ="Unberth Time= ";
	        cl.result("Verifyed Unberth Time= "+  UnberthTimeValue, "Unberth Time" , "Pass", "", 1, "VERIFY");
        }
        long PilotOutText1 = Long.parseLong(PilotOut.getText());
        if (hours == PilotOutText1){
            System.out.println("Verify that new Pilot Out timing calculated= " + hours);
            cl.ActualTestDataValue ="Verify that new Pilot Out timing calculated";
	        cl.result("Verifyed New Pilot Out hours Calculation= "+ hours, "After Calclulation " + hours , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("Not Verify that new Pilot Out timing calculated= " + hours);
            cl.ActualTestDataValue ="Verify that new Pilot Out timing calculated";
	        cl.result("Not Verifyed New Pilot Out hours Calculation= "+ hours, "After Calclulation " + hours , "Fail", "", 1, "VERIFY");
        }
        */
	}

	private static void executeScript(String string, WebElement draggableElement) {
		// TODO Auto-generated method stub
		
	}
}
