package com.onetx.selenium.main;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class Current_Monday {
	/*
	public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalDate currentMonday = today;

        // Loop until we find the current Monday
        while (currentMonday.getDayOfWeek() != DayOfWeek.MONDAY) {
            currentMonday = currentMonday.minusDays(1);
        }

        System.out.println("Today: " + today);
        System.out.println("Current Monday: " + currentMonday.getDayOfMonth());
    }*/
	public static void main(String[] args) {
        // Define the initial date and time (Mon 12:00 PM)
        LocalDateTime initialDateTime = LocalDateTime.parse("Mon 12:00 PM", DateTimeFormatter.ofPattern("E hh:mm a"));

        // Add 72 hours to the initial date and time
        LocalDateTime resultDateTime = initialDateTime.plus(72, ChronoUnit.HOURS);

        // Format and print the result
        String result = resultDateTime.format(DateTimeFormatter.ofPattern("E hh:mm a"));
        System.out.println("72 hours after 'Mon 12:00 PM' is: " + result);
    }

}
