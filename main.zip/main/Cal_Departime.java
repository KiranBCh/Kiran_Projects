package com.onetx.selenium.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class Cal_Departime {
	public static void main(String[] args) throws ParseException {
        // Define the date format
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Week' W, E HH:mm");

        // Parse the dates
        //LocalDateTime date1 = LocalDateTime.parse("Week 1, Tue 02:00", formatter);
        //LocalDateTime date2 = LocalDateTime.parse("Week 1, Mon 23:00", formatter);

        // Calculate the difference in hours
        //long hoursDifference = calculateHoursDifference(date1, date2);
        //Duration duration = Duration.between(date1, date2);

        // Get the difference in hours
        //long hoursDifference = Math.abs(duration.toHours());
        // Print the result
        //System.out.println("Difference in hours: " + hoursDifference + " hours");
        /*
        SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        long hours = 0;
            // Parse the times into Date objects
        Date date1 = dateFormat.parse("Week 2, Mon 12:00");
        Date date2 = dateFormat.parse("Week 1, Fri 14:00");

            // Calculate the time difference in milliseconds
            long timeDifference = date1.getTime() - date2.getTime();

            // Convert the time difference to hours and minutes
            hours = (timeDifference / (60 * 60 * 1000 ));
            long minutes = (timeDifference % (60 * 60 * 1000)) / (60 * 1000);
            
            System.out.println("Time Difference: " + hours + " hours and " + minutes + " minutes");
          */
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        // Parse the dates
		Date date1 = dateFormat.parse("Week 1, Mon 19:00");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(Calendar.HOUR_OF_DAY, 10);
        Date newDate = calendar.getTime();
        String result = dateFormat.format(newDate);
        System.out.println("UnBerthTime Calculate in hours: " + result + " result");
    
}
}