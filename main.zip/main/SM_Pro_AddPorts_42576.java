package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Pro_AddPorts_42576 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);
		
		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(9000);
		
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));//"(//span[@class='buttonLabels'])[2]"));
		vessle_click.click();
		Thread.sleep(9000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("PADMA");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(5000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        
        WebElement scheduleInformation = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
        scheduleInformation.click();
		Thread.sleep(8000);
		
		//Added Port which are single terminal
		WebElement AddPortClick = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPortClick.click();
		Thread.sleep(3000);
		
		WebElement ScrollDown = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
				
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", ScrollDown);
		
		WebElement AddPort = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPort.click();		
		Thread.sleep(3000);
		String Nameport = "MYPEN";
		AddPort.sendKeys(Nameport);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		List<WebElement> FirstPortName = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		for(WebElement value : FirstPortName) {
			if(value.getAttribute("value").equals(Nameport)) {				
				System.out.println("FirstPortName= "+ value.getAttribute("value"));
				//cl.result("Verified_FirstPortName= " + value.getAttribute("value"), "", "Pass", "42576", 1, "Verify");
				break;
			}
			else {
				System.out.println("FirstPortName= "+value.getAttribute("value"));
				//cl.result("Not_Verified_FirstPortName= " + value.getAttribute("value"), "", "Fail", "42576", 1, "Verify");
			}
		}
		List<WebElement> FirstTerminalName = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::tr//td//input[@class='q-field__input q-placeholder col'])[1]"));
		for(WebElement value : FirstTerminalName) {
			if(value.getAttribute("value") != null) {				
				System.out.println("FirstTerminalName= "+ value.getAttribute("value"));
				//cl.result("Verified_FirstTerminalName= " + value.getAttribute("value") , "", "Pass", "42576", 1, "Verify");
				break;
			}
			else {
				System.out.println("FirstTerminalName= "+ value.getAttribute("value"));
				//cl.result("Not_Verified_FirstTerminalName=" + value.getAttribute("value"), "", "Fail", "42576", 1, "Verify");
			}
		}
		//Add Port with multiple terminals
		WebElement AddSecondPort = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddSecondPort.click();
		
		WebElement ScrollDown2 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", ScrollDown2);
		
		WebElement AddSecondPortLast = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddSecondPortLast.click();		
		
		String SecondNameport = "INTUT";
		AddSecondPortLast.sendKeys(SecondNameport);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement AddSecondTerminal = driver.findElement(By.xpath("(((//div[@class='q-checkbox__bg absolute'])[last()-2])//following::tr[1]//td[2]//input)[2]"));
		Thread.sleep(8000);
		AddSecondTerminal.click();
		Thread.sleep(8000);
		AddSecondTerminal.sendKeys("TCT");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		List<WebElement> SecondPortName = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		for(WebElement value : SecondPortName) {
			if(value.getAttribute("value").equals(SecondNameport)) {				
				System.out.println("SecondPortName= "+ value.getAttribute("value"));
				//cl.result("Verified_SecondPortName=" + value.getAttribute("value"), "", "Pass", "42576", 1, "Verify");
				break;
			}
			else {
				System.out.println("SecondPortName= "+value.getAttribute("value"));
				//cl.result("Not_Verified_SecondPortName= " + value.getAttribute("value") , "", "Fail", "42576", 1, "Verify");
			}
		}
		List<WebElement> SecondTerminalName = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::tr//td//input[@class='q-field__input q-placeholder col'])[1]"));
		for(WebElement value : SecondTerminalName) {
			if(value.getAttribute("value") != null) {				
				System.out.println("SecondTerminalName= "+ value.getAttribute("value"));
				//cl.result("Verified_SecondTerminalName= " + value.getAttribute("value"), "", "Pass", "42576", 1, "Verify");
				break;
			}
			else {
				System.out.println("SecondTerminalName= "+ value.getAttribute("value"));
				//cl.result("Not_Verified_SecondTerminalName= " + value.getAttribute("value"), "", "Fail", "42576", 1, "Verify");
			}
		}
    }
}
