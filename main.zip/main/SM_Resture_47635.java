package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resture_47635 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
 
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
 
		
		WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
		
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch1.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("PADMA");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(5000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        Prefix.sendKeys("HH");
        Thread.sleep(4000);
      
        WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        Suffix.sendKeys("20");
        Thread.sleep(8000);
 
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        
       
        Actions act = new Actions(driver);
        WebElement element2 = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		act.moveToElement(element2).build().perform();
		Thread.sleep(8000);
		WebElement Port = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::div[@class='q-field__native row items-center'])[1]"));
		act.contextClick(Port).build().perform();
		Thread.sleep(4000);
 
		WebElement PhaseOutClick = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[1][@class='q-item__section column q-item__section--main justify-center header'])[4]"));
		PhaseOutClick.click();
		Thread.sleep(4000);
		
		WebElement profomanamenew = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomanamenew.click();
		Thread.sleep(5000);
		
		WebElement DropDownMenu = driver.findElement(By.xpath("//div[@class='q-tree q-tree--standard q-tree--no-connectors']"));
		DropDownMenu.click();
		Thread.sleep(5000);
		
		//WebElement RepVesseTrue = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap']"));
		//RepVesseTrue.click();
		//Thread.sleep(4000);
		/*
        List<WebElement> ExtVoyage = driver.findElements(By.xpath("//p[contains(text(),'External voyage number')]"));
        int size = ExtVoyage.size();
		if (size == 1) {
			System.out.println("External Voyage is Present");
		}
		else {
			System.out.println("External Voyage is not Present");
			
		}
        
		WebElement RepVesseFalse = driver.findElement(By.xpath("(//div[@class='q-toggle__thumb absolute flex flex-center no-wrap'])[1]"));
		RepVesseFalse.click();
		Thread.sleep(4000);
	
		List<WebElement> ExtVoyageNotVisible = driver.findElements(By.xpath("//p[contains(text(),'External voyage number')]"));
        int size1 = ExtVoyageNotVisible.size();
		if (size == 0) {
			System.out.println("External Voyage Is Not Displayed");
		}
		else {
			System.out.println("External Voyage Is Displayed");
			
		}
		
		Thread.sleep(3000);
		WebElement Cancel = driver.findElement(By.xpath("//span[contains(text(),'CANCEL')]"));
		Cancel.click();
		Thread.sleep(4000);
		
		WebElement newSailing1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
		
	   WebElement Toggle = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'][1]"));
	   Toggle.click();
	   
	   WebElement vessel_click = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		vessel_click.click();
		Thread.sleep(2000);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		
		for (int i = 0; i <= 2 ; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane'])[2]"));
		
	    WebElement Lane1 = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane'])[2]"));
	    act.click(Lane).build().perform();
		Thread.sleep(3000);
		act.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("//div[@class=\"columnbackground schedule-lane\"][2]//following::div[@class=\"service-lane\"][2]//div[@class=\"displayLabelGrid\"]//input[@class='q-field__input q-placeholder col']"));
		Thread.sleep(2000);
		act.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
				
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,200)","");
		
		Thread.sleep(3000);
		act.click(Lane1).build().perform();
		Thread.sleep(3000);
		act.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class=\"columnbackground schedule-lane\"][2]//following::div[@class=\"service-lane\"][2]//div[@class=\"displayLabelGrid\"]//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		act.moveToElement(AddPortName2).doubleClick().perform();
		
		AddPortName2.sendKeys("INNSA");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(9000);
		
		WebElement PortManual = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[209]"));
		act.contextClick(PortManual).build().perform();
		Thread.sleep(4000);
		
		WebElement Phase2 = driver.findElement(By.xpath("//div[contains(text(),'Phase out after port')]"));
		Phase2.click();
		Thread.sleep(4000);
		
		WebElement RepToggleTrue1 = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap']"));
		RepToggleTrue1.click();
		Thread.sleep(4000);
		
		List<WebElement> ExtVoyage1 = driver.findElements(By.xpath("//p[contains(text(),'External voyage number')]"));
        int size2 = ExtVoyage1.size();
		if (size2 == 1) {
			System.out.println("External Voyage is Present");
		}
		else {
			System.out.println("External Voyage is not Present");
			
		}
		
		
		WebElement RepToggleFalse1 = driver.findElement(By.xpath("(//div[@class='q-toggle__thumb absolute flex flex-center no-wrap'])[1]"));
		RepToggleFalse1.click();
		Thread.sleep(4000);
		
		
		List<WebElement> ExtVoyageNotVisible1 = driver.findElements(By.xpath("//p[contains(text(),'External voyage number')]"));
        int size3 = ExtVoyageNotVisible1.size();
		if (size3 == 0) {
			System.out.println("External Voyage Is Not Displayed");
		}
		else {
			System.out.println("External Voyage Is Displayed");
			
		}
	 */
	
  }

}
