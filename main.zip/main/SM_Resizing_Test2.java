package com.onetx.selenium.main;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resizing_Test2 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		Thread.sleep(3000);
		WebElement Schedule1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Schedule1.click();
		Thread.sleep(9000);
        Actions actions = new Actions(driver);

		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.moveToElement(Lane).build().perform();
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(5000);
		
		WebElement draggableElement = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='timing']")); 
		String currentStyle = draggableElement.getAttribute("style");
		System.out.println(currentStyle);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		Thread.sleep(5000);
		String newValue = "200px";
		String script = "arguments[0].style.height = '" + newValue + "';";
		jsExecutor.executeScript(script, draggableElement);
		//changeTopValueWithJavaScript(driver, draggableElement, "200px");
		Thread.sleep(5000);
		WebElement draggableElement1 = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='terminal']"));
		//changeTopValueWithJavaScript(driver, draggableElement1, "190px");
		String NewValue1 = "190px";
		String script1 = "arguments[0].style.height = '" + NewValue1 + "';";
		jsExecutor.executeScript(script1, draggableElement1);
		Thread.sleep(5000);
}
}
		/*
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 105)","");
		Thread.sleep(5000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.moveToElement(Lane2).build().perform();
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@class='q-item q-item-type row no-wrap q-item--clickable q-link cursor-pointer q-focusable q-hoverable item']")).click();
		*/
/*	}
private static void changeTopValueWithJavaScript(WebDriver driver, WebElement element, String newValue) {
    // Create an instance of JavascriptExecutor
    JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

    // Execute JavaScript to change the "top" value
    String script = "arguments[0].style.height = '" + newValue + "';";
    jsExecutor.executeScript(script, element);
}
*/

