package com.onetx.selenium.main;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SM_Man_AddPorts_42586 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(7000);
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		WebElement VesselNameClick = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		
		WebElement ScheduleInformation = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		ScheduleInformation.click();
		Thread.sleep(8000);
				
		WebElement AddPort = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPort.click();
		Thread.sleep(3000);
		
		WebElement AddPortName = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPortName.click();		
		Thread.sleep(3000);
		
		Thread.sleep(4000);
		AddPortName.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement AddPort2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPort2.click();
		Thread.sleep(3000);
		
		WebElement AddPortName2 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPortName2.click();		
		Thread.sleep(3000);
		
		AddPortName2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement SeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[26]")); 
		String SeatimeValue = SeaTime.getText();
		List<WebElement> Speed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedValue = "";
		for(WebElement value : Speed) {
			if(value.getAttribute("value") != null) {				
				SpeedValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> Distance = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String DistanceValue = "";
		for(WebElement value : Distance) {
			if(value.getAttribute("value") != null) {				
				DistanceValue = value.getAttribute("value");
				break;
			}
		}
		WebElement AddPort3 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPort3.click();
		Thread.sleep(3000);
		
		WebElement ScrollDown = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
				
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", ScrollDown);
		
		
		WebElement AddPortName3 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPortName3.click();		
		Thread.sleep(3000);
		
		AddPortName3.sendKeys("INHAL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement StayText = driver.findElement(By.xpath("//th[normalize-space()='Stay']"));
		js.executeScript("arguments[0].scrollIntoView(true);", StayText);
		WebElement SeaTimeAfter = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::td[24])")); 
		String SeatimeAfterValue = SeaTimeAfter.getText();
		List<WebElement> SpeedAfter = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::td[23]//input[@class='q-field__native q-placeholder text-center'])"));
		String SpeedAfterValue = "";
		for(WebElement value : SpeedAfter) {
			if(value.getAttribute("value") != null) {				
				SpeedAfterValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> DistanceAfter = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::td[21]//input[@class='q-field__input q-placeholder col'])"));
		String DistanceAfterValue = "";
		for(WebElement value : DistanceAfter) {
			if(value.getAttribute("value") != null) {				
				DistanceAfterValue = value.getAttribute("value");
				break;
			}
		}
		if (SeatimeValue != SeatimeAfterValue){
			System.out.println("Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue);
			//cl.result("Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue, "", "Pass", "42584", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue);
			//cl.result("Not_Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue, "", "Fail", "42584", 1, "Verify");
		}
		if (SpeedValue != SpeedAfterValue){
			System.out.println("Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue);
			//cl.result("Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue, "", "Pass", "42584", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue);
			//cl.result("Not_Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue, "", "Fail", "42584", 1, "Verify");
		}
		if (DistanceValue != DistanceAfterValue){
			System.out.println("Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue);
			//cl.result("Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue, "", "Pass", "42584", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue);
			//cl.result("Not_Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue, "", "Fail", "42584", 1, "Verify");
		}
	}

}
