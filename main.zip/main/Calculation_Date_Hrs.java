package com.onetx.selenium.main;

import java.awt.AWTException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Calculation_Date_Hrs {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		
		SimpleDateFormat inputFormatter = new SimpleDateFormat("'Week' w, E HH:mm");
		String inputDateString = "Week 1, Mon 12:00";
		int hoursToAdd = 12;
    try {
        Date inputDate = inputFormatter.parse(inputDateString);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(inputDate);

        int originalWeek = calendar.get(Calendar.WEEK_OF_YEAR);
        int originalDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        System.out.println("originalDayOfWeek--->"+originalDayOfWeek);
        int originalHour = calendar.get(Calendar.HOUR_OF_DAY);
        System.out.println("originalHour--->"+originalHour);
        int originalMinute = calendar.get(Calendar.MINUTE);
        System.out.println("originalMinute--->"+originalMinute);
        calendar.add(Calendar.HOUR_OF_DAY, hoursToAdd);

        int updatedWeek = calendar.get(Calendar.WEEK_OF_YEAR);
        int updatedDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        System.out.println("updatedDayOfWeek--->"+updatedDayOfWeek);
        int updatedHour = calendar.get(Calendar.HOUR_OF_DAY);
        int updatedMinute = calendar.get(Calendar.MINUTE);
        String updatedDateString = String.format("Week %d, %s %02d:%02d",updatedWeek, getDayOfWeek(updatedDayOfWeek),updatedHour,updatedMinute);

        //cl.log.info("Original Date and Time: " + inputDateString);
       // cl.log.info("Original Components: Week " + originalWeek + ", " + getDayOfWeek(originalDayOfWeek) + " " + originalHour + ":" + originalMinute);
       // cl.log.info("After adding " + hoursToAdd + " hours: " + updatedDateString);
        System.out.println("updatedDateString--->"+updatedDateString);
        //return updatedDateString;
    } catch (Exception e) {
        e.printStackTrace();
        //return null;
    }
}
	public static String getDayOfWeek(int dayOfWeek) {
		String[] daysOfWeek = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
		return daysOfWeek[dayOfWeek - 1];
	}
}
