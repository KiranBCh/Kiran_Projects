package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Arvind_47883 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);
	Actions actions = new Actions(driver);
	WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
	Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

	WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
	Pass.sendKeys("Alumni@2023" + Keys.ENTER);
	Thread.sleep(9000);
	
	driver.navigate().refresh();
	Thread.sleep(6000);
	
	
	WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
	JavascriptExecutor je = (JavascriptExecutor) driver;
	je.executeScript("arguments[0].click();", Services);
	Thread.sleep(9000);
	
	WebElement NewVessel = driver.findElement(By.xpath("//button[@id=\"btnCreateNewSchedule\"]"));
	NewVessel.click();
	Thread.sleep(5000);
	
	WebElement ManualToggle = driver.findElement(By.xpath("(//div[@class='q-toggle__track'])[1]"));
	actions.click(ManualToggle).perform();
	Thread.sleep(5000);
	
	WebElement ManualService = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[1]"));
	ManualService.click();
	ManualService.sendKeys("MAIKE D");
	Thread.sleep(2000);
	Robot robot = new Robot();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(2000);
	
	WebElement ManualOperator = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[2]"));
	ManualOperator.click();
	Thread.sleep(2000);
	
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	
	Thread.sleep(2000);
	
	WebElement ManualGenerate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
	ManualGenerate.click();
	Thread.sleep(5000);

	WebElement NavigateTo1 = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
	NavigateTo1.click();
	Thread.sleep(2000);
	
	WebElement AddPort = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
	AddPort.click();
//	waitSeconds();
	
	WebElement AddPortName = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
	AddPortName.click();		
	Thread.sleep(2000);
	
	AddPortName.sendKeys("AEAJM");
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
//	waitSeconds();
	Thread.sleep(3000);
	/*
	WebElement AddPort2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
	AddPort2.click();
//	waitSeconds();
	Thread.sleep(3000);
	
	WebElement AddPortName2 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
	AddPortName2.click();		
	Thread.sleep(3000);
	
	AddPortName2.sendKeys("BDMGL");
	Thread.sleep(1000);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
//	waitSeconds();
	Thread.sleep(3000);
	*/
	WebElement VesOp = driver.findElement(By.xpath("(//div[@class='q-field__append q-field__marginal row no-wrap items-center q-anchor--skip'])[4]"));
	VesOp.click();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(3000);

	WebElement Utilization = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[2]"));
	Utilization.click();
	Thread.sleep(3000);
	
	WebElement ExtVoy = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder text-center'])[1]"));
	ExtVoy.click();
	ExtVoy.sendKeys("123456"+Keys.ENTER);
	Thread.sleep(3000);
	
	WebElement ClickTerm = driver.findElement(By.xpath("//div[@class='data-table__sub-td']//div[@class='q-checkbox__bg absolute']//*[name()='svg']"));
	ClickTerm.click();
	Thread.sleep(4000);
	
	WebElement IntVoy = driver.findElement(By.xpath("//div[normalize-space()='EDIT INTERNAL VOYAGE NUMBER']"));
	IntVoy.click();
	Thread.sleep(4000);
	
	WebElement Toggle = driver.findElement(By.xpath("(//div[@class=\"q-toggle__inner relative-position non-selectable q-toggle__inner--falsy\"])[4]"));
	Toggle.click();
	Thread.sleep(4000);
	
	WebElement Confirm = driver.findElement(By.xpath("//span[contains(text(),'Confirm')]"));
	Confirm.click();
	Thread.sleep(4000);
	
	WebElement OpStatus = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-select__dropdown-icon'])[2]"));
	OpStatus.click();
	
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(3000);
	
	WebElement Vessel = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-select__dropdown-icon'])[7]"));
	Vessel.click();
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_DOWN);
	robot.keyRelease(KeyEvent.VK_DOWN);
	robot.keyPress(KeyEvent.VK_ENTER);
	robot.keyRelease(KeyEvent.VK_ENTER);
	Thread.sleep(3000);
	driver.findElement(By.xpath("//th[contains(text(), \"Operation Status\")]")).click();
	
	}
}
