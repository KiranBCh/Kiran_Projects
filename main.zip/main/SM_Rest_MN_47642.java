package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SM_Rest_MN_47642 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(3000);
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("ALS KRONOS");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(3000);

		WebElement Port = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::div[@class='q-field__native row items-center'])[1]"));
		actions.contextClick(Port).build().perform();
		Thread.sleep(4000);
		WebElement RestructureButton = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[1][@class='q-item__section column q-item__section--main justify-center header'])[4]"));
		RestructureButton.click();
		Thread.sleep(4000);
		
		//Verification 1st done
		WebElement TimePicker = driver.findElement(By.xpath("//div[@class='dateport']//div[@class='q-field__append q-field__marginal row no-wrap items-center']"));
		TimePicker.click();
		Thread.sleep(3000);
		
		//BeforeEffectdate		
		WebElement changeEffectTime = driver.findElement(By.xpath("(//div[@class='q-date__calendar-days fit']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense'])[3]"));
		changeEffectTime.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//h6[contains(text(), 'Remarks')]")).click();
		Thread.sleep(3000);
		
		WebElement DepartureTime = driver.findElement(By.xpath("//div[@class='port-details-container']//div[@class='port-details']//p[contains(text(), 'Departure Time')]//b"));
		String DepartureTimeValue = DepartureTime.getText().replace(",", "");

		if (DepartureTimeValue != null){
            System.out.println("DepartureTime " + DepartureTimeValue);
            //cl.ActualTestDataValue ="Departure datetime of Port";
	          //cl.result("Verifyed departure datetime "+  DepartureTimeValue, "Departure Date and Time" , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("DepartureTime " + DepartureTime);
            //cl.ActualTestDataValue ="Departure datetime of Port";
	          //cl.result("Not Verifyed departure datetime "+  DepartureTimeValue, "Departure Date and Time" , "Fail", "", 1, "VERIFY");
        }
		List<WebElement> AfterEffectdate = driver.findElements(By.xpath("(//div[@class='dateport']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[2]"));
		String AfterEffectdateValue = "";
		for(WebElement value : AfterEffectdate) {
			if(value.getAttribute("value") != null) {				
				AfterEffectdateValue = value.getAttribute("value");
				System.out.println("AfterEffectdateValue " + AfterEffectdateValue);
				break;
			}
		}
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");
        // Parse the date strings to LocalDateTime objects
        LocalDateTime date1 = LocalDateTime.parse(DepartureTimeValue, formatter);
        LocalDateTime date2 = LocalDateTime.parse(AfterEffectdateValue, formatter);

        if (date1.isBefore(date2)){
            System.out.println("User is able to select date and time to be greater than departure time/date of Port");
            //cl.ActualTestDataValue ="User is able to select datetime to be greater than departure datetime of Port";
	          //cl.result("Verifyed user is able to select the datetime to be greater than departure datetime "+ " After Effect date "+  AfterEffectdateValue, "User able to change the Date and Time" , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("User is not able to select date and time to be lesser than departure time/date of Port");
            //cl.ActualTestDataValue ="User is able to select datetime to be lesser than departure datetime of Port";
            //cl.result("Verifyed user is able to select the datetime to be greater than departure datetime "+ " After Effect date "+  AfterEffectdateValue, "User able to change the Date and Time" , "Fail", "", 1, "VERIFY");
        }
        
        WebElement TimePicker1 = driver.findElement(By.xpath("//div[@class='dateport']//div[@class='q-field__append q-field__marginal row no-wrap items-center']"));
		TimePicker1.click();
				
        WebElement LessThan = driver.findElement(By.xpath("//div[@class='q-date__calendar-days fit']//div[@class='q-date__calendar-item q-date__calendar-item--out']"));
        boolean LessThanValue = LessThan.getAttribute("class").contains("out");
        
        if (LessThanValue == true) {
            System.out.println("User is able to select date and time to be lesser than departure time/date of Port");
            //cl.ActualTestDataValue ="User is not able to select datetime to be lesser than departure datetime of Port";
	          //cl.result("Verifyed user is not able to select the datetime to be lesser than departure datetime", "Unable to change the Date and Time" , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("User is able to select date and time to be lesser than departure time/date of Port");
            //cl.ActualTestDataValue ="User is able to select datetime to be lesser than departure datetime of Port";
	          //cl.result("Verifyed user is able to select the datetime to be lesser than departure datetime", "Able to change the Date and Time" , "Fail", "", 1, "VERIFY");
        }
        
	}

}
