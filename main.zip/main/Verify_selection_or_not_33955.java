package com.onetx.selenium.main;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_selection_or_not_33955 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(7000);
	
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		vessle_click.click();
		Thread.sleep(7000);
	
		WebElement date_picker = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[2]"));
		date_picker.click();
		Thread.sleep(3000);
		
		LocalDate currentDate = LocalDate.now();
        // Find the next Monday
        LocalDate nextMonday = currentDate.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
		
        WebElement dateElement1 = driver.findElement(By.xpath("//span[@class='block'][normalize-space()='" + nextMonday.getDayOfMonth() +"']"));
		Thread.sleep(3000);
        dateElement1.click();
        
        boolean isEnabled = dateElement1.isEnabled();
        if (isEnabled){
        	System.out.println("Date is selected.");
        	//cl.result("Date_is_selected", "", "Pass", "33955", 1, "Date_is_selected");
        }
        else {
        	System.out.println("Date is not selected");
        	//cl.result("Date_is_not_selected", "", "Fail", "33955", 1, "Date_is_not_selected");
        }
		nextMonday = nextMonday.plusDays(1);
		int dayOfMonth = nextMonday.getDayOfMonth();
		
        WebElement dateElement2 = driver.findElement(By.xpath("//div[@class='q-date__calendar-item q-date__calendar-item--out']//div[contains(text(),'" + dayOfMonth + "')]"));
		Thread.sleep(3000);
		boolean isEnabled1 = dateElement2.isEnabled();
		if (isEnabled1 == false){
        	System.out.println("Date_is_selected.");
        	//cl.result("Date_is_selected", "", "Pass", "33955", 1, "Date_is_selected");
        }
        else {
        	System.out.println("Date_is_not_selected");
        	//cl.result("Date_is_not_selected", "", "Fail", "33955", 1, "Date_is_not_selected");
        }
		
	}

}
