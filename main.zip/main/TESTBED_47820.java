package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TESTBED_47820 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Test Bed')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id=\"btnCreateNewSchedule\"]"));
		vessle_click.click();
		Thread.sleep(7000);
	
		WebElement Searchbox = driver.findElement(By.xpath("//div[@id='existingScheduleDialog']//div[@class='row menuHeader']//input[@class='q-field__native q-placeholder']"));
		Searchbox.click();
		Searchbox.sendKeys("canal port");
		driver.findElement(By.xpath("(//div[contains(text(), 'canal port')]//preceding::div[1][@class='q-checkbox__bg absolute'])[1]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//span[contains(text(),'Load RC')]")).click();
		Thread.sleep(2000);
	}
		
}
