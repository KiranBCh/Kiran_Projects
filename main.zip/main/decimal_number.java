package com.onetx.selenium.main;

import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class decimal_number {

	public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
        driver.get("https://example.com"); // Replace with the URL of the page

        // Locate the WebElement that contains the value you want to verify
        WebElement field = driver.findElement(By.id("yourElementId")); // Replace with the actual element locator

        // Get the text from the WebElement
        String fieldValue = field.getText(); // You can also use .getAttribute("value") if it's an input field

        // Define a regular expression pattern to match the desired format
        String pattern = "\\d{3,}\\.\\d{2}";

        // Check if the field's text matches the pattern
        boolean isMatch = Pattern.matches(pattern, fieldValue);

        if (isMatch) {
            System.out.println("Field contains a number with two decimal places and at least three digits before the decimal point.");
        } else {
            System.out.println("Field does not match the desired format.");
        }

        driver.quit();
        
    }
}
