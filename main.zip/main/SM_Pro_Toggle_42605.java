package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Pro_Toggle_42605 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(8000);
		
		WebElement vessle_click = driver.findElement(By.xpath("//span[contains(text(), 'NEW SAILING VESSEL')]"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("PADMA");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		/*
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(3000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(3000);
		*/
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(3000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(3000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(3000);
      
        WebElement ScheduleInformation = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
        ScheduleInformation.click();
		Thread.sleep(3000);
		
		List<WebElement> VesselOperatorName = driver.findElements(By.xpath("(//div[@class='schedule-screen-frame']//tr[2]//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__native row items-center']//input[@class='q-field__input q-placeholder col'])[2]"));
		String VesselOperator = "";
		for(WebElement value : VesselOperatorName) {
			if(value.getAttribute("value") != null) {
				VesselOperator = value.getAttribute("value");
				break;
			}
		}
		WebElement ChangeVesselOperator = driver.findElement(By.xpath("(//div[@class='schedule-screen-frame']//tr[2]//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__native row items-center']//input[@class='q-field__input q-placeholder col'])[2]"));
		ChangeVesselOperator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		List<WebElement> VesselOperatorChange = driver.findElements(By.xpath("(//div[@class='schedule-screen-frame']//tr[2]//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__native row items-center']//input[@class='q-field__input q-placeholder col'])[2]"));
		String AfterVesselOperator = "";
		for(WebElement value : VesselOperatorChange) {
			if(value.getAttribute("value") != null) {
				AfterVesselOperator = value.getAttribute("value");
				break;
			}
		}
		if (VesselOperator != AfterVesselOperator){
			System.out.println("Verified_VesselOperator= " + VesselOperator + " AfterChangeVesselOperator= " + AfterVesselOperator);
			//cl.result("Verified_VesselOperator= " + VesselOperator + " AfterVesselOperator= " + AfterVesselOperator, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_VesselOperator= " + VesselOperator + " AfterChangeVesselOperator= " + AfterVesselOperator);
			//cl.result("Not_Verified_VesselOperator= " + VesselOperator + " AfterVesselOperator= " + AfterVesselOperator, "", "Fail", "42605", 1, "Verify");
		}
		//*******************CycleField*****************************
		List<WebElement> CycleField = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[10]//input[@class='q-field__native q-placeholder text-center']"));
		String CycleFieldName = "";
		for(WebElement value : CycleField) {
			if(value.getAttribute("value") != null) {
				CycleFieldName = value.getAttribute("value");
				break;
			}
		}
		WebElement CycleFieldClick = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[10]//input[@class='q-field__native q-placeholder text-center']"));
		CycleFieldClick.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value = '';", CycleFieldClick);
		CycleFieldClick.sendKeys("10");
		List<WebElement> AfterCycleField = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[10]//input[@class='q-field__native q-placeholder text-center']"));
		String AFterCycleFieldName = "";
		for(WebElement value : AfterCycleField) {
			if(value.getAttribute("value") != null) {
				AFterCycleFieldName = value.getAttribute("value");
				break;
			}
		}
		if (CycleFieldName != AFterCycleFieldName){
			System.out.println("Verified_CycleField= " + CycleFieldName + " AfterChangeCycleField= " + AFterCycleFieldName);
			//cl.result("Verified_CycleField= " + CycleFieldName + " AfterChangeCycleField= " + AFterCycleFieldName, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_CycleField= " + CycleFieldName + " AfterChangeCycleField= " + AFterCycleFieldName);
			//cl.result("Not_Verified_CycleField= " + CycleFieldName + " AfterChangeCycleField= " + AFterCycleFieldName, "", "Fail", "42605", 1, "Verify");
		}
		//*******************VesselPositionName*****************************
		List<WebElement> VesselPosition = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[11]//input[@class='q-field__native q-placeholder text-center']"));
		String VesselPositionName = "";
		for(WebElement value : VesselPosition) {
			if(value.getAttribute("value") != null) {
				VesselPositionName = value.getAttribute("value");
				break;
			}
		}
		WebElement AfterVesselPosition = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[11]//input[@class='q-field__native q-placeholder text-center']"));
		AfterVesselPosition.click();
		js.executeScript("arguments[0].value = '';", AfterVesselPosition);
		AfterVesselPosition.sendKeys("10");
		List<WebElement> AfterChangeVesselPosition = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[11]//input[@class='q-field__native q-placeholder text-center']"));
		String AfterChangeVesselPositionName = "";
		for(WebElement value : AfterChangeVesselPosition) {
			if(value.getAttribute("value") != null) {
				AfterChangeVesselPositionName = value.getAttribute("value");
				break;
			}
		}
		if (VesselPositionName != AfterChangeVesselPositionName){
			System.out.println("Verified_VesselPosition= " + VesselPositionName + " AfterChangeVesselPosition= " + AfterChangeVesselPositionName);
			//cl.result("Verified_VesselPosition= " + VesselPositionName + " AfterChangeVesselPosition= " + AfterChangeVesselPositionName, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_VesselPosition= " + VesselPositionName + " AfterChangeVesselPosition= " + AfterChangeVesselPositionName);
			//cl.result("Not_Verified_VesselPosition= " + VesselPositionName + " AfterChangeVesselPosition= " + AfterChangeVesselPositionName","", "Fail", "42605", 1, "Verify");
		}
		//*******************ExternalVoyageNumber*****************************
		List<WebElement> ExternalVoyageNumber = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[8]//input[@class='q-field__native q-placeholder text-center']"));
		String ExternalVoyageNumberName = "";
		for(WebElement value : ExternalVoyageNumber) {
			if(value.getAttribute("value") != null) {
				ExternalVoyageNumberName = value.getAttribute("value");
				break;
			}
		}
		WebElement AfterExternalVoyageNumber = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[11]//input[@class='q-field__native q-placeholder text-center']"));
		AfterExternalVoyageNumber.click();
		js.executeScript("arguments[0].value = '';", AfterExternalVoyageNumber);
		AfterExternalVoyageNumber.sendKeys("100000");
		List<WebElement> AfterFExternalVoyageNumber = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[11]//input[@class='q-field__native q-placeholder text-center']"));
		String AfterChangeExternalVoyageNumber = "";
		for(WebElement value : AfterFExternalVoyageNumber) {
			if(value.getAttribute("value") != null) {
				AfterChangeExternalVoyageNumber = value.getAttribute("value");
				break;
			}
		}
		if (ExternalVoyageNumberName != AfterChangeExternalVoyageNumber){
			System.out.println("Verified_ExternalVoyageNumber= " + ExternalVoyageNumberName + " AfterChangeExternalVoyageNumber= " + AfterChangeExternalVoyageNumber);
			//cl.result("Verified_ExternalVoyageNumber= " + ExternalVoyageNumberName + " AfterChangeExternalVoyageNumber= " + AfterChangeExternalVoyageNumber, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_ExternalVoyageNumber= " + ExternalVoyageNumberName + " AfterChangeExternalVoyageNumber= " + AfterChangeExternalVoyageNumber);
			//cl.result("Not_Verified_ExternalVoyageNumber= " + ExternalVoyageNumberName + " AfterChangeExternalVoyageNumber= " + AfterChangeExternalVoyageNumber,"", "Fail", "42605", 1, "Verify");
		}
		//*******************ServiceCode*****************************
		List<WebElement> ServiceCode = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[12]//input[@class='q-field__input q-placeholder col']"));
		String ServiceCodeName = "";
		for(WebElement value : ServiceCode) {
			if(value.getAttribute("value") != null) {
				ServiceCodeName = value.getAttribute("value");
				break;
			}
		}
		WebElement AfterServiceCode = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[12]//input[@class='q-field__input q-placeholder col']"));
		AfterServiceCode.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		List<WebElement> AfterServiceCodeName = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[12]//input[@class='q-field__input q-placeholder col']"));
		String AfterChangeServiceCode = "";
		for(WebElement value : AfterServiceCodeName) {
			if(value.getAttribute("value") != null) {
				AfterChangeServiceCode = value.getAttribute("value");
				break;
			}
		}
		if (ServiceCodeName != AfterChangeServiceCode){
			System.out.println("Verified_ServiceCode= " + ServiceCodeName + " AfterChangeServiceCode= " + AfterChangeServiceCode);
			//cl.result("Verified_ServiceCode= " + ServiceCodeName + " AfterChangeServiceCode= " + AfterChangeServiceCode, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Verified_ServiceCode= " + ServiceCodeName + " AfterChangeServiceCode= " + AfterChangeServiceCode);
			//cl.result("Not_Verified_ServiceCode= " + ServiceCodeName + " AfterChangeServiceCode= " + AfterChangeServiceCode, "", "Fail", "42605", 1, "Verify");
		}
		//*******************ServiceRotation*****************************
		WebElement ServiceRotation = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[13]"));
		String ServiceRotationName = ServiceRotation.getText();
		
		WebElement AfterServiceRotation = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[13]"));
		String AfterServiceRotationName = AfterServiceRotation.getText();
		if (ServiceRotationName != AfterServiceRotationName){
			System.out.println("Verified_ServiceRotation= " + ServiceRotationName + " AfterChangeServiceRotation= " + AfterServiceRotationName);
			//cl.result("Verified_ServiceRotation= " + ServiceRotationName + " AfterChangeServiceRotation= " + AfterChangeServiceRotation, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_ServiceRotation= " + ServiceRotationName + " AfterChangeServiceRotation= " + AfterServiceRotationName);
			//cl.result("Not_Verified_ServiceRotation= " + ServiceRotationName + " AfterChangeServiceRotation= " + AfterChangeServiceRotation, "", "Fail", "42605", 1, "Verify");
		}
		//*******************ServiceProduct*****************************
		List<WebElement> ServiceProduct = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[14]//input[@class='q-field__native q-placeholder text-center']"));
		String ServiceProductName = "";
		for(WebElement value : ServiceProduct) {
			if(value.getAttribute("value") != null) {
				ServiceProductName = value.getAttribute("value");
				break;
			}
		}
		WebElement AfterServiceProduct = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[14]//input[@class='q-field__native q-placeholder text-center']"));
		AfterServiceProduct.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		List<WebElement> AfterServiceProductName = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[14]//input[@class='q-field__native q-placeholder text-center']"));
		String AfterChangeServiceProductName = "";
		for(WebElement value : AfterServiceProductName) {
			if(value.getAttribute("value") != null) {
				AfterChangeServiceProductName = value.getAttribute("value");
				break;
			}
		}
		if (ServiceProductName != AfterChangeServiceProductName){
			System.out.println("Verified_ServiceProduct= " + ServiceProductName + " AfterChangeServiceProduct= " + AfterChangeServiceProductName);
			//cl.result("Verified_ServiceProduct= " + ServiceProductName + " AfterChangeServiceProduct= " + AfterChangeServiceProductName, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_ServiceProduct= " + ServiceProductName + " AfterChangeServiceProduct= " + AfterChangeServiceProductName);
			//cl.result(Not_Verified_ServiceProduct= " + ServiceProductName + " AfterChangeServiceProduct= " + AfterChangeServiceProductName, "", "Fail", "42605", 1, "Verify");
		}
		
		//*******************LegField*****************************
		List<WebElement> LegField = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[18]//input[@class='q-field__input q-placeholder col']"));
		String LegFieldName = "";
		for(WebElement value : LegField) {
			if(value.getAttribute("value") != null) {
				LegFieldName = value.getAttribute("value");
				break;
			}
		}
		WebElement AfterLegField = driver.findElement(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[18]//input[@class='q-field__input q-placeholder col']"));
		AfterLegField.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		List<WebElement> AfterLegFieldName = driver.findElements(By.xpath("//div[@class='schedule-screen-frame']//tr[2]//td[18]//input[@class='q-field__input q-placeholder col']"));
		String AfterLegFieldName1 = "";
		for(WebElement value : AfterLegFieldName) {
			if(value.getAttribute("value") != null) {
				AfterLegFieldName1 = value.getAttribute("value");
				break;
			}
		}
		if (LegFieldName != AfterLegFieldName1){
			System.out.println("Verified_Leg= " + LegFieldName + " AfterChangeLeg= " + AfterLegFieldName1);
			//cl.result("Verified_Leg= " + LegFieldName + " AfterChangeLeg= " + AfterLegFieldName1, "", "Pass", "42605", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Leg= " + LegFieldName + " AfterChangeLeg= " + AfterLegFieldName1);
			//cl.result("Verified_Leg= " + LegFieldName + " AfterChangeLeg= " + AfterLegFieldName1, "Fail", "42605", 1, "Verify");
		}
		
		
		
		
	}
}
