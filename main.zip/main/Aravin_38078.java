package com.onetx.selenium.main;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Aravin_38078 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(7000);
	
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		vessle_click.click();
		Thread.sleep(7000);
	
		WebElement toggle = driver.findElement(By.xpath("//*[@id='t1']"));
		Thread.sleep(3000);
		toggle.click();
		
		//WebElement Vessel_click = driver.findElement(By.xpath("//p[contains(text(), \"Vessel\")]//following-sibling::label[1]//div//input[@role=\"combobox\"][1]"));
		//Vessel_click.click();
		
		WebElement searchBox1 = driver.findElement(By.xpath("//p[contains(text(), \"Vessel\")]//following-sibling::label[1]//div//input[@role=\"combobox\"][1]"));
		Actions ac = new Actions(driver);
		Thread.sleep(4000);
		ac.click(searchBox1).perform();
		Thread.sleep(4000);
		
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]//following::div[27]"));		
		searchBox2.sendKeys("PADMA (PADMA 9152583)");
		Thread.sleep(2000);
		//WebElement selectname = driver.findElement(By.xpath("//div[text()='PADMA (PADMA 9152583)'"));
		//selectname.click();
		//Thread.sleep(7000);
		
	}
}
