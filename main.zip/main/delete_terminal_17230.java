package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class delete_terminal_17230 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement new_schedule_button = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		new_schedule_button.click();
		
		
		Thread.sleep(3000);
		WebElement Lane = driver.findElement(
				By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		Actions actions = new Actions(driver);
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(4000);
		
		WebElement elementToContextClick = driver.findElement(By.xpath("//div[@id='terminalDblClick']"));
		actions.contextClick(elementToContextClick).perform();
		Thread.sleep(7000);
		
		WebElement DeleteClick = driver.findElement(By.xpath("//div[@id='itmDeleteTerminal']"));
		DeleteClick.click();
		Thread.sleep(7000);
		
		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(4000);
		
		WebElement stay_value = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[16]"));
		
		WebElement buffer_time_value = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		
		if (stay_value.getText().equals(buffer_time_value.getText())){
			System.out.println("verifyed with Port Stay and Port Buffer");
		}
		else {
			System.out.println("Not verifyed with Port Stay and Port Buffer");
		}
		
		WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
		
		String pilotInText = PilotIn.getText();
		String pilotOutText = PilotOut.getText();
		
		int pilotInValue = Integer.parseInt(pilotInText);
		int pilotOutValue = Integer.parseInt(pilotOutText);
		
		if (pilotInValue == 0 && pilotOutValue == 0) {
			System.out.println("verifyed with PilotIn and PilotOut");
		}
		else {
			System.out.println("Not verifyed with PilotIn and PilotOut");
		}
	}

}
