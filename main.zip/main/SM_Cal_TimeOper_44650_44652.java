package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Cal_TimeOper_44650_44652 {
	
	/*
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		Thread.sleep(9000);
		
		WebElement vessle_click = driver.findElement(By.xpath("//span[contains(text(), 'NEW SAILING VESSEL')]"));
		vessle_click.click();
		Thread.sleep(8000);
		
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		ac.click(searchBox1).perform();
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(3000);
		
		WebElement VerifyProfoma = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		VerifyProfoma.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("PADMA");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(5000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
      
        WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(8000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement StayText = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", StayText);
		
		List<WebElement> Speed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedValue = "";
		for(WebElement value : Speed) {
			if(value.getAttribute("value") != null) {				
				SpeedValue = value.getAttribute("value");
				//System.out.println("Speed= "+SpeedValue);
				break;
			}
		}
		
		Thread.sleep(4000);
		WebElement EnterDistance = driver.findElement(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		EnterDistance.click();
		EnterDistance.sendKeys("100");
		Thread.sleep(4000);
		WebElement Distanceenter = driver.findElement(By.xpath("//th[normalize-space()='Distance (NM)']"));
		Distanceenter.click();
		Thread.sleep(4000);
		
		List<WebElement> AfterSpeed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String AfterSpeedValue = "";
		for(WebElement value : AfterSpeed) {
			if(value.getAttribute("value") != null) {				
				AfterSpeedValue = value.getAttribute("value");
				break;
			}
		}
		if (SpeedValue != AfterSpeedValue){
			System.out.println("Verified_Speed_AfterChanging_TheDistance= " +SpeedValue + " AfterSpeed= "+ AfterSpeedValue);
			//cl.result("Changed_Speed_AfterChanging_The_Distance= " +SpeedValue + " AfterSpeed= "+ AfterSpeedValue, "", "Pass", "44650", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Speed_AfterChanging_TheDistance= " +SpeedValue + " AfterSpeed= "+ AfterSpeedValue);
			//cl.result("Not_Changed_Speed_AfterChanging_The_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue, "", "Fail", "44650", 1, "Verify");
		}
		WebElement AfterDistanceVerify = driver.findElement(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		AfterDistanceVerify.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		
		//***************code here for 44652*************************************
		WebElement BufferTime = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[3]//td[28]"));
		String BeforeBufferTime = BufferTime.getText();
		//System.out.println("BufferTime= "+ BufferTime.getText());
		
		WebElement TerminalStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[26]"));
		System.out.println("TerminalStay= "+TerminalStay.getText());
		List<WebElement> TerminalOperation = driver.findElements(By.xpath("//th[normalize-space()='Operation Time']//following::tr[3]//td[27]//label//div//input[@class='q-field__native q-placeholder text-center']"));
		String TerminalOperationValue = "";
		for(WebElement value : TerminalOperation) {
			if(value.getAttribute("value") != null) {				
				TerminalOperationValue = value.getAttribute("value");
				//System.out.println("TerminalOperation= "+ TerminalOperationValue);
				break;
			}
		}
		WebElement AfterTerminalOperation = driver.findElement(By.xpath("//th[normalize-space()='Operation Time']//following::tr[3]//td[27]//label//div//input[@class='q-field__native q-placeholder text-center']"));
		AfterTerminalOperation.click();
		js.executeScript("arguments[0].value = '';", AfterTerminalOperation);
		AfterTerminalOperation.sendKeys("6");
		Thread.sleep(4000);
		
		WebElement empty = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']"));
		empty.click();
		Thread.sleep(4000);
		
		WebElement AfterBufferTime = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[3]//td[28]"));
		String AfterBufferTimeValue = AfterBufferTime.getText();
		int ABTValue = Integer.parseInt(AfterBufferTime.getText());
		int BBTValue = Integer.parseInt(BufferTime.getText());
        if (ABTValue != BBTValue) {
        	System.out.println("Verifyed_TerminalBufferTime_Before="+ BeforeBufferTime + "AfterBufferTime" + AfterBufferTimeValue);
        	//cl.result("Verifyed_TerminalBufferTime_Before="+ BeforeBufferTime + "AfterBufferTime" + AfterBufferTimeValue, "", "Pass", "44652", 1, "Verify");
        }
        else {
        	System.out.println("Verifyed_TerminalBufferTime_Before="+ BeforeBufferTime + "AfterBufferTime" + AfterBufferTimeValue);
        	//cl.result("Not_Verifyed_TerminalBufferTime_Before="+ BeforeBufferTime + "AfterBufferTime" + AfterBufferTimeValue, "", "Fail", "44652", 1, "Verify");
        }
        //********************Manuall Schedule click on********************************************
        //Click on Back button //div[@class='arrow_back']
       */ 
    public static void main(String[] args) throws InterruptedException, AWTException {
    	System.out.println("****************************");
    		
    		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
    		
    		ChromeDriver driver = new ChromeDriver();

    		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
    		driver.get(domain_url);
    		driver.manage().window().maximize();
    		Thread.sleep(5000);

    		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

    		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
    		Thread.sleep(3000);

    		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
    		Pass.sendKeys("Alumni@2023");		
    		Thread.sleep(3000);

    		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
    		Signin.click();
    		Thread.sleep(3000);
    		String string1 = domain_url + "/schedule/services/gantt";
    		driver.get(string1);
    		
    		Thread.sleep(9000);
    		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
    		Thread.sleep(8000);
    		vessle_click.click();
    		Thread.sleep(7000);
    		
    		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
    		ToggleButton.click();
    		Thread.sleep(2000);
    		
    		WebElement VesselNameClick = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
    		VesselNameClick.click();
    		Thread.sleep(2000);
    		Robot robot = new Robot();
    		Thread.sleep(3000);
    		robot.keyPress(KeyEvent.VK_DOWN);
    		robot.keyRelease(KeyEvent.VK_DOWN);
    		robot.keyPress(KeyEvent.VK_ENTER);
    		robot.keyRelease(KeyEvent.VK_ENTER);
    		Thread.sleep(2000);
    		
    		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
    		vessel_click3.click();
    		Thread.sleep(2000);
    		
    		robot.keyPress(KeyEvent.VK_DOWN);
    		robot.keyRelease(KeyEvent.VK_DOWN);
    		robot.keyPress(KeyEvent.VK_ENTER);
    		robot.keyRelease(KeyEvent.VK_ENTER);
    		Thread.sleep(2000);
    		
    		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
    		generator.click();
    		Thread.sleep(2000);
    		
    		WebElement ScheduleInformation = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
    		ScheduleInformation.click();
    		Thread.sleep(8000);
    				
    		WebElement AddPort = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
    		AddPort.click();
    		Thread.sleep(3000);
    		
    		WebElement AddPortName = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
    		AddPortName.click();		
    		Thread.sleep(3000);
    		
    		Thread.sleep(4000);
    		AddPortName.sendKeys("AEAJM");
    		robot.keyPress(KeyEvent.VK_DOWN);
    		robot.keyRelease(KeyEvent.VK_DOWN);
    		robot.keyPress(KeyEvent.VK_ENTER);
    		robot.keyRelease(KeyEvent.VK_ENTER);
    		Thread.sleep(3000);
    		
    		WebElement AddPort2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
    		AddPort2.click();
    		Thread.sleep(3000);
    		
    		WebElement AddPortName2 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
    		AddPortName2.click();		
    		Thread.sleep(3000);
    		
    		AddPortName2.sendKeys("BDMGL");
    		Thread.sleep(4000);
    		robot.keyPress(KeyEvent.VK_DOWN);
    		robot.keyRelease(KeyEvent.VK_DOWN);
    		robot.keyPress(KeyEvent.VK_ENTER);
    		robot.keyRelease(KeyEvent.VK_ENTER);
    		Thread.sleep(4000);
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    		WebElement StayText = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']"));
    		js.executeScript("arguments[0].scrollIntoView(true);", StayText);
    		List<WebElement> Speed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
    		String SpeedValue = "";
    		for(WebElement value : Speed) {
    			if(value.getAttribute("value") != null) {				
    				SpeedValue = value.getAttribute("value");
    				break;
    			}
    		}
    		
    		Thread.sleep(4000);
    		WebElement EnterDistance = driver.findElement(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
    		EnterDistance.click();
    		EnterDistance.sendKeys("100");
    		Thread.sleep(4000);
    		WebElement Distanceenter = driver.findElement(By.xpath("//th[normalize-space()='Distance (NM)']"));
    		Distanceenter.click();
    		Thread.sleep(4000);
    		
    		List<WebElement> AfterSpeed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
    		String AfterSpeedValue = "";
    		for(WebElement value : AfterSpeed) {
    			if(value.getAttribute("value") != null) {				
    				AfterSpeedValue = value.getAttribute("value");
    				break;
    			}
    		}
    		if (SpeedValue != AfterSpeedValue){
    			System.out.println("Verified_Speed_AfterChanging_TheDistance= " +SpeedValue + " AfterSpeed= "+ AfterSpeedValue);
    			//cl.result("Changed_Speed_AfterChanging_The_Distance= " +SpeedValue + " AfterSpeed= "+ AfterSpeedValue, "", "Pass", "44650", 1, "Verify");
    		}
    		else {
    			System.out.println("Not_Verified_Speed_AfterChanging_TheDistance= " +SpeedValue + " AfterSpeed= "+ AfterSpeedValue);
    			//cl.result("Not_Changed_Speed_AfterChanging_The_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue, "", "Fail", "44650", 1, "Verify");
    		}
    		WebElement AfterDistanceVerify = driver.findElement(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
    		AfterDistanceVerify.click();
    		robot.keyPress(KeyEvent.VK_DOWN);
    		robot.keyRelease(KeyEvent.VK_DOWN);
    		//Manu***********************************************************
    		WebElement BufferTime = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[3]//td[28]"));
    		String BeforeBufferTime = BufferTime.getText();
    		//System.out.println("BufferTime= "+ BufferTime.getText());
    		
    		WebElement TerminalStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[3]//td[26]"));
    		System.out.println("TerminalStay= "+TerminalStay.getText());
    		List<WebElement> TerminalOperation = driver.findElements(By.xpath("//th[normalize-space()='Operation Time']//following::tr[3]//td[27]//label//div//input[@class='q-field__native q-placeholder text-center']"));
    		String TerminalOperationValue = "";
    		for(WebElement value : TerminalOperation) {
    			if(value.getAttribute("value") != null) {				
    				TerminalOperationValue = value.getAttribute("value");
    				//System.out.println("TerminalOperation= "+ TerminalOperationValue);
    				break;
    			}
    		}
    		WebElement AfterTerminalOperation = driver.findElement(By.xpath("//th[normalize-space()='Operation Time']//following::tr[3]//td[27]//label//div//input[@class='q-field__native q-placeholder text-center']"));
    		AfterTerminalOperation.click();
    		js.executeScript("arguments[0].value = '';", AfterTerminalOperation);
    		AfterTerminalOperation.sendKeys("6");
    		Thread.sleep(4000);
    		
    		WebElement empty = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']"));
    		empty.click();
    		Thread.sleep(4000);
    		
    		WebElement AfterBufferTime = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[3]//td[28]"));
    		String AfterBufferTimeValue = AfterBufferTime.getText();
    		int ABTValue = Integer.parseInt(AfterBufferTime.getText());
    		int BBTValue = Integer.parseInt(BufferTime.getText());
            if (ABTValue != BBTValue) {
            	System.out.println("Verifyed_TerminalBufferTime,BeforeBufferTime= "+ BeforeBufferTime + "AfterBufferTime= " + AfterBufferTimeValue);
            	//cl.result("Verifyed_TerminalBufferTime,BeforeBufferTime= "+ BeforeBufferTime + "AfterBufferTime= " + AfterBufferTimeValue, "", "Pass", "44652", 1, "Verify");
            }
            else {
            	System.out.println("Not_Verifyed_TerminalBufferTime,BeforeBufferTime= "+ BeforeBufferTime + "AfterBufferTime= " + AfterBufferTimeValue);
            	//cl.result("Not_Verifyed_TerminalBufferTime,BeforeBufferTime= "+ BeforeBufferTime + "AfterBufferTime= " + AfterBufferTimeValue, "", "Fail", "44652", 1, "Verify");
            }
    		
	}
}
