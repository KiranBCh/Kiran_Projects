package com.onetx.selenium.main;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

public class Monday_date {
	/*
	public static void main(String[] args) {
        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Find the next Monday
        LocalDate nextMonday = currentDate.with(TemporalAdjusters.next(DayOfWeek.MONDAY));

        System.out.println("Current Date: " + currentDate);
        System.out.println("Next Monday: " + nextMonday);
        
        
    }
	public static void main(String[] args) {
        // Define the times "12:00" and "00:00"
        LocalTime noon = LocalTime.parse("12:00");
        LocalTime midnight = LocalTime.parse("00:00");

        // Calculate the time difference
        Duration duration = Duration.between(noon, midnight);

        // Get the difference in hours and minutes
        long hours = Math.abs(duration.toHours());
        long minutes = Math.abs(duration.toMinutes() % 60);

        System.out.println("Time difference: " + hours + " hours " + minutes + " minutes");
    }
	*/
	
	public static void main(String[] args) {
        // Define the initial time as "Mon 12:00"
        LocalTime initialTime = LocalTime.parse("Mon 12:00", DateTimeFormatter.ofPattern("E HH:mm"));

        // Add 12 hours to the initial time
        LocalTime resultTime = initialTime.plusHours(12);

        // Format and print the result
        String result = resultTime.format(DateTimeFormatter.ofPattern("E HH:mm"));
        System.out.println("12 hours after 'Mon 12:00' is: " + result);
    }
	public static String DaysBetweenDates(String input1, String input2) {
		// Define the date-time format
		SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");

		try {
			// Parse the input strings into Date objects
			Date date1 = (Date) dateFormat.parse(input1);
			Date date2 = (Date) dateFormat.parse(input2);

			// Calculate the difference in milliseconds between the two dates
			long millisecondsDifference = date2.getTime() - date1.getTime();

			// Convert milliseconds to days, hours, and minutes
			double daysDifference = millisecondsDifference / (24.0 * 60 * 60 * 1000);

			// Round off the days to the nearest half-day
			double roundedDays = Math.round(daysDifference * 2) / 2.0;

			// Display the result
			System.out.println("Difference between " + input1 + " and " + input2 + " is " + roundedDays + " days.");

			String DaysCount = Double.toString(roundedDays);

			return DaysCount;

		} catch (ParseException e) {
			// Handle parsing exceptions
			e.printStackTrace();
			return null;
		}
	}



}
