package com.onetx.selenium.main;
import java.time.DayOfWeek;
import java.time.LocalDate;
public class LastMonth_Monday {
	public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalDate lastMonth = today.minusMonths(1);

        // Find the last Monday of the previous month
        LocalDate lastMonthMonday = lastMonth.with(DayOfWeek.MONDAY);
        
        // If lastMonthMonday is after lastMonth, subtract 7 days to get the last Monday
        if (lastMonthMonday.isAfter(lastMonth)) {
            lastMonthMonday = lastMonthMonday.minusWeeks(1);
        }

        System.out.println("Today: " + today);
        System.out.println("Last Month: " + lastMonth);
        System.out.println("Last Month's Last Monday: " + lastMonthMonday.getDayOfMonth());
    }

}
