package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_47677_UserSelectsCopyPrevious {
	public static void main(String[] args) throws InterruptedException, AWTException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);

		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		Actions action = new Actions(driver);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Robot robot = new Robot();
		
		WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
		
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("kiranschedule");
		Thread.sleep(4000);
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'kiranschedule')]"));
		Sch1.click();
		Thread.sleep(3000);

		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("WAN HAI 263");
		Thread.sleep(5000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("6");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        Prefix.sendKeys("HH");
        Thread.sleep(4000);
      
        WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        Suffix.sendKeys("20");
        Thread.sleep(8000);

        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        
        
        Thread.sleep(4000);
        driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']")).click();
        for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		} 
		WebElement ClickTerminal2 = driver.findElement(By.xpath("(//div[@class='data-table__sub-td'])[5]"));
		ClickTerminal2.click();
		Thread.sleep(4000);
		
		WebElement EditInternalVoyagetext = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered'][1]//td[9]"));
		String EditInternalVoyagetextValue = EditInternalVoyagetext.getText();
		System.out.println("EditInternalVoyagetextValue "+ EditInternalVoyagetextValue);
		
		driver.findElement(By.xpath("//button[@id='btnServicesEditInternalVoyageNumber']")).click();
		
		WebElement CopyPrevioustoggleButton = driver.findElement(By.xpath("//div[@class='q-card__section q-card__section--vert'][2]//div[1]//div[@class='toggle-items']//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy']"));
        CopyPrevioustoggleButton.click();
       
        driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
        
        WebElement EditInternalVoyagetext1 = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//td[9]"));
		String EditInternalVoyagetextValue1 = EditInternalVoyagetext1.getText();
		System.out.println("EditInternalVoyagetextValueAfter "+ EditInternalVoyagetextValue1);
        
		
		WebElement Back = driver.findElement(By.xpath("//div[@class='arrow_back']//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']"));
		Back.click();
		Thread.sleep(8000);
		
		WebElement newSailing1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing1.click();
		Thread.sleep(5000);
		Actions actions = new Actions(driver);
		WebElement ManualToggle = driver.findElement(By.xpath("(//div[@class='q-toggle__track'])[1]"));
		actions.click(ManualToggle).perform();
		Thread.sleep(7000);
			
		WebElement ManualService = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		ManualService.click();
		ManualService.sendKeys("WAN HAI 263");
		Thread.sleep(4000);
			
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
			
		WebElement ManualOperator = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[2]"));
		ManualOperator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
			
		Thread.sleep(4000);
			
		WebElement ManualGenerate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
		ManualGenerate.click();
		Thread.sleep(2000);	
		
		WebElement ScheduleInformation = driver.findElement(By.xpath("(//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation'])[2]"));
		ScheduleInformation.click();
		Thread.sleep(8000);
		
		//First Port 
		driver.findElement(By.xpath("//span[contains(text(),'Add port & Terminal')]")).click();
		Thread.sleep(7000);
		
		WebElement terminal1Checkbox = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[3]"));
		terminal1Checkbox.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[@id='btnServicesEditInternalVoyageNumber']")).click();
		
		WebElement GenerateNumber = driver.findElement(By.xpath("//div[@class='q-card__section q-card__section--vert'][2]//div[@class='toggle-items']//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']"));
		GenerateNumber.click();
		Thread.sleep(2000);
		
        driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
        
        WebElement terminalunselect = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[3]"));
        terminalunselect.click();
		Thread.sleep(3000);
		// First Port Unselect 
		driver.findElement(By.xpath("//span[contains(text(),'Add port & Terminal')]")).click();
		Thread.sleep(5000);
		
		WebElement terminal1Checkbox2 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
		terminal1Checkbox2.click();
		Thread.sleep(3000);
				
		driver.findElement(By.xpath("//button[@id='btnServicesEditInternalVoyageNumber']")).click();
		Thread.sleep(5000);
		
		WebElement GenerateNumber2 = driver.findElement(By.xpath("//div[@class='q-card__section q-card__section--vert'][2]//div[@class='toggle-items']//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']"));
		GenerateNumber2.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
		
		WebElement terminal1Checkbox2UnSelect = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
		terminal1Checkbox2UnSelect.click();
		Thread.sleep(3000);
		/// Second Port Unselect
		
		driver.findElement(By.xpath("//span[contains(text(),'Add port & Terminal')]")).click();
		Thread.sleep(5000);
		
		WebElement terminal1Checkbox3 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[9]"));
		terminal1Checkbox3.click();
		Thread.sleep(3000);
				
		driver.findElement(By.xpath("//button[@id='btnServicesEditInternalVoyageNumber']")).click();
		Thread.sleep(3000);
		
		WebElement GenerateNumber3 = driver.findElement(By.xpath("//div[@class='q-card__section q-card__section--vert'][2]//div[@class='toggle-items']//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']"));
		GenerateNumber3.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
		
		WebElement TerminalCheckboxFinal = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[9]"));
		TerminalCheckboxFinal.click();
		Thread.sleep(3000);
		// FInal Calculation		
		WebElement EditInternalVoyagetextMan = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered'][1]//td[9]"));
		String EditInternalVoyagetextManValue = EditInternalVoyagetextMan.getText();
		System.out.println("EditInternalVoyagetextValue "+ EditInternalVoyagetextManValue);
		
		WebElement terminal1CheckboxCal = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
		terminal1CheckboxCal.click();
				
		driver.findElement(By.xpath("//button[@id='btnServicesEditInternalVoyageNumber']")).click();
		Thread.sleep(3000);
		
		WebElement CopyPreviousButton = driver.findElement(By.xpath("(//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap'])[1]"));
		CopyPreviousButton.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']//span[contains(text(), 'Confirm')]")).click();
		
		WebElement EditInternalVoyagetext3 = driver.findElement(By.xpath("//tr[@class='data-table__row data-table__row--centered selected-row']//td[9]"));
		String EditInternalVoyagetextValue3 = EditInternalVoyagetext3.getText();
		System.out.println("EditInternalVoyagetextValueAfter "+ EditInternalVoyagetextValue3);
		
	}

}
