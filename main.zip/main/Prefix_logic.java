package com.onetx.selenium.main;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Prefix_logic {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		String Kiran1 = "32890H";
		//Total number of characters of voyage number
		//Case1
		
		
		
		
	}

}
