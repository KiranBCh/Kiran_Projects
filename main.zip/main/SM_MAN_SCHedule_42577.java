package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_MAN_SCHedule_42577 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		Thread.sleep(7000);
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement vessle_click1 = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'][1]"));
		vessle_click1.click();
		Thread.sleep(2000);
		
		WebElement vessel_click = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		vessel_click.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		Actions actions = new Actions(driver);
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		
	    WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
				
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,200)","");
		
		Thread.sleep(3000);
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		
		AddPortName2.sendKeys("INNSA");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement AddTwoTerminalName = driver.findElement(By.xpath("(//div[@id='terminalDblClick'])[2]"));
		AddTwoTerminalName.click();
		WebElement AddTerminal = driver.findElement(By.xpath("(//div[@class='terminalNameContainer']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddTerminal).doubleClick().perform();
		AddTerminal.sendKeys("JNP");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		List<WebElement> FirstPortName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		boolean ispresentflag = false;
		for(WebElement value : FirstPortName) {
			if(value.getAttribute("value").equals("AEAJM")) {				
				ispresentflag = true;
				//System.out.println("FirstPortName= "+ispresentflag);
				cl.result("Verified_FirstPortName AEAJM=" + ispresentflag , "", "Pass", "42577", 1, "Verify");
				break;
			}
			else {
				cl.result("Not_Verified_FirstPortName AEAJM=" + ispresentflag , "", "Fail", "42577", 1, "Verify");
			}
		}
		
		List<WebElement> FirstTerminalName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		boolean ispresentflag1 = false;
		for(WebElement value : FirstTerminalName) {
			if(value.getAttribute("value").equals("AJM")) {				
				ispresentflag1 = true;
				//System.out.println("FirstTerminalName= "+ispresentflag1);
				cl.result("Verified_FirstTerminalName AJM=" + ispresentflag1 , "", "Pass", "42577", 1, "Verify");
				break;
			}
			else {
				cl.result("Not_Verified_FirstTerminalName AJM=" + ispresentflag1 , "", "Fail", "42577", 1, "Verify");
			}
		}
		
		List<WebElement> SecondPortName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[3]"));
		boolean ispresentflag2 = false;
		for(WebElement value : SecondPortName) {
			if(value.getAttribute("value").equals("INNSA")) {				
				ispresentflag2 = true;
				//System.out.println("SecondPortName= "+ispresentflag2);
				cl.result("Verified_SecondPortName INNSA=" + ispresentflag2 , "", "Pass", "42577", 1, "Verify");
				break;
			}
			else {
				cl.result("Not_Verified_SecondPortName INNSA=" + ispresentflag2 , "", "Fail", "42577", 1, "Verify");
			}
		}
		
		List<WebElement> SecondTerminalName = driver.findElements(By.xpath("(//input[@class='q-field__input q-placeholder col'])[4]"));
		boolean ispresentflag3 = false;
		for(WebElement value : SecondTerminalName) {
			if(value.getAttribute("value").equals("JNP")) {				
				ispresentflag3 = true;
				//System.out.println("SecondTerminalName= "+ispresentflag3);
				cl.result("Verified_SecondTerminalName JNP=" + ispresentflag3 , "", "Pass", "42577", 1, "Verify");
				break;
			}
			else {
				cl.result("Not_Verified_SecondTerminalName JNP=" + ispresentflag3 , "", "Fail", "42577", 1, "Verify");
			}
		}
		
		//driver.close();
		
		
//		below
		//WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		
		//((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		
		
	}

}
