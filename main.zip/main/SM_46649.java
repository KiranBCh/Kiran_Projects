package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SM_46649 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		WebElement VesselNameClick = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		/*
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		*/
		Thread.sleep(2000);
		
		//ArrivalTime
		WebElement ArrivalTime = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-arrival-001']"));
		actions.moveToElement(ArrivalTime).doubleClick().perform();
		List<WebElement> ArrivalTimeHours = driver.findElements(By.xpath("//div[@id='port-arrival-001']//select[@id='gantt-hours']//option"));
		boolean is24HourFormatA = ArrivalTimeHours.size() == 24;
        List<WebElement> ArrivalTimeMinutes = driver.findElements(By.xpath("//div[@id='port-arrival-001']//select[@id='gantt-min']//option"));
        boolean hasAllMinutesA = ArrivalTimeMinutes.size() == 60;
        if (is24HourFormatA && hasAllMinutesA){
			cl.result("Verifying ", "ArrivalTimeHours:" + ArrivalTimeHours.size() +" ArrivalTimeMinutes:"+ ArrivalTimeMinutes.size(), "Pass", "46649", 1, "Verify");
		}
        else {
			cl.result("Not_Verifying ", "ArrivalTimeHours, ArrivalTimeMinutes", "Fail", "46649", 1, "Verify");
		}
        driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
        Thread.sleep(2000);
        
        //DepartureTime
        WebElement DepartureTime = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
        actions.moveToElement(DepartureTime).doubleClick().perform();
        List<WebElement> DepartureTimeHours = driver.findElements(By.xpath("//div[@id='port-departure-001']//select[@id='gantt-hours']//option"));
		boolean is24HourFormatD = DepartureTimeHours.size() == 24;
        //System.out.println("Hours in 24h format (00 to 23): " + is24HourFormatD);
        List<WebElement> DepartureTimeMinutes = driver.findElements(By.xpath("//div[@id='port-departure-001']//select[@id='gantt-min']//option"));
        boolean hasAllMinutesD = DepartureTimeMinutes.size() == 60;
        //System.out.println("Possible minutes in an hour (00 to 59): " + hasAllMinutesD+"-->"+DepartureTimeMinutes.size());
        if (is24HourFormatD && hasAllMinutesD){
			cl.result("Verifying ", "DepartureTimeHours:" + DepartureTimeHours.size() +" DepartureTimeMinutes:"+ DepartureTimeMinutes.size(), "Pass", "46649", 1, "Verify");
		}
        else {
			cl.result("Not_Verifying ", "DepartureTimeHours, DepartureTimeMinutes", "Fail", "46649", 1, "Verify");
		}
		
		driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
		Thread.sleep(2000);
		
		//TerminalBirthTime
		WebElement TerminalTime = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-berth-0001']"));
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String doubleClickScript = "var element = arguments[0];" +
                "var mouseEvent = document.createEvent('MouseEvents');" +
                "mouseEvent.initEvent('dblclick', true, true);" +
                "element.dispatchEvent(mouseEvent);";
        
       WebElement sel = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
       Select sele_hours = new Select(sel);
       sele_hours.selectByValue("2");
       
        jsExecutor.executeScript(doubleClickScript, TerminalTime);
		List<WebElement> TerminalTimeHours = driver.findElements(By.xpath("//div[@id='term-berth-0001']//select[@id='gantt-hours']//option"));
		boolean is24HourFormatT = TerminalTimeHours.size() == 24;
        List<WebElement> TerminalTimeMinutes = driver.findElements(By.xpath("//div[@id='term-berth-0001']//select[@id='gantt-min']//option"));
        boolean hasAllMinutesT = TerminalTimeMinutes.size() == 60;
        if (is24HourFormatT && hasAllMinutesT){
			cl.result("Verifying ", "TerminalBerthTimeHours:" + TerminalTimeHours.size() +" TerminalBerthTimeMinutes:"+ TerminalTimeMinutes.size(), "Pass", "46649", 1, "Verify");
		}
        else {
			cl.result("Not_Verifying ", "TerminalBerthTimeHours, TerminalBerthTimeMinutes", "Fail", "46649", 1, "Verify");
		}
        driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
        Thread.sleep(2000);
		//TerminalUnberthTime 
        WebElement TerminalTimeUnberth = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-unberth-0001']"));
        String doubleClickScript1 = "var element = arguments[0];" +
                "var mouseEvent = document.createEvent('MouseEvents');" +
                "mouseEvent.initEvent('dblclick', true, true);" +
                "element.dispatchEvent(mouseEvent);";
        jsExecutor.executeScript(doubleClickScript1, TerminalTimeUnberth);
        List<WebElement> TerminalUnberthTimeHours = driver.findElements(By.xpath("//div[@id='term-unberth-0001']//select[@id='gantt-hours']//option"));
		boolean is24HourFormatT2 = TerminalUnberthTimeHours.size() == 24;
        List<WebElement> TerminalUnberthTimeMinutes = driver.findElements(By.xpath("//div[@id='term-unberth-0001']//select[@id='gantt-min']//option"));
        boolean hasAllMinutesT2 = TerminalUnberthTimeMinutes.size() == 60;
        if (is24HourFormatT2 && hasAllMinutesT2){
			cl.result("Verifying ", "TerminalUnberthTimeHours:" + TerminalUnberthTimeHours.size() +" TerminalUnberthTimeHours:"+ TerminalUnberthTimeMinutes.size(), "Pass", "46649", 1, "Verify");
		}
        else {
			cl.result("Not_Verifying ", "TerminalUnberthTimeHours, TerminalUnberthTimeHours", "Fail", "46649", 1, "Verify");
		}
        
        
       
	}

}
