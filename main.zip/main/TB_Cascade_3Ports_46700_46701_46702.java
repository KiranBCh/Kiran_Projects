package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TB_Cascade_3Ports_46700_46701_46702 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		Actions actions = new Actions(driver);
		//Robot robot = new Robot();
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)",""); //200 change
		Thread.sleep(3000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
	 
		WebElement ArrivalTime = driver.findElement(By.xpath("//div[@class='timings']//div[@id='port-arrival-00']"));
		String ArrivalTimeValue = ArrivalTime.getText();
		if (ArrivalTimeValue != null){
            System.out.println("ArrivalTime= " + ArrivalTimeValue);
            cl.ActualTestDataValue ="ArrivalTime= ";
	        cl.result("Verifyed Arrival Time= "+  ArrivalTimeValue, "Arrival Time" , "Pass", "", 1, "VERIFY");
        }
		WebElement DepartureTime = driver.findElement(By.xpath("//div[@class='timings']//div[@id='port-departure-00']"));
		String DepartureTimeValue = DepartureTime.getText();
		if (DepartureTimeValue != null){
            System.out.println("DepartureTime= " + DepartureTimeValue);
            cl.ActualTestDataValue ="DepartureTime= ";
	        cl.result("Verifyed Departure Time= "+  DepartureTimeValue, "Departure Time" , "Pass", "", 1, "VERIFY");
        }
		
		WebElement BerthTime = driver.findElement(By.xpath("//div[@class='timings']//div[@id='term-berth-000']"));
		String BerthTimeValue = BerthTime.getText();
		if (BerthTimeValue != null){
            System.out.println("BerthTime= " + BerthTimeValue);
            cl.ActualTestDataValue ="BerthTime= ";
	        cl.result("Verifyed Berth Time= "+  BerthTimeValue, "Berth Time" , "Pass", "", 1, "VERIFY");
        }
		
		WebElement UnBerthTime = driver.findElement(By.xpath("//div[@class='timings']//div[@id='term-unberth-000']"));
		String UnBerthTimeValue = UnBerthTime.getText();
		if (BerthTimeValue != null){
            System.out.println("UnBerthTime= " + UnBerthTimeValue);
            cl.ActualTestDataValue ="UnBerth Time= ";
	        cl.result("Verifyed UnBerth Time= "+  BerthTimeValue, "UnBerth Time" , "Pass", "", 1, "VERIFY");
        }
		driver.findElement(By.xpath("(//button[@id='btnCascadeAll'])[1]")).click();
		Thread.sleep(3000);
		
		WebElement FirstPortClick = driver.findElement(By.xpath("(//div[@class='dbClickCover'])[1]"));
		FirstPortClick.click();
		
		//AdjustTime
		WebElement AdjustTime = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[2]"));
		AdjustTime.click();
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		actions.moveToElement(AdjustTime).doubleClick().perform();
		js.executeScript("arguments[0].value = '';", AdjustTime);
		AdjustTime.sendKeys("2"); 
		
		Thread.sleep(6000);
		//Choose 1
		driver.findElement(By.xpath("(//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'])[1]")).click();
		Thread.sleep(3000);
		
		//Choose 2
		//driver.findElement(By.xpath("(//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'])[2]")).click();
		//Thread.sleep(3000);
		
		//Cascade all
		driver.findElement(By.xpath("//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy']")).click();
		Thread.sleep(3000);
		
		//Confirm Button
		driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--standard q-btn--rectangle q-btn--actionable q-focusable q-hoverable bg-blue']")).click();
		
		WebElement ArrivalTime1 = driver.findElement(By.xpath("//div[@class='timings']//div[@id='port-arrival-00']"));
		String ArrivalTimeValue1 = ArrivalTime1.getText();
		System.out.println("ArrivalTimeValue= " + ArrivalTimeValue1);
		
		WebElement DepartureTime1 = driver.findElement(By.xpath("//div[@class='timings']//div[@id='port-departure-00']"));
		String DepartureTimeValue1 = DepartureTime1.getText();
		System.out.println("DepartureTimeValue= " + DepartureTimeValue1);
		
		WebElement BerthTime1 = driver.findElement(By.xpath("//div[@class='timings']//div[@id='term-berth-000']"));
		String BerthTimeValue1 = BerthTime1.getText();
		System.out.println("BerthTimeValue= " + BerthTimeValue1);
		
		WebElement UnBerthTime1 = driver.findElement(By.xpath("//div[@class='timings']//div[@id='term-unberth-000']"));
		String UnBerthTimeValue1 = UnBerthTime1.getText();
		System.out.println("UnBerthTimeValue= " + UnBerthTimeValue1);
		if (!(ArrivalTimeValue).equals(ArrivalTimeValue1)){
            System.out.println("Before ArrivalTime= " + ArrivalTimeValue + "After ArrivalTime= " + ArrivalTimeValue1);
            cl.ActualTestDataValue ="Before ArrivalTime and After ArrivalTime";
	        cl.result("Verifyed Before Arrival Time= "+  ArrivalTimeValue + " After ArrivalTime= " + ArrivalTimeValue1 , "Arrival Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Before ArrivalTime= " + ArrivalTimeValue + "After ArrivalTime= " + ArrivalTimeValue1);
            cl.ActualTestDataValue ="Before ArrivalTime and After ArrivalTime";
	        cl.result("Verifyed Before Arrival Time= "+  ArrivalTimeValue + " After ArrivalTime= " + ArrivalTimeValue1 , "Arrival Time" , "Fail", "", 1, "VERIFY");
        }
		if (!(DepartureTime).equals(DepartureTime1)){
            System.out.println("Before Departure Time= " + DepartureTime + "After Departure Time= " + DepartureTime1);
            cl.ActualTestDataValue ="Before Departure Time and After Departure Time";
	        cl.result("Verifyed Before Departure Time= "+  DepartureTime + " After Departure Time= " + DepartureTime1 , "Departure Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Not Before Departure Time= " + DepartureTime + "After Departure Time= " + DepartureTime1);
            cl.ActualTestDataValue ="Before Departure Time and After Departure Time";
	        cl.result("Not Verifyed Before Departure Time= "+  DepartureTime + " After Departure Time= " + DepartureTime1 , "Departure Time" , "Fail", "", 1, "VERIFY");
        }
		if (!(BerthTime).equals(BerthTime1)){
            System.out.println("Before Berth Time= " + BerthTime + "After Arrival Time= " + BerthTime1);
            cl.ActualTestDataValue ="Before BerthTime and After Berth Time";
	        cl.result("Verifyed Before BerthTime= "+  BerthTime + " After BerthTime= " + BerthTime1 , "Berth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Not Before Berth Time= " + BerthTime + "After Arrival Time= " + BerthTime1);
            cl.ActualTestDataValue ="Before BerthTime and After Berth Time";
	        cl.result("Not Verifyed Before BerthTime= "+  BerthTime + " After BerthTime= " + BerthTime1 , "Berth Time" , "Fail", "", 1, "VERIFY");
        }
		if (!(UnBerthTime).equals(UnBerthTime1)){
            System.out.println("Before UnBerth Time= " + UnBerthTime + "After UnBerth Time= " + UnBerthTime1);
            cl.ActualTestDataValue ="Before UnBerth Time and After UnBerth Time";
	        cl.result("Verifyed Before UnBerth Time= "+  UnBerthTime + " After ArrivalTime= " + UnBerthTime1 , "UnBerth Time" , "Pass", "", 1, "VERIFY");
        }else {
        	System.out.println("Before UnBerth Time= " + UnBerthTime + "After UnBerth Time= " + UnBerthTime1);
            cl.ActualTestDataValue ="Before UnBerth Time and After UnBerth Time";
	        cl.result("Not Verifyed Before UnBerth Time= "+  UnBerthTime + " After ArrivalTime= " + UnBerthTime1 , "UnBerth Time" , "Fail", "", 1, "VERIFY");
        }
		
	}	
	
	
}
