package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SM_TESTBED_ARRIVALTIME_20688 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
			
		WebElement ScheduleInformation = driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']"));
		ScheduleInformation.click();
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		WebElement AddPortButton = driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']"));
		AddPortButton.click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		AddPort1.click();		
		Thread.sleep(6000);
		
		Thread.sleep(4000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement ScrollDown = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", ScrollDown);

		WebElement AddPortButton2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPortButton2.click();
		Thread.sleep(4000);
		
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
		AddPortButton3.click();
		Thread.sleep(3000);
		
		WebElement ScrollDown2 = driver.findElement(By.xpath("(//td[@class='highlight data-table__sticky-column_3']//following::div//input[@class='q-field__input q-placeholder col'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", ScrollDown2);
		Thread.sleep(3000);
				
		WebElement AddPort3 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort3.click();		
		Thread.sleep(3000);
		AddPort3.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		//Verified PortName and TerminalName
		List<WebElement> PortNameVerify = driver.findElements(By.xpath("(//tr[@class='data-table__port-row']//td[@class='data-table__sticky-column_3']//input[@class='q-field__input q-placeholder col'])[2]"));
		String PrtNameVerify = "";
		for(WebElement value : PortNameVerify) {
			if(value.getAttribute("value") != null) {				
				//System.out.println("PortName= "+ value.getAttribute("value"));
				PrtNameVerify = value.getAttribute("value");
				break;
			}
		}
		
		List<WebElement> TerminalNameVerify = driver.findElements(By.xpath("(//td[@class='data-table__sticky-column_3']//div[@class='data-table__sub-td']//input[@class='q-field__input q-placeholder col'])[2]"));
		String TrNameVerify = "";
		for(WebElement value : TerminalNameVerify) {
			if(value.getAttribute("value") != null) {				
				System.out.println("TerminalName= "+ value.getAttribute("value"));
				TrNameVerify = value.getAttribute("value");
				break;
			}	
		}
		if ((PrtNameVerify != null) && (TrNameVerify != null)) {
			System.out.println("TerminalName= "+ PrtNameVerify);
			//cl.result("Verified_PortName= " +PrtNameVerify + " TerminalName= "+TrNameVerify, "", "Pass", "20688", 1, "Verify");
		}
		else {
			System.out.println("TerminalName= "+ PrtNameVerify);
			//cl.result("Not_Verified_PortName= " +PrtNameVerify + " TerminalName= "+TrNameVerify, "", "Fail", "20688", 1, "Verify");
		}
		
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
		// SeaTime 
		WebElement SeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[15]")); 
		String SeatimeValue = SeaTime.getText();
		
		WebElement ChangeDepartureTime = driver.findElement(By.xpath("(//tr[@class='data-table__port-row'][2]//td[22]//div[@class='clickable'])[1]"));
		ChangeDepartureTime.click();
		WebElement ChangeTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[22]//div[@class='proforma-timings-calendar']//select[@id='gantt-hours']"));//option[@value='20']"));
		ChangeTime.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//th[normalize-space()='Departure Time']")).click();
		Thread.sleep(5000);
		
		WebElement AfterSeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[15]")); 
		String AfterSeatimeValue = AfterSeaTime.getText();
		Thread.sleep(5000);
		if (SeatimeValue.equals(AfterSeatimeValue)){
			System.out.println("Verified_SeaTimeBefore= " +SeatimeValue +"  AndAfterSeaTime= " + AfterSeatimeValue);
			cl.result("Verified_SeaTimeBefore= " +SeatimeValue +"  AndAfterSeaTime= " + AfterSeatimeValue, "", "Pass", "20688", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_SeaTimeBefore= " +SeatimeValue +"  AndAfterSeaTime= " + AfterSeatimeValue);
			cl.result("Verified_SeaTimeBefore= " +SeatimeValue +"  AndAfterSeaTime= " + AfterSeatimeValue, "", "Fail", "20688", 1, "Verify");
		}
				
		WebElement ArrivalTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][3]//td[19]//div[@class='clickable']//p"));
		String time1 = ArrivalTime.getText();
		Thread.sleep(5000);
		WebElement ADepartureTime = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[22]//div[@class='clickable']//p"));
		String time2 = ADepartureTime.getText();
		Thread.sleep(5000);
        SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
        long hours = 0;
        try {
            // Parse the times into Date objects
            Date date1 = dateFormat.parse(time1);
            Date date2 = dateFormat.parse(time2);

            // Calculate the time difference in milliseconds
            long timeDifference = date1.getTime() - date2.getTime();

            // Convert the time difference to hours and minutes
            hours = (timeDifference / (60 * 60 * 1000 )) + 2;
            long minutes = (timeDifference % (60 * 60 * 1000)) / (60 * 1000);
            
            System.out.println("Time Difference: " + hours + " hours and " + minutes + " minutes");
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        WebElement beforeSeaTimeCal = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][3]//td[15]"));
		String beforeSeaTimeCalVal = beforeSeaTimeCal.getText();
		long beforeSeaTimeCalValcon = Long.parseLong(beforeSeaTimeCalVal);
		if (beforeSeaTimeCalValcon == hours){
        	System.out.println("Verified_SeaTime_AfterChangeDeparturTime= " +beforeSeaTimeCalVal);
        }
        else {
        	System.out.println("Not_Verified_SeaTime_AfterChangeDeparturTime= " +beforeSeaTimeCalVal);
        }
		
		//Calculation Speed = Distance/SeaTime
		List<WebElement> DistanceGet = driver.findElements(By.xpath("//th[normalize-space()='Distance (NM)']//following::tr[6]//td[12]//input[@class='q-field__input q-placeholder col']"));
		String DistanceAfterValue = "";
		for(WebElement value : DistanceGet) {
			if(value.getAttribute("value") != null) {				
				DistanceAfterValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> SpeedneedCheck = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[6]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedAfterValue = "";
		for(WebElement value : SpeedneedCheck) {
			if(value.getAttribute("value") != null) {				
				SpeedAfterValue = value.getAttribute("value");
				break;
			}
		}
		WebElement SeaTimeVeri = driver.findElement(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[6]//td[15]"));
		String seaTimeString = SeaTimeVeri.getText();
		double seaTimeDouble = Double.parseDouble(seaTimeString);
		double roundedNumber = Math.round(seaTimeDouble);
		
		double DistanceCal1 = Double.valueOf(DistanceAfterValue);
		double AfterSeatimeValueCa11 = Double.valueOf(SpeedAfterValue);
		double SpeedCalculation = (DistanceCal1) / (AfterSeatimeValueCa11);
		double final_cal = Math.round(SpeedCalculation);
		
		//Verify Speed Calculation
		if (roundedNumber == final_cal) {
			cl.result("Not_Verifyed_Speed= "+ AfterSeatimeValueCa11, "", "Pass", "20688", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Speed= " + AfterSeatimeValueCa11);
			cl.result("Not_Verifyed_Speed= "+ AfterSeatimeValueCa11, "", "Fail", "20688", 1, "Verify");
		}
	
	}
}
