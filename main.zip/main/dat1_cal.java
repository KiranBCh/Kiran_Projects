package com.onetx.selenium.main;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class dat1_cal {
	/*
	public static void main(String[] args) {
        // Define the initial date and time (Mon 12:00 PM)
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("E hh:mm a");
        LocalDateTime initialDateTime = LocalDateTime.parse("Mon 12:00 PM", inputFormatter);

        // Add 72 hours to the initial date and time
        LocalDateTime resultDateTime = initialDateTime.plus(72, ChronoUnit.HOURS);

        // Format and print the result
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("E hh:mm a");
        String result = resultDateTime.format(outputFormatter);
        System.out.println("72 hours after 'Mon 12:00 PM' is: " + result);
    }
	*/
	public static void main(String[] args) throws ParseException {
		// Recalculate Sea Time of next port = Arrival Time of next port - Departure Time of edited port + difference in GMT
	        //String time2 = "Week 1, Tue 00:00";
	        //String time1 = "Week 1, Fri 00:00";
	        String time2 = "";
	        String time1 = "";
	        /*
	         * AfterDepartureTime= Week 2, Mon 12:00
AfterDepartureTime= Week 1, Fri 02:00
Time Difference: 81 hours and 0 minutes

	        SimpleDateFormat sdf = new SimpleDateFormat("MM dd yyyy HH:mm:ss");
	        Calendar cal = Calendar.getInstance();
	        cal.setTimeZone(TimeZone.getTimeZone("UTC"));
	        cal.set(Calendar.WEEK_OF_YEAR, 1);        
	        cal.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY);
	        cal.set(Calendar.HOUR_OF_DAY, 02);
	        cal.set(Calendar.MINUTE, 0);
	        
	        System.out.println(sdf.format(cal.getTime()));
	        String frDate = sdf.format(cal.getTime());
	        Date dateFr = sdf.parse(frDate);
	        
	        cal.set(Calendar.WEEK_OF_YEAR, 2);        
	        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
	        cal.set(Calendar.HOUR_OF_DAY, 12);
	        cal.set(Calendar.MINUTE, 0);
	        System.out.println(sdf.format(cal.getTime()));
	        String toDate = sdf.format(cal.getTime());
	        Date dateTo = sdf.parse(toDate);
	        
	        System.out.println(dateFr);
	        System.out.println(dateTo);
	        */
	        // Define date format
	        //SimpleDateFormat dateFormat = new SimpleDateFormat("EEE HH:mm");
	        SimpleDateFormat dateFormat = new SimpleDateFormat("'Week' w, EEE HH:mm");
	        //Ajman (AEAJM)
	        try {
	            // Parse the times into Date objects
	            Date ArrivalTime = dateFormat.parse("Week 1, Fri 02:00");
	            Date DepartureTime = dateFormat.parse("Week 2, Mon 12:00");
	            System.out.println("ArrivalTime= " + ArrivalTime);
	            System.out.println("DepartureTime= " + DepartureTime);
	            // Calculate the time difference in milliseconds
	            //long timeDifference = dateTo.getTime() - dateFr.getTime();
	            long timeDifference = ArrivalTime.getTime() - DepartureTime.getTime();

	            // Convert the time difference to hours and minutes
	            long hours = timeDifference / (60 * 60 * 1000) + 2;
	            long minutes = (timeDifference % (60 * 60 * 1000)) / (60 * 1000); 

	            System.out.println("Time Difference: " + hours + " hours and " + minutes + " minutes");
	            //Calendar calendar = Calendar.getInstance();     calendar.setTime(new Date());     calendar.add(Calendar.HOUR_OF_DAY, (int) hours);
	            //System.out.println("Currentdate" + calendar.getTime();
	        } catch (ParseException e) {
	            e.printStackTrace();
	        }
}
}