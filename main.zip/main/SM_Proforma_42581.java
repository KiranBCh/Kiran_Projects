package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Proforma_42581 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", "C:\\Reference\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		Thread.sleep(3000);
		WebElement VesselNameClick = driver.findElement(By.xpath("(//div[@class='vessel']//div[@class='q-field__inner relative-position col self-stretch']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		VesselNameClick.sendKeys("CAPE FLORES");
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
				
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		Actions actions = new Actions(driver);
		
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
			
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,110)","");
		
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(2000);
		
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		
		AddPortName2.sendKeys("INNSA");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement AddTwoTerminalName = driver.findElement(By.xpath("(//div[@id='terminalDblClick'])[2]"));
		Thread.sleep(3000);
		AddTwoTerminalName.click();
		Thread.sleep(3000);
		WebElement AddTerminal = driver.findElement(By.xpath("(//div[@class='terminalNameContainer']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(3000);
		actions.moveToElement(AddTerminal).doubleClick().perform();
		AddTerminal.sendKeys("JNP");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,105)","");
		
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(2000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		Thread.sleep(2000);
		
		WebElement AddPortName3 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[3]"));
		actions.moveToElement(AddPortName3).doubleClick().perform();
		Thread.sleep(2000);
		
		AddPortName3.sendKeys("BDMGL");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		
		List<WebElement> OldTerminalName = driver.findElements(By.xpath("(//div[@class='terminalNameContainer']//input[@class='q-field__input q-placeholder col'])[2]"));
		String OldTerminalNameStr = "";
		for(WebElement value : OldTerminalName) {
			if(value.getAttribute("value") != null) {				
				OldTerminalNameStr = value.getAttribute("value");
				break;
			}
		}
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default adHoc resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
		WebElement ClearPort = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		ClearPort.click();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		actions.moveToElement(ClearPort).doubleClick().perform();
		js.executeScript("arguments[0].value = '';", ClearPort);
		Thread.sleep(4000);
		ClearPort.sendKeys("INNSA");
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		
		WebElement changeTerminal = driver.findElement(By.xpath("(//div[@class='terminalNameContainer']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		//changeTerminal.clear();
		//actions.moveToElement(changeTerminal).doubleClick().perform();
		js.executeScript("arguments[0].value = '';", changeTerminal);
		Thread.sleep(2000);
		changeTerminal.sendKeys("BMT");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		
		List<WebElement> NewTerminalName = driver.findElements(By.xpath("(//div[@class='terminalNameContainer']//input[@class='q-field__input q-placeholder col'])[2]"));
		String NewTerminalNameStr = "";
		for(WebElement value : NewTerminalName) {
			if(value.getAttribute("value") != null) {				
				NewTerminalNameStr = value.getAttribute("value");
				break;
			}
		}
		
		if (OldTerminalNameStr != NewTerminalNameStr) {
			System.out.println("Verifyed, BeforeTerminalName= "+ OldTerminalNameStr + "  AfterTerminalName= " + NewTerminalNameStr);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Verifyed, BeforeTerminalName= "+ OldTerminalNameStr + "  AfterTerminalName= " + NewTerminalNameStr, "", "Pass", "42582", 1, "Verify");
		}
		else {
			System.out.println("Not_Verifyed, BeforeTerminalName= "+ OldTerminalNameStr + "  AfterTerminalName= " + NewTerminalNameStr);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Not_Verifyed, BeforeTerminalName= "+ OldTerminalNameStr + "  AfterTerminalName= " + NewTerminalNameStr, "", "Fail", "42582", 1, "Verify");
		}
		
		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(3000);
		
		List<WebElement> SecondTerminalName = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-3]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		String SecondTerminalNameValue = "";
		for(WebElement value : SecondTerminalName) {
			if(value.getAttribute("value") != null) {				
				SecondTerminalNameValue = value.getAttribute("value");
				break;
			}
		}
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement SecondTerminalNameChange = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-3]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		SecondTerminalNameChange.click();
		SecondTerminalNameChange.sendKeys("NSF");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		List<WebElement> AfterSecondTerminalName = driver.findElements(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-3]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		String AfterSecondTerminalNameValue = "";
		for(WebElement value : AfterSecondTerminalName) {
			if(value.getAttribute("value") != null) {				
				AfterSecondTerminalNameValue = value.getAttribute("value");
				break;
			}
		}
		if (SecondTerminalNameValue != AfterSecondTerminalNameValue) {
			System.out.println("Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue, "", "Pass", "42582", 1, "Verify");
		}
		else {
			System.out.println("Not_Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue);
			cl.ActualTestDataValue ="Change Terminal Names";
        	cl.result("Not_Verifyed, BeforeTerminalName= "+ SecondTerminalNameValue + "  AfterTerminalName= " + AfterSecondTerminalNameValue, "", "Fail", "42582", 1, "Verify");
		}
		
	}
}
