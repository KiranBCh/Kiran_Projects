package com.onetx.selenium.main;

import java.io.File;

public class file_current_path {
	public static void main(String[] args) {
        String currentDirectory = System.getProperty("user.dir");
        String parentDirectory = new File(currentDirectory).getParent();
        String parentDirectory1 = new File(parentDirectory).getParent();
        String parentDirectory2 = parentDirectory1 +"/downloads/";
        String currentDirectory_name = System.getProperty("user.name");
        System.out.println(currentDirectory_name);
        System.out.println(currentDirectory);
        
        System.out.println(parentDirectory2);
        //C:\Users\KiranbabuChiluvuru\Downloads
        //currentDirectoryC:\Automation\classes
        
        String s = "C:/Users/KiranbabuChiluvuru/Downloads/";
 
        File f = new File(parentDirectory2.replace("\\","/") + "CIT_data.csv");
		
		if (f.exists()) {
			System.out.println("File donwloaded");
		}
    }

}
