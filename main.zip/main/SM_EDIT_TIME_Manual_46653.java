package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SM_EDIT_TIME_Manual_46653 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		WebElement VesselNameClick = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		Thread.sleep(2000);
		
		//ArrivalTime
		WebElement ArrivalTimeBefore = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-arrival-001']"));
		String GetArrivalTime = ArrivalTimeBefore.getText();
		
		WebElement ArrivalTimeChange = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-arrival-001']"));
		actions.moveToElement(ArrivalTimeChange).doubleClick().perform();
		WebElement ArrivalTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeArrivalTimeHours = new Select(ArrivalTimeHours);
	    ChangeArrivalTimeHours.selectByValue("2");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
	    Thread.sleep(2000);
	    WebElement ArrivalTimeAfter = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-arrival-001']"));
		String GetArrivalTimeAfter = ArrivalTimeAfter.getText();
		Thread.sleep(2000);
		if (!(GetArrivalTime).equals(GetArrivalTimeAfter)){
			System.out.println("Verifyed ArrivalTime Before "+ GetArrivalTime + " Hours "+ "  AfterChange "+ GetArrivalTimeAfter + " Hours");
			//cl.result("Verifyed ArrivalTime Before "+ GetArrivalTime + " Hours "+ "  AfterChange "+ GetArrivalTimeAfter + " Hours", "", "Pass", "46653", 1, "Verify");
		}
        else {
        	System.out.println("Verifyed ArrivalTime Before "+ GetArrivalTime + " Hours "+ "  AfterChange "+ GetArrivalTimeAfter + " Hours");
			//cl.result("Not_Verifyed ArrivalTime Before "+ GetArrivalTime + " Hours "+ "  AfterChange "+ GetArrivalTimeAfter + " Hours","", "Fail", "46653", 1, "Verify");
		}   
		
        driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
        Thread.sleep(2000);
        
        //DepartureTime
        WebElement DepartureTimeBefore = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
		String GetDepartureTime = DepartureTimeBefore.getText();
		
        WebElement DepartureTime = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
        actions.moveToElement(DepartureTime).doubleClick().perform();
        WebElement DepartureTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeDepartureTimeHours = new Select(DepartureTimeHours);
	    ChangeDepartureTimeHours.selectByValue("14");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
	    Thread.sleep(2000);
	    WebElement DepartureTimeAfter = driver.findElement(By.xpath("((//div[@class='service-lane'])[2]//div[@class='timing'])[1]//div[@id='port-departure-001']"));
		String GetDepartureTimeAfter = DepartureTimeAfter.getText();
		if (!(GetDepartureTime).equals(GetDepartureTimeAfter)){
			System.out.println("Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours");
			//cl.result("Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours", "", "Pass", "46653", 1, "Verify");
		}
        else {
        	System.out.println("Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours");
			//cl.result("Not_Verifyed DepartureTime Before "+ GetDepartureTime + " Hours "+ "  AfterChange "+ GetDepartureTimeAfter + " Hours", "", "Fail", "46653", 1, "Verify");
		}  
		
		driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
		Thread.sleep(2000);
		
		//TerminalBirthTime
		WebElement TerminalBirthTimeBefore = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-berth-0001']"));
		String GetTerminalBirthTime = TerminalBirthTimeBefore.getText();
		WebElement TerminalTime = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-berth-0001']"));
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String doubleClickScript = "var element = arguments[0];" +
                "var mouseEvent = document.createEvent('MouseEvents');" +
                "mouseEvent.initEvent('dblclick', true, true);" +
                "element.dispatchEvent(mouseEvent);";
        jsExecutor.executeScript(doubleClickScript, TerminalTime);
        
        WebElement TerminalBirthTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeTerminalBirthTimeHours = new Select(TerminalBirthTimeHours);
	    ChangeTerminalBirthTimeHours.selectByValue("3");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
	    
	    WebElement TerminalBirthTimeAfter = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-berth-0001']"));
		String GetTerminalBirthTimeAfter = TerminalBirthTimeAfter.getText();
		if (!(GetTerminalBirthTime).equals(GetTerminalBirthTimeAfter)){
			//System.out.println("Verifyed BirthTime Before "+ GetTerminalBirthTime + "Hours"+ "  AfterChange "+ GetTerminalBirthTimeAfter + " Hours");
			cl.result("Verifyed BirthTime Before "+ GetTerminalBirthTime + " Hours "+ "  AfterChange "+ GetTerminalBirthTimeAfter + " Hours", "", "Pass", "46653", 1, "Verify");
		}
        else {
        	//System.out.println("Verifyed BirthTime Before "+ GetTerminalBirthTime + "Hours"+ "  AfterChange "+ GetTerminalBirthTimeAfter + " Hours");
			cl.result("Not_Verifyed BirthTime Before "+ GetTerminalBirthTime + " Hours "+ "  AfterChange "+ GetTerminalBirthTimeAfter + " Hours", "", "Fail", "46653", 1, "Verify");
		}  
        
        driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
        Thread.sleep(2000);
        
		//TerminalUnberthTime
        WebElement TerminalUnberthTimeBefore = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-unberth-0001']"));
		String GetTerminalUnberthTime = TerminalUnberthTimeBefore.getText();
		
        WebElement TerminalTimeUnberth = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-unberth-0001']"));
        String doubleClickScript1 = "var element = arguments[0];" +
                "var mouseEvent = document.createEvent('MouseEvents');" +
                "mouseEvent.initEvent('dblclick', true, true);" +
                "element.dispatchEvent(mouseEvent);";
        jsExecutor.executeScript(doubleClickScript1, TerminalTimeUnberth);
        
        WebElement TerminalUnberthTimeHours = driver.findElement(By.xpath("//select[@id='gantt-hours']"));
	    Select ChangeTerminalUnberthTimeHours = new Select(TerminalUnberthTimeHours);
	    ChangeTerminalUnberthTimeHours.selectByValue("13");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[text()='Long Term Schedule']")).click();
	    WebElement TerminalUnberthTimeAfter = driver.findElement(By.xpath("(//div[@class='service-lane'])[2]//div[@class='timings']//..//div[@class='terminal']//div[@id='term-unberth-0001']"));
		String GetTerminalUnberthTimeAfter = TerminalUnberthTimeAfter.getText();
		if (!(GetTerminalUnberthTime).equals(GetTerminalUnberthTimeAfter)){
			System.out.println("Verifyed UnberthTime Before "+ GetTerminalUnberthTime + "Hours"+ "  AfterChange "+ GetTerminalUnberthTimeAfter + " Hours");
			//cl.result("Verifyed UnberthTime Before "+ GetTerminalUnberthTime + " Hours "+ "  AfterChange "+ GetTerminalUnberthTimeAfter + " Hours", "", "Pass", "46653", 1, "Verify");
		}
        else {
        	System.out.println("Not_Verifyed UnberthTime Before "+ GetTerminalUnberthTime + "Hours"+ "  AfterChange "+ GetTerminalUnberthTimeAfter + " Hours");
			cl.result("Not_Verifyed UnberthTime Before "+ GetTerminalUnberthTime + " Hours "+ "  AfterChange "+ GetTerminalUnberthTimeAfter + " Hours", "", "Fail", "46653", 1, "Verify");
		}
	}
}
