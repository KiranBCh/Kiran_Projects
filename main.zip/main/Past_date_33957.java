package com.onetx.selenium.main;

import java.time.DayOfWeek;
import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Past_date_33957 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		Thread.sleep(7000);
		vessle_click.click();
		
        WebElement date_picker = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
		date_picker.click();
		Thread.sleep(7000);
		
		WebElement dateElement = driver.findElement(By.xpath("//i[contains(text(), 'chevron_left')][1]"));
		Thread.sleep(7000);
        dateElement.click();
        
        LocalDate today = LocalDate.now();
        LocalDate lastMonth = today.minusMonths(1);

        // Find the last Monday of the previous month
        LocalDate lastMonthMonday = lastMonth.with(DayOfWeek.MONDAY);
        
        // If lastMonthMonday is after lastMonth, subtract 7 days to get the last Monday
        if (lastMonthMonday.isAfter(lastMonth)) {
            lastMonthMonday = lastMonthMonday.minusWeeks(1);
        }
        //lastMonthMonday.getDayOfMonth();
        String current_monday = String.valueOf(lastMonthMonday.getDayOfMonth());
                
        WebElement dateElement1 = driver.findElement(By.xpath("//span[@class='block'][normalize-space()='" + current_monday +"']"));
		Thread.sleep(3000);
        dateElement1.click();
        WebElement verified_date = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
        boolean isEnabled = verified_date.isEnabled();
        if (isEnabled){
        	System.out.println("Past dates are available for selection.");
        }
        else {
        	System.out.println("Past dates are not available for selection.");
        }
        driver.close();
	}

}
