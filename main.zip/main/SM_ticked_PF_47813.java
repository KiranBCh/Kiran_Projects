package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_ticked_PF_47813 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(4000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");
		Thread.sleep(4000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(4000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);

		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		
        driver.findElement(By.xpath("//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(7000);
		
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(7000);
		
		WebElement AddPort1 = driver.findElement(By.xpath("//tr[@class='data-table__port-row']//td//input[@class='q-field__input q-placeholder col']"));
		AddPort1.click();		
		Thread.sleep(3000);
		
		Thread.sleep(3000);
		AddPort1.sendKeys("AEAJM");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(4000);
		 
		for (int i = 0; i < 4; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		WebElement AddPort2 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort2.click();		
		Thread.sleep(3000);
		
		AddPort2.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']")).click();
		Thread.sleep(3000);
			
		WebElement AddPort3 = driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='highlight data-table__sticky-column_3']//following::input[@class='q-field__input q-placeholder col'])[1]"));
		AddPort3.click();		
		Thread.sleep(3000);
		AddPort3.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		//UtilizationCheckBox
		driver.findElement(By.xpath("(//tr[@class='data-table__port-row']//td[@class='row-grouping']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy'])[1]")).click();
		//External
		driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[1]")).click();
		//Internall
		driver.findElement(By.xpath("(//tr[@class='data-table__row data-table__row--centered']//div[@class='q-checkbox cursor-pointer no-outline row inline no-wrap items-center q-checkbox--dense justify-center'])[2]")).click();
		
		//ServiceRotation
		WebElement ServiceRotation = driver.findElement(By.xpath("(//td[@class='highlight row-grouping']//input[@class='q-field__input q-placeholder col'])[1]"));
		ServiceRotation.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		//Leg
		WebElement Leg = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[1]"));
		Leg.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement LegMiddle = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[2]"));
		LegMiddle.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement LegLast = driver.findElement(By.xpath("((//tr[@class='data-table__row data-table__row--centered']//td[10]//div[@class='q-field__native row items-center']))[3]"));
		LegLast.click();
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement InputVesselName = driver.findElement(By.xpath("(//div[@class='inputs']//div[@class='q-field__inner relative-position col self-stretch']//input[@class='q-field__native q-placeholder'])"));		
		Thread.sleep(2000);
		String FileName = "Kiran002";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		actions.moveToElement(InputVesselName).doubleClick().perform();
		js.executeScript("arguments[0].value = '';", InputVesselName);
		InputVesselName.sendKeys(FileName);

		String titleName = driver.findElement(By.xpath("//div[@class='page-title' and text()]")).getText();
		
		driver.findElement(By.xpath("//div[@class='arrow_back']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--round q-btn--actionable q-focusable q-hoverable q-btn--dense']")).click();
		driver.findElement(By.xpath("//div[@class='arrow_back']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--round q-btn--actionable q-focusable q-hoverable q-btn--dense']")).click();
		driver.findElement(By.xpath("(//div[@class='q-dialog fullscreen no-pointer-events q-dialog--modal']//div[@class='q-card']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle q-btn--actionable q-focusable q-hoverable buttons-cancel'])[2]")).click();
		
		
		
}
}
