package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CM_Click {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		//CM_SEARCH_VESSEL_IN_VESSEL_PAGE
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		VesselClick_Search.sendKeys("A KIBO");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(7000);
		
		//WebElement VesselClickName = driver.findElement(By.xpath("(//div[@class='q-scrollarea__content absolute']//div[@class='vessel_item_name'])[1]"));
		WebElement VesselClickName1 = driver.findElement(By.xpath("//span[contains(text(),'A KIBO →')]"));
		VesselClickName1.click();
		Thread.sleep(9000);
		
		WebElement VesselSummaryPage = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[1]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPage.click();
		Thread.sleep(8000);
		
		WebElement VesselCodeHeading = driver.findElement(By.xpath("//div[@class='port-contractual-details-repeated']//div//div[contains(@class, 'vessel-code-heading')]"));
		String VesselCodeHeadingText = VesselCodeHeading.getText();
		System.out.println(VesselCodeHeadingText);
		Thread.sleep(8000);
		
		WebElement PortCodeHeading = driver.findElement(By.xpath("//div[@class='port-contractual-details-repeated']//div//div[contains(@class, 'port-code-heading')]"));
		String PortCodeHeadingText = PortCodeHeading.getText();
		System.out.println(PortCodeHeadingText);
		Thread.sleep(8000);
		
		WebElement PortNameClick = driver.findElement(By.xpath("//div[@class='cm_page_port_summaries']//div[text()='CNSHA']"));
		PortNameClick.click();
		Thread.sleep(8000);
		
		WebElement PortDetailHeading = driver.findElement(By.xpath("(//div[@class='port-details-bar']//div[@class='port-detail-heading vert-line'])[1]"));
		System.out.println(PortDetailHeading.getText());
		WebElement Service = driver.findElement(By.xpath("(//div[@class='port-detail-item']//div[text()='Service'])[1]"));
		System.out.println(Service.getText());
		WebElement Voyage = driver.findElement(By.xpath("(//div[@class='port-detail-item']//div[text()='Voyage'])[1]"));
		System.out.println(Voyage.getText());
		WebElement Leg = driver.findElement(By.xpath("(//div[@class='port-detail-item']//p[text()='Leg'])[1]"));
		System.out.println(Leg.getText());
		WebElement ETA = driver.findElement(By.xpath("(//div[@class='port-detail-item']//p[text()='ETA'])[1]"));
		System.out.println(ETA.getText());
		WebElement ETD = driver.findElement(By.xpath("(//div[@class='port-detail-item']//p[text()='ETD'])[1]"));
		System.out.println(ETD.getText());
	    driver.close();
		
	}

}
