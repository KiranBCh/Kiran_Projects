package com.onetx.selenium.main;
import java.time.DayOfWeek;
import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Test {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		
		Thread.sleep(7000);
		
		vessle_click.click();
		Thread.sleep(7000);
		System.out.println("***********Strated***********(33954)******");
		/*
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		Thread.sleep(4000);
		ac.click(searchBox1).perform();
		Thread.sleep(4000);
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("Schedule123");
		Thread.sleep(7000);
		WebElement selectname = driver.findElement(By.xpath("//div[text()='Schedule123']"));
		selectname.click();
		Thread.sleep(7000);
		WebElement date_picker = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
		date_picker.click();
		Thread.sleep(7000);
		WebElement select_date_picker = driver.findElement(By.xpath("//p[@class='proforma-text']"));
		String select_date_picker_ele = select_date_picker.getText();
		
		System.out.println("Element text: " + select_date_picker_ele);
		driver.close();
		
		
		System.out.println("***********Closed***********************");
		
		WebElement date_picker = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
		date_picker.click();
		Thread.sleep(3000);
		
		WebElement dateElement = driver.findElement(By.xpath("//span[@class='block'][normalize-space()='2']"));
		Thread.sleep(3000);
        dateElement.click();
        
        boolean isEnabled = dateElement.isEnabled();
        if (isEnabled) {
        	System.out.println("Date is allowed selection");
        }
        Thread.sleep(7000);
        driver.close();
        */
        System.out.println("********Close**********************");
        WebElement date_picker = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
		date_picker.click();
		Thread.sleep(3000);
		
		WebElement dateElement = driver.findElement(By.xpath("//i[contains(text(), 'chevron_left')][1]"));
		Thread.sleep(3000);
        dateElement.click();
        
        LocalDate today = LocalDate.now();
        LocalDate lastMonth = today.minusMonths(1);

        // Find the last Monday of the previous month
        LocalDate lastMonthMonday = lastMonth.with(DayOfWeek.MONDAY);
        
        // If lastMonthMonday is after lastMonth, subtract 7 days to get the last Monday
        if (lastMonthMonday.isAfter(lastMonth)) {
            lastMonthMonday = lastMonthMonday.minusWeeks(1);
        }
        //lastMonthMonday.getDayOfMonth();
        String current_monday = String.valueOf(lastMonthMonday.getDayOfMonth());
        //String verified_date_ele = current_monday.getText();
		//System.out.println("Element text: " + current_monday);
        
        WebElement dateElement1 = driver.findElement(By.xpath("//span[@class='block'][normalize-space()='" + current_monday +"']"));
		Thread.sleep(3000);
        dateElement1.click();
        
        //WebElement select_LastMonth = driver.findElement(By.xpath("//div[@class='q-date__calendar-weekdays row items-center no-wrap']//following::span[@class='block'][1]"));
        //Thread.sleep(5000);
        //select_LastMonth.;
        
        //String select_date_picker_ele = select_LastMonth.getText();
		//System.out.println("Element text: " + select_date_picker_ele);
        
        WebElement verified_date = driver.findElement(By.xpath("(//input[@class=\"q-field__native q-placeholder\"])[2]"));
        //String verified_date_ele = verified_date.getText();
		//System.out.println("Element text: " + verified_date_ele);
		
        boolean isEnabled = verified_date.isEnabled();
        if (isEnabled){
        	System.out.println("Past dates are available for selection.");
        }
        else {
        	System.out.println("Past dates are not available for selection.");
        }
        /*
        if (isEnabled) {
        	System.out.println("Date is allowed selection past");
        }
        else {
        	System.out.println("Date is not allowed to select");
        }
        Thread.sleep(7000);
        */
        
        
        
	}

}
