package com.onetx.selenium.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Filter_Proforma_34330 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		Thread.sleep(7000);
		
		vessle_click.click();
		Thread.sleep(7000);
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		Thread.sleep(4000);
		ac.click(searchBox1).perform();
		Thread.sleep(4000);
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(7000);
		WebElement selectname = driver.findElement(By.xpath("//div[text()='VerifyProfomaSearch1']"));
		String searched_by_typing = selectname.getText();
		//System.out.println("Element text: " + searched_by_typing);
		Thread.sleep(7000);
		//boolean isEnabled1 = selectname.isEnabled();
		if (searched_by_typing.equals(searched_by_typing)){
        	System.out.println("Verifyed Profoma Search.");
        	//cl.result("proforma_template_can_be_searched_by_typing_and_results_are_filtered", "", "Pass", "34330", 1, "proforma_template_can_be_searched_by_typing_and_results_are_filtered");
        }
        else {
        	System.out.println("Verifyed Profoma not Searchable");
        	//cl.result("proforma_template_can_be_searched_by_typing_and_results_are_not_filtered", "", "Fail", "34330", 1, "proforma_template_can_be_searched_by_typing_and_results_are_not_filtered");
        }
	}

}
