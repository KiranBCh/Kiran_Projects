package com.onetx.selenium.main;

import java.awt.AWTException;
import java.time.Duration;
import java.time.LocalTime;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Kiran_38081 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement new_schedule_button = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		new_schedule_button.click();
		Thread.sleep(3000);

		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(4000);
		
		WebElement add_port_terminal = driver.findElement(By.xpath("//span[@class='block']"));
		add_port_terminal.click();
		Thread.sleep(3000);
		
		
		
		
		
		
        WebElement ArrivalTime  = driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']//following::td[19]"));
        String ArrivalTimeValue = ArrivalTime.getText();
        if ((ArrivalTimeValue).equals("Week 1, Mon 12:00")) {
        	System.out.println("Verified_ArrivalTime= " + ArrivalTimeValue);
			//cl.result("Verified_ArrivalTime= " + ArrivalTimeValue, "", "Pass", "38081", 1, "Verify");
        }
        else {
        	System.out.println("Not_Verified_ArrivalTime= " + ArrivalTimeValue);
			//cl.result("Not_Verified_ArrivalTime= " + ArrivalTimeValue, "", "Fail", "38081", 1, "Verify");
        }
        
        WebElement SeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[2]//td[14]"));
        String SeaTimeValue = SeaTime.getText();
        if (SeaTimeValue == null) {
        	System.out.println("Verified_SeaTimeValue= " + SeaTimeValue);
			//cl.result("Verified_SeaTime= " + SeaTimeValue, "", "Pass", "38081", 1, "Verify");
        }
        else {
        	System.out.println("Verified_SeaTimeValue= " + SeaTimeValue);
			//cl.result("Not_Verified_SeaTime= " + SeaTimeValue, "", "Fail", "38081", 1, "Verify");
        }
        
        WebElement Distance = driver.findElement(By.xpath("//th[normalize-space()='Distance (NM)']//following::tr[2]//td[12]"));
        String DistanceValue = Distance.getText();
        if (DistanceValue == "") {
        	System.out.println("Verified_DistanceValue= " + DistanceValue);
			//cl.result("Verified_Distance= " + DistanceValue, "", "Pass", "38081", 1, "Verify");
        }
        else {
        	System.out.println("Not_Verified_DistanceValue= " + DistanceValue);
			//cl.result("Not_Verified_DistanceValue= " + DistanceValue, "", "Fail", "38081", 1, "Verify");
        }
        WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
        int pilotInText = Integer.parseInt(PilotIn.getText());
        if (pilotInText == 1) {
        	System.out.println("Verified_pilotInText= " + pilotInText);
			//cl.result("Verified_PilotIn= " + pilotInText, "", "Pass", "38081", 1, "Verify");
        }
        else {
        	System.out.println("Not_Verified_pilotInText= " + pilotInText);
			//cl.result("Not_Verified_PilotIn= " + pilotInText, "", "Fail", "38081", 1, "Verify");
        }
        WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
        int PilotOutText = Integer.parseInt(PilotOut.getText());
        if (PilotOutText == 1) {
        	System.out.println("Verified_PilotOutText= " + PilotOutText);
			//cl.result("Verified_PilotOut= " + PilotOutText, "", "Pass", "38081", 1, "Verify");
        }
        else {
        	System.out.println("Not_Verified_PilotOutText= " + PilotOutText);
			//cl.result("Not_Verified_PilotOut= " + PilotOutText, "", "Fail", "38081", 1, "Verify");
        }
        WebElement PortStay = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[16]"));
        int PortStayText = Integer.parseInt(PortStay.getText());
        if (PortStayText == 12) {
        	System.out.println("Verified_PortStayText= " + PortStayText);
			//cl.result("Verified_PortStay= " + PortStayText, "", "Pass", "38081", 1, "Verify");
        }
        else {
        	System.out.println("Not_Verified_PortStay= " + PortStayText);
			//cl.result("Not_Verified_PortStay= " + PortStayText, "", "Fail", "38081", 1, "Verify");
        }
        WebElement DepartureTime = driver.findElement(By.xpath("//th[normalize-space()='Departure Time']//following::td[22]"));
		String DepartureTimeValue = DepartureTime.getText();
		System.out.println("DepartureTimeValue= " + DepartureTimeValue);
        /*
		
		
        
        
		
		WebElement PilotIn_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		WebElement BerthTime = driver.findElement(By.xpath("//th[normalize-space()='Berth Time']//following::tr[3]//td[19]//div[@class='clickable']//p"));
        WebElement UnberthTime = driver.findElement(By.xpath("//th[normalize-space()='Unberth Time']//following::tr[2]//td[20]//div[@class='clickable']//p"));
        
		
		
        int PilotOutText = Integer.parseInt(PilotOut.getText());
        int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
        int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
        int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
        int Shifting_AllTerminals = 0;
        int ARKS_Shifting_AllTerminals = 0;
        int PortBuffer = pilotInText + PilotOutText + Shifting_AllTerminals - PilotInARKSText - PilotOutARKSText - ARKS_Shifting_AllTerminals;
        
        if (bufferTimeValueText == PortBuffer) {
        	System.out.println("Verifyed_PortBufferTime_Is_Equals(bufferTimeValue)");
        }
        else {
        	System.out.println("Verifyed_PortBufferTime_Is_Not_Equals(bufferTimeValue)");
        }
        */
	}
}
