package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Man_42584 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		Thread.sleep(7000);
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement vessle_click1 = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'][1]"));
		vessle_click1.click();
		Thread.sleep(2000);
		
		WebElement vessel_click = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		vessel_click.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		Actions actions = new Actions(driver);
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		
		AddPortName.sendKeys("AEAJM");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
				
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,200)","");
		
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		Thread.sleep(3000);
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		WebElement AddPortName2 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName2).doubleClick().perform();
		
		AddPortName2.sendKeys("INNSA");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement AddTwoTerminalName = driver.findElement(By.xpath("(//div[@id='terminalDblClick'])[2]"));
		AddTwoTerminalName.click();
		WebElement AddTerminal = driver.findElement(By.xpath("(//div[@class='terminalNameContainer']//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		actions.moveToElement(AddTerminal).doubleClick().perform();
		AddTerminal.sendKeys("JNP");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,300)","");
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		Thread.sleep(3000);
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		WebElement AddPortName3 = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[3]"));
		actions.moveToElement(AddPortName3).doubleClick().perform();
		Thread.sleep(2000);
		
		AddPortName3.sendKeys("BDMGL");
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(8000);
		
		WebElement SeaTime = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[26]")); 
		String SeatimeValue = SeaTime.getText();
		System.out.println("SeaTime="+SeatimeValue);
		List<WebElement> Speed = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedValue = "";
		for(WebElement value : Speed) {
			if(value.getAttribute("value") != null) {				
				SpeedValue = value.getAttribute("value");
				System.out.println("Speed="+SpeedValue);
				break;
			}
		}
		List<WebElement> Distance = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String DistanceValue = "";
		for(WebElement value : Distance) {
			if(value.getAttribute("value") != null) {				
				DistanceValue = value.getAttribute("value");
				System.out.println("Distance="+DistanceValue);
				break;
			}
		}
		
		Thread.sleep(4000);
		WebElement AddFirstPortRemove = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		AddFirstPortRemove.clear();
		Thread.sleep(4000);
		WebElement AddFirstTerminalRemove = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		AddFirstTerminalRemove.clear();
		Thread.sleep(3000);
		WebElement AddFirstPort = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		AddFirstPort.click();
		Thread.sleep(4000);
		AddFirstPort.sendKeys("IDBLW");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement SeaTimeAfter = driver.findElement(By.xpath("//th[normalize-space()='Sea Time']//following::tr[4]//td[26]")); 
		String SeatimeAfterValue = SeaTimeAfter.getText();
		List<WebElement> SpeedAfter = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedAfterValue = "";
		for(WebElement value : SpeedAfter) {
			if(value.getAttribute("value") != null) {				
				SpeedAfterValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> DistanceAfter = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String DistanceAfterValue = "";
		for(WebElement value : DistanceAfter) {
			if(value.getAttribute("value") != null) {				
				DistanceAfterValue = value.getAttribute("value");
				break;
			}
		}
		if (SeatimeValue != SeatimeAfterValue){
			System.out.println("Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue);
			//cl.result("Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue, "", "Pass", "42584", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue);
			//cl.result("Not_Verified_SeaTime= " + SeatimeValue + " AfterSeaTime= " + SeatimeAfterValue, "", "Fail", "42584", 1, "Verify");
		}
		if (SpeedValue != SpeedAfterValue){
			System.out.println("Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue);
			//cl.result("Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue, "", "Pass", "42584", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue);
			//cl.result("Not_Verified_Speed= " +SpeedValue + " AfterSpeed= "+SpeedAfterValue, "", "Fail", "42584", 1, "Verify");
		}
		if (DistanceValue != DistanceAfterValue){
			System.out.println("Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue);
			//cl.result("Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue, "", "Pass", "42584", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue);
			//cl.result("Not_Verified_Distance= " +DistanceValue + " AfterDistance= "+DistanceAfterValue, "", "Fail", "42584", 1, "Verify");
		}
	
	}

}
