package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.time.Duration;
import java.time.LocalTime;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class calculation_16277 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		ChromeDriver driver = new ChromeDriver();
		try {
		System.out.println("****************************");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");	

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		//driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);
		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		//String Testbed_button = domain_url + "/schedule/testbed/gantt";
		Thread.sleep(3000);
		driver.get(domain_url + "/schedule/testbed/gantt"); 
		Thread.sleep(4000);
		
		//Step_1
		driver.findElement(By.xpath("(//span[normalize-space()='CREATE NEW SCHEDULE'])[1]")).click();
		Thread.sleep(4000);
		
		Actions actions = new Actions(driver);
		WebElement Lane = driver.findElement(
				By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		
		WebElement ArrivalTime = driver.findElement(By.xpath("//div[@id='port-arrival-00']"));
		WebElement DepartureTime = driver.findElement(By.xpath("//div[@id='port-departure-00']"));
		
		String ArrivalTimeValue = ArrivalTime.getText();
		String DepartureTimeValue = DepartureTime.getText();
		LocalTime noon = LocalTime.parse(ArrivalTimeValue);
        LocalTime midnight = LocalTime.parse(DepartureTimeValue);
        // Calculate the time difference
        Duration duration = Duration.between(noon, midnight);
        // Get the difference in hours and minutes
        long hours = Math.abs(duration.toHours());
        
        if (hours == 12) {
        	System.out.println("Verify_the_starttime_and_endtime_is_equals_12hours");
        	//cl.result("Verify_the_starttime_and_endtime_is_equals_12hours", "", "Pass", "16277", 1, "Verify");
        }
        else {
        	System.out.println("Verify_the_starttime_and_endtime_is_not_equals_12hours");
        	//cl.result("Verify_the_starttime_and_endtime_is_not_equals_12hours", "", "Fail", "16277", 1, "Verify");
        }
		}
	catch (Exception e) {
		System.out.println(e.getMessage());
		//cl.result(e.toString(), "", "Fail", "", 1,  "Verify");
		driver.close();
	}
		
 }
}

