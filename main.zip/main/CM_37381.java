package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CM_37381 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(4000);
		
		Robot robot = new Robot();
		VesselClick_Search.sendKeys("X-PRESS AGILITY");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		
		WebElement VesselClickName = driver.findElement(By.xpath("//div[@class='vessel_item_name']//span[contains(text(), 'X-PRESS AGILITY')]"));
		VesselClickName.click();
		Thread.sleep(8000);
		
		WebElement VesselSummaryPage = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[1]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPage.click();
		Thread.sleep(8000);
		
		WebElement VesselSummaryPageDF_SA = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[4]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPageDF_SA.click();
		Thread.sleep(8000);
		
		WebElement TEUs_Value = driver.findElement(By.xpath("(//div[@class='bsa-section']//div[@class='booking__remarks']//div[contains(text(), 'TEUs')]//..//..//../div[@class='booking__remarks__body']//div[@class='bsa-table-row']//div[@class='custom-cell-item custom-cell table-cell'])[1]"));
		String TEUs_ValueText = TEUs_Value.getText();
		
		if (TEUs_ValueText != null){
			System.out.println("TEUs Value=" + TEUs_ValueText);
			//cl.result("Verifyed_TEUs= " + TEUs_ValueText , "", "Pass", "37381", 1, "Verify");
		}
		else {
			System.out.println("TEUs Value=" + TEUs_ValueText);
			//cl.result("Not_Verifyed_TEUs_Value=+ " +TEUs_ValueText, "", "Fail", "37381", 1, "Verify");
		}
		
		WebElement Tons_Value = driver.findElement(By.xpath("(//div[@class='bsa-section']//div[@class='booking__remarks']//div[contains(text(), 'Tons')]//..//..//../div[@class='booking__remarks__body']//div[@class='bsa-table-row']//div[@class='custom-cell-item custom-cell table-cell'])[2]"));
		String Tons_ValueText = Tons_Value.getText().replace(" ", "");
		
		if (Tons_ValueText != null){
			System.out.println("Tons = " + Tons_ValueText);
			//cl.result("Verified_Tons= "+ Tons_ValueText, "", "Pass", "37381", 1, "Verify");
		}
		else {
			System.out.println("Not_Verfied_Tons =  "+ Tons_ValueText);
			//cl.result("Not_Verfied_Tons= "+ Tons_ValueText, "", "Fail", "37381", 1, "Verify");
		}
		
	}

}
