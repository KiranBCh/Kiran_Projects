package com.onetx.selenium.main;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class default_port_34333 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("//span[@class='buttonLabels']"));
		Thread.sleep(7000);
		
		vessle_click.click();
		Thread.sleep(7000);
		WebElement searchBox1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		Actions ac = new Actions(driver);
		Thread.sleep(4000);
		ac.click(searchBox1).perform();
		Thread.sleep(4000);
		WebElement searchBox2 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));		
		searchBox2.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(7000);
		WebElement selectname = driver.findElement(By.xpath("//div[text()='VerifyProfomaSearch1']"));
		selectname.click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath("//p[text()='Starting Port']/parent::div/descendant::div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']")).click();
		Thread.sleep(7000);
		
	    List<WebElement> ports = driver.findElements(By.xpath("//div[@class='q-virtual-scroll__content']/descendant::div[@class='q-item__section column q-item__section--main justify-center']"));
	    //System.out.println(ports);
		int count = ports.size();
		for(int i=0; i<count;i++) {

			String port1 = ports.get(0).getText();
			String port = ports.get(i).getText();
			if (port1.equals(port)) {
				System.out.println("Success ");
				//cl.result("Date_is_selected", "", "Pass", "33955", 1, "Date_is_selected");
				break;
				}
			else {
				System.out.println("Not Success ");
			}
			}
		//
		/*
		String verified_date_ele = selectname.getText();
		System.out.println("Element text: " + verified_date_ele);
		Thread.sleep(7000);
		boolean isEnabled1 = selectname.isEnabled();
		if (verified_date_ele == verified_date_ele){
        	System.out.println("Verifyed Profoma Search.");
        	//cl.result("Date_is_selected", "", "Pass", "33955", 1, "Date_is_selected");
        }
        else {
        	System.out.println("Verifyed Profoma not Searchable");
        	//cl.result("Date_is_not_selected", "", "Fail", "33955", 1, "Date_is_not_selected");
        }
        */
	}
}
