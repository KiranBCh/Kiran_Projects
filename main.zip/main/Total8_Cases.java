package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Total8_Cases {
	public static void main(String[] args) throws InterruptedException, AWTException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);

		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		Actions action = new Actions(driver);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);

		
		WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
		
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("Schedulearvind");
		Thread.sleep(4000);
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'Schedulearvind')]"));
		Sch1.click();
		Thread.sleep(3000);

		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("PADMA");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
//		waitSeconds();
//		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
//		Cycle.click();
//		Cycle.sendKeys("5");
//		Thread.sleep(5000);
//		
//		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
//		Vesselpos.click();
//		Vesselpos.sendKeys("4");
//		Thread.sleep(5000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("6");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        Prefix.sendKeys("HH");
        Thread.sleep(4000);
      
        WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        Suffix.sendKeys("20");
        Thread.sleep(8000);

        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        
        for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		} 
        Thread.sleep(4000);
		WebElement NavigateTo = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='read_more'])[1]"));
		NavigateTo.click();
		Thread.sleep(4000);
		
		WebElement ClickTerminal2 = driver.findElement(By.xpath("(//div[@class='data-table__sub-td'])[5]"));
		ClickTerminal2.click();
		Thread.sleep(4000);
		
		WebElement IntVoyage = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
		IntVoyage.click();
		Thread.sleep(4000);
		
		WebElement CurrentPort = driver.findElement(By.xpath("//p[@class='q-card-text']"));
		String PortCurrent = CurrentPort.getText();
        System.out.println(PortCurrent);
		
		
		WebElement CopyPrevious = driver.findElement(By.xpath("//p[contains(text(),'Copy Previous')]"));
//        String[] words = CopyPrevious.getText().split(" ");
        String CopyPre = CopyPrevious.getText();
        System.out.println(CopyPre);
//        String CopyPreviousValue = String.join(" ", Arrays.copyOfRange(words, 0, 2));
        
        WebElement CopyNext = driver.findElement(By.xpath("//p[contains(text(),'Copy Next')]"));
//        String[] words1 = CopyNext.getText().split(" ");
//        String CopyNextValue = String.join(" ", Arrays.copyOfRange(words1, 0, 2));
        String CopyNext1 = CopyNext.getText();
        System.out.println(CopyNext1);
        
        
        WebElement GenerateNew = driver.findElement(By.xpath("(//p[contains(text(),'Generate New')])[1]"));
//        String[] words2 = GenerateNew.getText().split(" ");
//        String GenerateNewValue= String.join(" ", Arrays.copyOfRange(words2, 0, 2));
        String Generatenew1 = GenerateNew.getText();
        System.out.println(Generatenew1);
        
        WebElement GenerateNeww = driver.findElement(By.xpath("(//p[contains(text(),'Generate New')])[2]"));
//      String[] words2 = GenerateNew.getText().split(" ");
//      String GenerateNewValue= String.join(" ", Arrays.copyOfRange(words2, 0, 2));
      String Generatenew2 = GenerateNeww.getText();
      System.out.println(Generatenew2);
        
        
        
        if (CurrentPort != null && CopyPre != null && CopyNext != null && GenerateNew != null && GenerateNeww != null && GenerateNew != null){
			System.out.println("verify current port "+ PortCurrent + "Verifyed Copy Previous "+ CopyPre + " CopyNext " + CopyNext+ " Generate New " + Generatenew1+ " GenerateNeww " + Generatenew2);
			//cl.result("Verifyed Copy Previous "+ CopyPreviousValue + " CopyNext " + CopyNextValue+ " Generate New " + GenerateNewValue, "", "Pass", "46653", 1, "Verify");
		}
        else {
        	System.out.println("Not_Verifyed Copy Previous "+ CopyPre + " CopyNext " + CopyNext+ " Generate New " + Generatenew1+ " GenerateNeww " + Generatenew2);
			//cl.result("Not_Verifyed Copy Previous "+ CopyPreviousValue + " CopyNext " + CopyNextValue+ " Generate New " + GenerateNewValue, "", "Pass", "46653", 1, "Verify");
		}

        
        
        WebElement Cancel = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle q-btn--actionable q-focusable q-hoverable button white']//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']"));
		Cancel.click();
		Thread.sleep(4000);
        
        WebElement Back = driver.findElement(By.xpath("//div[@class='arrow_back']//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']"));
		Back.click();
		Thread.sleep(8000);
		
		 WebElement newSailing1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
			newSailing1.click();
			Thread.sleep(5000);
			
			
			Actions actions = new Actions(driver);
			WebElement ManualToggle = driver.findElement(By.xpath("(//div[@class='q-toggle__track'])[1]"));
			actions.click(ManualToggle).perform();
			Thread.sleep(7000);
			
			WebElement ManualService = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[1]"));
			ManualService.click();
			ManualService.sendKeys("PADMA");
			Thread.sleep(4000);
			
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(4000);
			
			WebElement ManualOperator = driver.findElement(By.xpath("(//div[@class='vessel']//following::input[@class='q-field__input q-placeholder col'])[2]"));
			ManualOperator.click();
			
			
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			
			Thread.sleep(4000);
			
			WebElement ManualGenerate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
			ManualGenerate.click();
			Thread.sleep(7000);
			
			
			WebElement ScheduleInformation = driver.findElement(By.xpath("(//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation'])[2]"));
			ScheduleInformation.click();
			Thread.sleep(8000);
					
			WebElement AddPort = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
			AddPort.click();
			Thread.sleep(3000);
			
			WebElement AddPortName = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
			AddPortName.click();		
			Thread.sleep(3000);
			
			Thread.sleep(4000);
			AddPortName.sendKeys("AEAJM");
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			
			WebElement AddPort2 = driver.findElement(By.xpath("//span[normalize-space()='Add port & Terminal']"));
			AddPort2.click();
			Thread.sleep(3000);
			
			WebElement AddPortName2 = driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
			AddPortName2.click();		
			Thread.sleep(3000);
			
			AddPortName2.sendKeys("BDMGL");
			Thread.sleep(4000);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(4000);
			
			
//			
				
				WebElement AddportandTerminal = driver.findElement(By.xpath("//span[contains(text(),'Add port & Terminal')]"));
				AddportandTerminal.click();
				
				
				WebElement Port3Arr = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons q-select__dropdown-icon'])[16]"));
				Port3Arr.click();
		        Thread.sleep(4000);
		        
		        WebElement Port3Name = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[12]"));
		        Port3Name.sendKeys("Sharjah");
		        robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(4000);
				
				WebElement terminal1Checkbox = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[3]"));
				terminal1Checkbox.click();
				
				WebElement IntVoy1 = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
				IntVoy1.click();
				Thread.sleep(2000);
				
				WebElement Generate1 = driver.findElement(By.xpath("//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap']"));
				Generate1.click();
				Thread.sleep(2000);
				
				WebElement Confirm1 = driver.findElement(By.xpath("//span[contains(text(),'Confirm')]"));
				Confirm1.click();
				Thread.sleep(2000);
				
				WebElement term1 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[3]"));
				term1.click();
				Thread.sleep(2000);
				
				WebElement term2 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
				term2.click();
				Thread.sleep(2000);
				
				
				WebElement IntVoy2 = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
				IntVoy1.click();
				Thread.sleep(2000);
				
				WebElement CopyPre1 = driver.findElement(By.xpath("(//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap'])[1]"));
				CopyPre1.click();
				Thread.sleep(2000);
				
				WebElement Confirm2 = driver.findElement(By.xpath("//span[contains(text(),'Confirm')]"));
				Confirm2.click();
				Thread.sleep(2000);
				
				WebElement term2cb = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
				term2cb.click();
				Thread.sleep(2000);
				
				for (int i = 0; i < 1; i++) {
					robot.keyPress(KeyEvent.VK_CONTROL);
					robot.keyPress(KeyEvent.VK_SUBTRACT);
					robot.keyRelease(KeyEvent.VK_SUBTRACT);
					robot.keyRelease(KeyEvent.VK_CONTROL);
				} 
				
				WebElement term3 = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[9]"));
				term3.click();
				Thread.sleep(2000);
				
				WebElement IntVoy3 = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
				IntVoy3.click();
				Thread.sleep(2000);
				
				WebElement CopyPre2 = driver.findElement(By.xpath("(//div[@class='q-toggle cursor-pointer no-outline row inline no-wrap items-center xpf-toggle']//div[@class='q-toggle__thumb absolute flex flex-center no-wrap'])[1]"));
				CopyPre2.click();
				Thread.sleep(2000);
				
				WebElement Confirm3 = driver.findElement(By.xpath("//span[contains(text(),'Confirm')]"));
				Confirm3.click();
				Thread.sleep(2000);
				
				WebElement term3cb = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[9]"));
				term3cb.click();
				Thread.sleep(2000);
				
				WebElement term2final = driver.findElement(By.xpath("(//div[@class='q-checkbox__bg absolute'])[6]"));
				term2final.click();
				Thread.sleep(2000);
				
				WebElement IntVoyFinal = driver.findElement(By.xpath("//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--push q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense info_btn'][3]"));
				IntVoyFinal.click();
				Thread.sleep(2000);
				
				WebElement ManualCurrentPort = driver.findElement(By.xpath("//p[@class='q-card-text']"));
				String ManualCurrentPort1 = ManualCurrentPort.getText();
		        System.out.println(ManualCurrentPort1);
				
				
				WebElement ManualCopyPrevious = driver.findElement(By.xpath("//p[contains(text(),'Copy Previous')]"));
//		        String[] words = CopyPrevious.getText().split(" ");
		        String ManualCopyPre = ManualCopyPrevious.getText();
		        System.out.println(ManualCopyPre);
//		        String CopyPreviousValue = String.join(" ", Arrays.copyOfRange(words, 0, 2));
		        
		        WebElement ManualCopyNext = driver.findElement(By.xpath("//p[contains(text(),'Copy Next')]"));
//		        String[] words1 = CopyNext.getText().split(" ");
//		        String CopyNextValue = String.join(" ", Arrays.copyOfRange(words1, 0, 2));
		        String ManualCopyNext1 = ManualCopyNext.getText();
		        System.out.println(ManualCopyNext1);
		        
		        
		        WebElement ManualGenerateNew = driver.findElement(By.xpath("(//p[contains(text(),'Generate New')])[1]"));
//		        String[] words2 = GenerateNew.getText().split(" ");
//		        String GenerateNewValue= String.join(" ", Arrays.copyOfRange(words2, 0, 2));
		        String ManualGeneratenew1 = ManualGenerateNew.getText();
		        System.out.println(ManualGeneratenew1);
		        
		        WebElement ManualGenerateNeww = driver.findElement(By.xpath("(//p[contains(text(),'Generate New')])[2]"));
//		      String[] words2 = GenerateNew.getText().split(" ");
//		      String GenerateNewValue= String.join(" ", Arrays.copyOfRange(words2, 0, 2));
		      String ManualGeneratenew2 = ManualGenerateNeww.getText();
		      System.out.println(ManualGeneratenew2);
		        
		        
		        
		        if (ManualCurrentPort != null && ManualCopyPre != null && ManualCopyNext != null && ManualGenerateNew != null && ManualGenerateNeww != null && ManualGenerateNew != null){
					System.out.println("verify current port "+ PortCurrent + "Verifyed Copy Previous "+ CopyPre + " CopyNext " + CopyNext+ " Generate New " + Generatenew1+ " GenerateNeww " + Generatenew2);
					//cl.result("Verifyed Copy Previous "+ CopyPreviousValue + " CopyNext " + CopyNextValue+ " Generate New " + GenerateNewValue, "", "Pass", "46653", 1, "Verify");
				}
		        else {
		        	System.out.println("Not_Verifyed Copy Previous "+ CopyPre + " CopyNext " + CopyNext+ " Generate New " + Generatenew1+ " GenerateNeww " + Generatenew2);
					//cl.result("Not_Verifyed Copy Previous "+ CopyPreviousValue + " CopyNext " + CopyNextValue+ " Generate New " + GenerateNewValue, "", "Pass", "46653", 1, "Verify");
				}

	}
}
