package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Rest_PF_47641 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		Thread.sleep(5000);
		//String Url1 = "https://dev01bridgesitstapp.z23.web.core.windows.net/schedule/services/gantt";
		//driver.get(Url1);
		//Thread.sleep(5000);
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		Thread.sleep(5000);
		//WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		WebElement newSailing = driver.findElement(By.xpath("//span[normalize-space()='NEW SAILING VESSEL']"));
		newSailing.click();
		Thread.sleep(8000);
		
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch1.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("ALS KRONOS");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
				
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
       
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        
        Actions act = new Actions(driver);
        WebElement element2 = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		act.moveToElement(element2).build().perform();
		Thread.sleep(8000);
		WebElement Port = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::div[@class='q-field__native row items-center'])[1]"));
		act.contextClick(Port).build().perform();
		Thread.sleep(4000);
 
		WebElement RestructureButton = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[1][@class='q-item__section column q-item__section--main justify-center header'])[4]"));
		RestructureButton.click();
		Thread.sleep(4000);
		
		//Verification 1st done
		WebElement TimePicker = driver.findElement(By.xpath("//div[@class='dateport']//div[@class='q-field__append q-field__marginal row no-wrap items-center']"));
		TimePicker.click();
		Thread.sleep(3000);
		
		//BeforeEffectdate
		WebElement changeEffectTime = driver.findElement(By.xpath("(//div[@class='q-date__calendar-days fit']//button[@class='q-btn q-btn-item non-selectable no-outline q-btn--flat q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--dense'])[3]"));
		changeEffectTime.click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//h6[contains(text(), 'Remarks')]")).click();
		Thread.sleep(3000);
		
		WebElement DepartureTime = driver.findElement(By.xpath("//div[@class='port-details-container']//div[@class='port-details']//p[contains(text(), 'Departure Time')]//b"));
		String DepartureTimeValue = DepartureTime.getText().replace(",", "");

		if (DepartureTimeValue != null){
            System.out.println("DepartureTime " + DepartureTime);
            cl.ActualTestDataValue ="Departure datetime of Port";
	          cl.result("Verifyed departure datetime "+  DepartureTimeValue, "Departure Date and Time" , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("DepartureTime " + DepartureTime);
            cl.ActualTestDataValue ="Departure datetime of Port";
	          cl.result("Not Verifyed departure datetime "+  DepartureTimeValue, "Departure Date and Time" , "Fail", "", 1, "VERIFY");
        }
		List<WebElement> AfterEffectdate = driver.findElements(By.xpath("(//div[@class='dateport']//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']//input)[2]"));
		String AfterEffectdateValue = "";
		for(WebElement value : AfterEffectdate) {
			if(value.getAttribute("value") != null) {				
				AfterEffectdateValue = value.getAttribute("value");
				System.out.println("AfterEffectdateValue " + AfterEffectdateValue);
				break;
			}
		}
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");
        // Parse the date strings to LocalDateTime objects
        LocalDateTime date1 = LocalDateTime.parse(DepartureTimeValue, formatter);
        LocalDateTime date2 = LocalDateTime.parse(AfterEffectdateValue, formatter);

        if (date1.isBefore(date2)){
            System.out.println("User is able to select date and time to be greater than departure time/date of Port");
            cl.ActualTestDataValue ="User is able to select datetime to be greater than departure datetime of Port";
	          cl.result("Verifyed user is able to select the datetime to be greater than departure datetime "+ " After Effect date "+  AfterEffectdateValue, "User able to change the Date and Time" , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("User is not able to select date and time to be lesser than departure time/date of Port");
            cl.ActualTestDataValue ="User is able to select datetime to be lesser than departure datetime of Port";
            cl.result("Verifyed user is able to select the datetime to be greater than departure datetime "+ " After Effect date "+  AfterEffectdateValue, "User able to change the Date and Time" , "Fail", "", 1, "VERIFY");
        }
        
        WebElement TimePicker1 = driver.findElement(By.xpath("//div[@class='dateport']//div[@class='q-field__append q-field__marginal row no-wrap items-center']"));
		TimePicker1.click();
				
        WebElement LessThan = driver.findElement(By.xpath("//div[@class='q-date__calendar-days fit']//div[@class='q-date__calendar-item q-date__calendar-item--out']"));
        boolean LessThanValue = LessThan.getAttribute("class").contains("out");
        
        if (LessThanValue == true) {
            System.out.println("User is able to select date and time to be lesser than departure time/date of Port");
            cl.ActualTestDataValue ="User is not able to select datetime to be lesser than departure datetime of Port";
	          cl.result("Verifyed user is not able to select the datetime to be lesser than departure datetime", "Unable to change the Date and Time" , "Pass", "", 1, "VERIFY");
        } else {
        	System.out.println("User is able to select date and time to be lesser than departure time/date of Port");
            cl.ActualTestDataValue ="User is able to select datetime to be lesser than departure datetime of Port";
	          cl.result("Verifyed user is able to select the datetime to be lesser than departure datetime", "Able to change the Date and Time" , "Fail", "", 1, "VERIFY");
        }
                
	}
}
