package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TESTBED_Validating_time_Ganttchart_31245_31246_31247 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Alumni@2023");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[@id='next']")).click();
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(9000);
		
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Thread.sleep(9000);
		vessle_click.click();
		Thread.sleep(9000);
		Actions actions = new Actions(driver);
		Robot robot = new Robot();
		/*
		WebElement laneblock = driver.findElement(By.xpath("(//div[text()='1']/ancestor::div[@id='weeks']//div[@class='dayRows']/div[@id='block'])[2]"));
		WebElement schblock=driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']"));
		int x=laneblock.getLocation().getX();
		int y=laneblock.getLocation().getY();
		System.out.println("x-->"+x+"     y--->"+y);
		actions.moveByOffset(135, 270).click(laneblock).perform();
		int xCoordinate = x; 
        int yCoordinate = y;
		Thread.sleep(2000);
		//driver.switchTo().frame(0);
		//Thread.sleep(2000);
		//actions.moveByOffset(135, 270).contextClick(schblock).build().perform();
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

        // Execute JavaScript to simulate a right-click at specific coordinates
        String script = "var event = new MouseEvent('contextmenu', {" +
                        "  bubbles: true," +
                        "  cancelable: false," +
                        "  view: window," +
                        "  clientX: arguments[1]," +
                        "  clientY: arguments[2]" +
                        "});" +
                        "arguments[0].dispatchEvent(event);";
        jsExecutor.executeScript(script, schblock, x, y);
        Thread.sleep(2000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		actions.moveByOffset(135, 300).click().perform();
		actions.moveByOffset(135, 300).contextClick().perform();
		driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]")).click();
		*/
		
		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, 100)","");
		
		Thread.sleep(3000);
		WebElement Lane1 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane1).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane1).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton2 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton2.click();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,105)","");
		Thread.sleep(3000);
		WebElement Lane2 = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.click(Lane2).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane2).build().perform();
		Thread.sleep(5000);
		
		WebElement AddPortButton3 = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton3.click();
		
		WebElement element1 = driver.findElement(By.xpath("(//div[@class='q-card portBlock default resizable'])[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center', inline: 'center'});", element1);
	 
		
	}

}
