package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Man_40815 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Service')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
		
		Thread.sleep(8000);
		WebElement vessle_click = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		vessle_click.click();
		Thread.sleep(7000);
		
		WebElement ToggleButton = driver.findElement(By.xpath("//div[@id='toggle']"));
		ToggleButton.click();
		Thread.sleep(2000);
		
		WebElement VesselNameClick = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		VesselNameClick.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		//Actions actions = new Actions(driver);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']")).click();
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
        Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
        driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[@class='data-table__sticky-column_2']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@id='btnAddPortTerminal']")).click();
		Thread.sleep(3000);
		
		List<WebElement> SpeedAfter = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[4]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedValue = "";
		for(WebElement value : SpeedAfter) {
			if(value.getAttribute("value") != null) {				
				SpeedValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> DistanceAfter = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[4]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String DistanceValue = "";
		for(WebElement value : DistanceAfter) {
			if(value.getAttribute("value") != null) {				
				DistanceValue = value.getAttribute("value");
				break;
			}
		}
		
		List<WebElement> SpeedBefore = driver.findElements(By.xpath("//th[normalize-space()='Speed (KTS)']//following::tr[6]//td//input[@class='q-field__native q-placeholder text-center']"));
		String SpeedAfterBeforeValue = "";
		for(WebElement value : SpeedBefore) {
			if(value.getAttribute("value") != null) {				
				SpeedAfterBeforeValue = value.getAttribute("value");
				break;
			}
		}
		List<WebElement> DistanceBefore = driver.findElements(By.xpath("(//th[normalize-space()='Distance (NM)']//following::tr[6]//td//input[@class='q-field__input q-placeholder col'])[2]"));
		String DistanceBeforeValue = "";
		for(WebElement value : DistanceBefore) {
			if(value.getAttribute("value") != null) {				
				DistanceBeforeValue = value.getAttribute("value");
				break;
			}
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ScrollRight = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']"));
		js.executeScript("arguments[0].scrollIntoView(true);", ScrollRight);
	
		WebElement Scrolldown = driver.findElement(By.xpath("//tr[@class='data-table__port-row'][2]//td[@class='data-table__sticky-column_2']//div[@class='q-checkbox__inner relative-position non-selectable q-checkbox__inner--falsy']"));
		js.executeScript("arguments[0].scrollIntoView(true);", Scrolldown);
		
		if (SpeedAfterBeforeValue != SpeedValue){
			System.out.println("Verified After Speed " + SpeedValue + " Before Speed " + SpeedAfterBeforeValue);
			//cl.result("Verified After Speed " + SpeedValue + " Before Speed " + SpeedAfterBeforeValue, "", "Pass", "40815", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified After Speed " + SpeedValue + " Before Speed " + SpeedAfterBeforeValue);
			//cl.result("Not_Verified After Speed " + SpeedValue + " Before Speed " + SpeedAfterBeforeValue, "", "Fail", "40815", 1, "Verify");
		}
		
		if (DistanceValue != DistanceBeforeValue){
			System.out.println("Verified After Distance " + DistanceValue + " Before Distance " + DistanceBeforeValue);
			//cl.result("Verified After Distance " + DistanceValue + " Before Distance " + DistanceBeforeValue, "", "Pass", "40815", 1, "Verify");
		}
		else {
			System.out.println("Not_Verified After Distance= " + DistanceValue + " Before Distance " + DistanceBeforeValue);
			//cl.result("Not_Verified After Distance " + DistanceValue + " Before Distance " + DistanceBeforeValue, "", "Fail", "40815", 1, "Verify");
		}
	}
}
