package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CM_24683 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgecapsitstapp.z23.web.core.windows.net/";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		
		WebElement ClickVessel = driver.findElement(By.xpath("//li[contains(text(),'By Vessel')]"));
		ClickVessel.click();
		Thread.sleep(3000);
		
		WebElement VesselClick_Search = driver.findElement(By.xpath("//input[@class='q-field__input q-placeholder col by-vessel-functional-bar-select-input']"));
		VesselClick_Search.click();
		Thread.sleep(8000);
		
		Robot robot = new Robot();
		VesselClick_Search.sendKeys("A KIBO");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(8000);
		
		//WebElement VesselClickName = driver.findElement(By.xpath("(//div[@class='q-scrollarea__content absolute']//div[@class='vessel_item_name'])[1]"));
		WebElement VesselClickName1 = driver.findElement(By.xpath("//span[contains(text(),'A KIBO →')]"));
		VesselClickName1.click();
		Thread.sleep(8000);
		
		WebElement VesselSummaryPage = driver.findElement(By.xpath("(//div[@class='q-drawer__content fit overflow-auto']//div//i)[1]")); //(//i[normalize-space()='chevron_right'])[1]
		VesselSummaryPage.click();
		Thread.sleep(8000);
		/*
		WebElement VesselCodeHeading = driver.findElement(By.xpath("//div[@class='port-contractual-details-repeated']//div//div[contains(@class, 'vessel-code-heading')]"));
		//String VesselCodeHeadingText = VesselCodeHeading.getText();
		//System.out.println(VesselCodeHeadingText);
		Thread.sleep(8000);
		
		WebElement PortCodeHeading = driver.findElement(By.xpath("//div[@class='port-contractual-details-repeated']//div//div[contains(@class, 'port-code-heading')]"));
		//String PortCodeHeadingText = PortCodeHeading.getText();
		//System.out.println(PortCodeHeadingText);
		Thread.sleep(8000);
		*/
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ScrollDown = driver.findElement(By.xpath("//div[@class='q-scrollarea fit']//div[@class='q-scrollarea__thumb q-scrollarea__thumb--v absolute-right']"));
		//System.out.println(ScrollDown.getAttribute("style"));
		String ScrollDownPage = ScrollDown.getAttribute("style");
		
		Actions actions = new Actions(driver);
		int verticalScrollAmount = 300; // Adjust as needed
		actions.moveToElement(ScrollDown).clickAndHold().moveByOffset(0, verticalScrollAmount).release().perform();
		Thread.sleep(3000);
		
		WebElement ScrollDownLast = driver.findElement(By.xpath("//div[@class='q-scrollarea fit']//div[@class='q-scrollarea__thumb q-scrollarea__thumb--v absolute-right']"));
		//System.out.println(ScrollDownLast.getAttribute("style"));
		String ScrollDownLastPage = ScrollDownLast.getAttribute("style");
		
		if (ScrollDownPage.equals(ScrollDownLastPage)){
			System.out.println("User_can_not_scroll_between_the_port_details_bars");
			//cl.result("User_can_not_scroll_between_the_port_details_bars", "", "Fail", "24683", 1, "Verify");
		}
		else {
			System.out.println("User_can_scroll_between_the_port_details_bars");
			//cl.result("Verifyed_user_can_scroll_between_the_port_details_bars.", "", "Pass", "24683", 1, "Verify");
		}
		
		Thread.sleep(3000);
	}

}
