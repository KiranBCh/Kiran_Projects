package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_REST_47644 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://dev01bridgesitstapp.z23.web.core.windows.net");
		Thread.sleep(4000);
 
		WebElement Username = driver.findElement(By.xpath("//input[@type='email']"));
		Username.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
 
		WebElement Pass = driver.findElement(By.xpath("//input[@type='password']"));
		Pass.sendKeys("Alumni@2023" + Keys.ENTER);
		Thread.sleep(9000);
		
		driver.navigate().refresh();
		Thread.sleep(6000);
 
		
		WebElement Services = driver.findElement(By.xpath("//li[contains(text(),'Services')]"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].click();", Services);
		Thread.sleep(9000);
 
		
		WebElement newSailing = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		newSailing.click();
		Thread.sleep(8000);
		
		WebElement profomaname = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
		TxtboxProfoma.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		
		
		WebElement Sch1 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch1.click();
		Thread.sleep(3000);
 
		WebElement Clickves = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[1]"));
		Clickves.click();
		Clickves.sendKeys("PADMA");
		Thread.sleep(5000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		
		WebElement Operator = driver.findElement(By.xpath("(//input[@class='q-field__input q-placeholder col'])[2]"));
		Thread.sleep(2000);
		Operator.click();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		
		WebElement Cycle = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[3]"));
		Cycle.click();
		Cycle.sendKeys("5");
		Thread.sleep(5000);
		
		WebElement Vesselpos = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[4]"));
		Vesselpos.click();
		Vesselpos.sendKeys("4");
		Thread.sleep(5000);
		
		WebElement Characters = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[5]"));
		Characters.click();
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        Characters.sendKeys("7");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
        
        WebElement StartingNum = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[6]"));
        StartingNum.click();
        StartingNum.sendKeys("2");
        Thread.sleep(8000);
        
        WebElement Prefix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[7]"));
        Prefix.sendKeys("HH");
        Thread.sleep(4000);
      
        WebElement Suffix = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[9]"));
        Suffix.sendKeys("20");
        Thread.sleep(8000);
 
        WebElement Generate = driver.findElement(By.xpath("//span[contains(text(),'GENERATE')]"));
        Generate.click();
        Thread.sleep(8000);
        
        Actions act = new Actions(driver);
        WebElement element2 = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::input[@class='q-field__input q-placeholder col'])[1]"));
		act.moveToElement(element2).build().perform();
		Thread.sleep(8000);
		WebElement Port = driver.findElement(By.xpath(
				"((//div[@class='service-lane'])[2]//following::div[@class='q-field__native row items-center'])[1]"));
		act.contextClick(Port).build().perform();
		Thread.sleep(4000);
 
		WebElement PhaseOutClick = driver.findElement(By.xpath("(//i[@class='q-icon notranslate material-icons icon']//following::div[1][@class='q-item__section column q-item__section--main justify-center header'])[4]"));
		PhaseOutClick.click();
		Thread.sleep(4000);
		
		WebElement profomaname1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[1]"));
		profomaname1.click();
		Thread.sleep(5000);
		
		WebElement TxtboxProfoma1 = driver.findElement(By.xpath("(//input[@class='q-field__native q-placeholder'])[8]"));
		TxtboxProfoma1.sendKeys("VerifyProfomaSearch1");
		Thread.sleep(4000);
		
		WebElement Sch11 = driver.findElement(By.xpath("//div[contains(text(),'VerifyProfomaSearch1')]"));
		Sch11.click();
		Thread.sleep(3000);
		
		WebElement Cycle1 = driver.findElement(By.xpath("//div[@class='cycle']//div[@class='q-field__inner relative-position col self-stretch']//input"));
		Cycle1.click();
		Cycle1.sendKeys("1");
	
		
		WebElement VesselPo = driver.findElement(By.xpath("//div[@class='vessel-position']//div[@class='q-field__inner relative-position col self-stretch']//input"));
		VesselPo.click();
		VesselPo.sendKeys("1");
		
	}
}
