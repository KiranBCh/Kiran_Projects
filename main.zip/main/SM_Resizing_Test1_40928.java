package com.onetx.selenium.main;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_Resizing_Test1_40928 {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		
		WebElement Schedule1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Schedule1.click();
		Thread.sleep(9000);
        Actions actions = new Actions(driver);

		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.moveToElement(Lane).build().perform();
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(5000);
		
		
		WebElement draggableElement = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='timing']")); 
		String currentStyle = draggableElement.getAttribute("style");
		System.out.println(currentStyle);
		dragElementWithStyle(driver, draggableElement, 0, 50);
		//resizeElementWithStyle(driver, resizableElement, "width: 50px; height: 200px;");
		Thread.sleep(5000);
}
		
		private static void dragElementWithStyle(WebDriver driver, WebElement element, int xOffset, int yOffset) {
	        // Create an instance of Actions class
	        Actions actions = new Actions(driver);

	        // Perform drag-and-drop using Actions
	        actions.clickAndHold(element)
	               .moveByOffset(xOffset, yOffset)
	               .release()
	               .perform();

	        // Get the updated style attribute after the drag-and-drop
	        String updatedStyle = element.getAttribute("style");

	        // Update the style attribute with JavaScript to reflect the new position
	        updateStyleWithJavaScript(driver, element, xOffset, yOffset, updatedStyle);
	    }

		// Function to update the style attribute with JavaScript
	    private static void updateStyleWithJavaScript(WebDriver driver, WebElement element, int xOffset, int yOffset, String updatedStyle) {
	        // Create an instance of JavascriptExecutor
	        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

	        // Calculate the new position based on the xOffset and yOffset
	        String script = "var element = arguments[0];" +
	                        "var xOffset = arguments[1];" +
	                        "var yOffset = arguments[2];" +
	                        "var updatedStyle = arguments[3];" +
	                        "element.style.left = (parseInt(updatedStyle.split(';')[1].split(':')[1].trim()) + xOffset) + 'px';" +
	                        "element.style.top = (parseInt(updatedStyle.split(';')[0].split(':')[1].trim()) + yOffset) + 'px';";

	        // Execute the JavaScript to set the new style attribute
	        jsExecutor.executeScript(script, element, xOffset, yOffset, updatedStyle);
	    }
   }

