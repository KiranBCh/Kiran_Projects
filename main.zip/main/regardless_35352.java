package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class regardless_35352 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");

		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));

		Pass.sendKeys("Alumni@2023");		

		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));

		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement new_schedule_button = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		new_schedule_button.click();
		Thread.sleep(7000);
		Robot robot = new Robot();
		WebElement Lane = driver.findElement(
				By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		Actions actions = new Actions(driver);
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(4000);
		
		WebElement ArrivalTime = driver.findElement(By.xpath("//div[@id='port-arrival-00']"));
		WebElement DepartureTime = driver.findElement(By.xpath("//div[@id='port-departure-00']"));
		
		System.out.println(ArrivalTime.getText());
		
		/*
		WebElement AddPortName = driver.findElement(By.xpath("//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col']"));
		Thread.sleep(2000);
		AddPortName.sendKeys("ITAOI");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		*/
		//robot.keyPress(KeyEvent.)
		//robot.keyPress(KeyEvent.VK_DOWN);
		//robot.keyRelease(KeyEvent.VK_DOWN);
		//Thread.sleep(4000);
		
		//actions.moveToElement(AddPortName).perform();
		//actions.click().perform();
		Thread.sleep(7000);
		//driver.close();
		}

}
