package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Arvind_46498 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));

		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(7000);
		String string1 = domain_url + "/schedule/services/gantt";
		driver.get(string1);
		
		Thread.sleep(7000);
		WebElement vessle_click = driver.findElement(By.xpath("(//span[@class='buttonLabels'])[2]"));
		vessle_click.click();
		Thread.sleep(8000);
		
		WebElement vessle_click1 = driver.findElement(By.xpath("//div[@class='q-toggle__inner relative-position non-selectable q-toggle__inner--falsy'][1]"));
		vessle_click1.click();
		Thread.sleep(8000);
		
		WebElement vessel_click = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[1]"));
		vessel_click.click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		Actions actions = new Actions(driver);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement vessel_click3 = driver.findElement(By.xpath("(//i[@role='presentation'][normalize-space()='arrow_drop_down'])[2]"));
		vessel_click3.click();
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		
		WebElement generator = driver.findElement(By.xpath("//span[text()='GENERATE']"));
		generator.click();
		Thread.sleep(2000);
		WebElement Lane = driver.findElement(By.xpath("((//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']//div[@class='service-lane'])[2]"));
		actions.click(Lane).build().perform();
		Thread.sleep(3000);
		actions.contextClick(Lane).build().perform();
		Thread.sleep(3000);
		
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		Thread.sleep(3000);
		
		WebElement AddPortName = driver.findElement(By.xpath("(//div[@class='displayLabelGrid']//input[@class='q-field__input q-placeholder col'])[1]"));
		Thread.sleep(2000);
		actions.moveToElement(AddPortName).doubleClick().perform();
		actions.contextClick(AddPortName).build().perform();
		Thread.sleep(3000);
		WebElement PhaseOutClick = driver.findElement(By.xpath("//i//img[@alt='Phase out']//following::div[1][@class='q-item__section column q-item__section--main justify-center header']"));
		PhaseOutClick.click();
		Thread.sleep(3000);
		
		//driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		//driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
		//driver.findElement(By.xpath("((//div[@class='q-checkbox__bg absolute'])[last()-2]//following::input)[1]"));
	}

}
