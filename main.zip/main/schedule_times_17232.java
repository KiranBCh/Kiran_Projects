package com.onetx.selenium.main;

import java.awt.AWTException;
import java.time.Duration;
import java.time.LocalTime;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class schedule_times_17232 {
	public static void main(String[] args) throws InterruptedException, AWTException {
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(7000);
		
		WebElement new_schedule_button = driver.findElement(By.xpath("//span[normalize-space()='CREATE NEW SCHEDULE']"));
		new_schedule_button.click();
		Thread.sleep(3000);

		WebElement schedule_information = driver.findElement(By.xpath("//div[@class='schedule-btn-group']//button[@id='itmScheduleInformationNavigation']"));
		schedule_information.click();
		Thread.sleep(4000);
		
		WebElement add_port_terminal = driver.findElement(By.xpath("//span[@class='block']"));
		add_port_terminal.click();
		Thread.sleep(3000);
		
		WebElement ArrivalTime1  = driver.findElement(By.xpath("//th[normalize-space()='Arrival Time']//following::td[19]"));
		WebElement DepartureTime1 = driver.findElement(By.xpath("//th[normalize-space()='Departure Time']//following::td[22]"));
		String ArrivalTime = ArrivalTime1.getText().replace("Week 1, Mon ", "");
		String DepartureTime = DepartureTime1.getText().replace("Week 1, Tue ", "");
		LocalTime noon = LocalTime.parse(ArrivalTime);
        LocalTime midnight = LocalTime.parse(DepartureTime);
        // Calculate the time difference
        Duration duration = Duration.between(noon, midnight);
        // Get the difference in hours and minutes
        long hours = Math.abs(duration.toHours());
        
        
        WebElement StayValue1 = driver.findElement(By.xpath("//th[normalize-space()='Stay']//following::tr[2]//td[16]"));
        String StayValue = StayValue1.getText();
        long StayValueText = Integer.parseInt(StayValue);
        
        if (StayValueText == hours) {
        	System.out.println("Verifyed_PortStay_Is_Equals(DepartureTime - ArrivalTime)");
        }
        else {
        	System.out.println("Verifyed_PortStay_Is_Not_Equals_To(DepartureTime - ArrivalTime)");
        }
        WebElement PilotIn = driver.findElement(By.xpath("//th[normalize-space()='Pilot In']//following::tr[1]//td[23]"));
		WebElement PilotOut = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out']//following::tr[1]//td[25]"));
		WebElement PilotIn_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot In ARKS']//following::tr[1]//td[24]"));
		WebElement PilotOut_ARKS = driver.findElement(By.xpath("//th[normalize-space()='Pilot Out ARKS']//following::tr[1]//td[26]"));
		WebElement bufferTimeValue = driver.findElement(By.xpath("//th[normalize-space()='Buffer Time']//following::tr[2]//td[18]"));
		
		int pilotInText = Integer.parseInt(PilotIn.getText());
        int PilotOutText = Integer.parseInt(PilotOut.getText());
        int PilotInARKSText = Integer.parseInt(PilotIn_ARKS.getText());
        int PilotOutARKSText = Integer.parseInt(PilotOut_ARKS.getText());
        int bufferTimeValueText = Integer.parseInt(bufferTimeValue.getText());
        int Shifting_AllTerminals = 0;
        int ARKS_Shifting_AllTerminals = 0;
        int PortBuffer = pilotInText + PilotOutText + Shifting_AllTerminals - PilotInARKSText - PilotOutARKSText - ARKS_Shifting_AllTerminals;
        
        if (bufferTimeValueText == PortBuffer) {
        	System.out.println("Verifyed_PortBufferTime_Is_Equals(bufferTimeValue)");
        }
        else {
        	System.out.println("Verifyed_PortBufferTime_Is_Not_Equals(bufferTimeValue)");
        }
	}

}
