package com.onetx.selenium.main;

import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SM_31244_Draging {
public static void main(String[] args) throws InterruptedException, AWTException {
		
		System.out.println("****************************");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KiranbabuChiluvuru\\eclipse-workspace\\Kiran_babu_java\\Driver\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		String domain_url = "https://dev01bridgesitstapp.z23.web.core.windows.net";
		driver.get(domain_url);
		driver.manage().window().maximize();
		Thread.sleep(3000);

		WebElement Email = driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("sudhakar.lakshmanaraj@alumniserv.com");
		Thread.sleep(3000);

		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("Alumni@2023");		
		Thread.sleep(3000);

		WebElement Signin = driver.findElement(By.xpath("//button[@id='next']"));
		Signin.click();
		Thread.sleep(3000);
		String Testbed_button = domain_url + "/schedule/testbed/gantt";
		driver.get(Testbed_button);
		Thread.sleep(9000);
		
		WebElement Schedule1 = driver.findElement(By.xpath("//button[@id='btnCreateNewSchedule']"));
		Schedule1.click();
		Thread.sleep(9000);
        Actions actions = new Actions(driver);

		WebElement Lane = driver.findElement(By.xpath("(//div[@id='block'])[2]//following::div[@class='columnbackground schedule-lane']"));
		actions.moveToElement(Lane).build().perform();
		actions.contextClick(Lane).build().perform();
		Thread.sleep(5000);
		WebElement AddPortButton = driver.findElement(By.xpath("(//div[@id='itmAddPort'])[1]"));
		AddPortButton.click();
		
		WebElement handleElement = driver.findElement(By.xpath("//div[@class='columnbackground schedule-lane']//div[@class='timings']//div[@class='q-card portBlock default resizable']"));
		dragHandleWithJavaScript(driver, handleElement);

}

private static void dragHandleWithJavaScript(ChromeDriver driver, WebElement handleElement) {
	// TODO Auto-generated method stub
	JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

    // Replace 'xOffset' and 'yOffset' with the desired drag distance
    int xOffset = 150;
    int yOffset = 100;

    // Execute JavaScript to simulate the drag-and-drop
    jsExecutor.executeScript(
            "var element = arguments[0];" +
            "var xOffset = arguments[1];" +
            "var yOffset = arguments[2];" +
            "var event = document.createEvent('MouseEvents');" +
            "event.initMouseEvent('mousedown', true, true, window, 0, 0, 0, xOffset, yOffset, false, false, false, false, 0, null);" +
            "element.dispatchEvent(event);" +
            "event = document.createEvent('MouseEvents');" +
            "event.initMouseEvent('mousemove', true, true, window, 0, 0, 0, xOffset, yOffset, false, false, false, false, 0, null);" +
            "element.dispatchEvent(event);" +
            "event = document.createEvent('MouseEvents');" +
            "event.initMouseEvent('mouseup', true, true, window, 0, 0, 0, xOffset, yOffset, false, false, false, false, 0, null);" +
            "element.dispatchEvent(event);",
            handleElement, xOffset, yOffset
    );
}

}
