from fastapi import Body, FastAPI

BOOKS = [
    {
        "title": "C",
        "author": "author",
        "age": 35
    },
    {
        "title": "C++",
        "author": "Author2",
        "age": 30
    },
    {
        "title": "Java",
        "author": "Author3",
        "age": 39
    },
    {
        "title": "Python",
        "author": "Author4",
        "age": 32
    },
    {
        "title": "FastAPI",
        "author": "Author5",
        "age": 32
    }
]
app = FastAPI()

@app.get("/books")
async def read_all_books():
    return BOOKS

@app.get("/books/{author}")
async def read_all_author(author: str):
    final_list = []
    for book in BOOKS:
        if book.get("author").casefold() == author.casefold():
            final_list.append(book)
    return final_list


@app.get("/books/{title}")
async def read_book(title: str):
    for book in BOOKS:
        if book.get("title").casefold() == title.casefold():
            return book

@app.get("/books/")
async def read_books_age(age: int):
    books_list = []
    for book in BOOKS:
        if book.get("age") == age:
            books_list.append(book)
    return books_list

@app.post("/books/create_book")
async def insert_book(insert_data=Body()):
    BOOKS.append(insert_data)


@app.put("/books/update_book")
async def update_book(update_data=Body()):
    for i in range(len(BOOKS)):
        if BOOKS[i].get("title").casefold() == update_data.get("title").casefold():
            BOOKS[i] = update_data
@app.delete("/books/delete_book/{book_title}")
async def delete_book(book_title: str):
    for i in range(len(BOOKS)):
        if BOOKS[i].get("title").casefold() == book_title.casefold():
            BOOKS.pop(i)
            break


