import requests

headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
}

data = 'project=caryak&spider=car_prices_sellmax&batch_com=52&batch_id=24&vin=5YJ3E1EB7MF960910&trim=Long Range Sedan 4D&zip_code=77381&mileage=81000&condition=excellent'

response = requests.post('http://3.230.199.190:14200/schedule.json', headers=headers, data=data).json()
print(response)
