from pydantic import BaseModel, Field



class Kiran(BaseModel):
    name : str = Field(min_length=3, max_length=10)
    age : int = Field(lt=3)

class Babu(BaseModel):
    phone_number: int
    location: str


data = {
    "name": "KiranBabu",
    "age": 35
}

book = Kiran(name="kiranbabu", age=35).dict()
book1 = Kiran(**data).dict()
#print(dir(book))
print(book)
print(book1)
print(type(book1))
print(type(book))