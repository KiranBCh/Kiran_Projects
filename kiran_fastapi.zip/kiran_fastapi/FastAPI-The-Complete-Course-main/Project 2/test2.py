from fastapi import FastAPI, HTTPException
from typing import Optional

from pydantic import BaseModel, Field


app = FastAPI()

class Book:
    id : int
    title: str
    author: str
    description: str
    rating: int
    public_year: int
    def __init__(self, id, title, author, description, rating, public_year):
        self.id = id
        self.title = title
        self.author = author
        self.description = description
        self.rating = rating 
        self.public_year = public_year
BOOKS  = [
    Book(1, 'Java', 'codingwithroby', 'A very nice book!', 4, 2012),
    Book(2, 'Python', 'codingwithroby', 'A very nice book!', 5,2013),
    Book(3, 'Pandas', 'codingwithroby', 'A very nice book!', 5, 2014),
    Book(4, 'Scrapy', 'codingwithroby', 'A very nice book!', 3, 2016),
    Book(5, 'Selenium', 'codingwithroby', 'A very nice book!', 2, 2018),
    Book(6, 'Mysql', 'codingwithroby', 'A very nice book!', 4, 2023)
]     


class BookRequest(BaseModel):
    id: Optional[int]
    title:  str = Field(min_length=3)
    author: str = Field(min_length=1)
    description: str = Field(min_length=1, max_length=100)
    rating: int = Field(gt=1, lt=5)
    public_year: int = Field(gt=2000, lt=2023)

    class Config:
        schema_extra = {
            "example": {
                "title": "title",
                "author": "author name",
                "description": "sample de",
                "rating": 5,
                "public_year" : 2023
                
            }
        }

@app.get("/books")
async def get_data_from():
    return BOOKS


@app.get("/books/{book_id}")
async def read_book(book_id: int):
    for book in BOOKS:
        if book.id == book_id:
            return book
    raise HTTPException(status_code=404, detail="Item not found")

@app.get("/books/")
async def read_book(rating_num: int):
    rating_book_list = []
    for book in BOOKS:
        if book.rating == rating_num:
            rating_book_list.append(book)
    return rating_book_list


@app.post("/create_book")
async def new_book(book_request: BookRequest):
    new_book = Book(**book_request.dict())
    print(vars(new_book))
    BOOKS.append(find_book_id(new_book))
    

def find_book_id(book: Book):
    """
    book.id = 1
    if len(BOOKS) > 0:
        book.id = BOOKS[-1].id+ 1
    else:
        book.id = 1
    print(book.id)
    """
    book.id = 1 if len(BOOKS) == 0 else BOOKS[-1].id + 1
    return book


@app.put("/books/update_book")
async def new_update_book(book: BookRequest):
    book_change = False
    for i in range(len(BOOKS)):
        if BOOKS[i].id == book.id:
            BOOKS[i] = book
            book_change = True
    if not book_change:
        raise HTTPException(status_code=404, detail="Book not found")
    
@app.delete("/books/delete_book")
async def delete_book_new(book_id: int):
    for i in range(len(BOOKS)):
        if BOOKS[i].id == book_id:
            BOOKS.pop(book_id)
            break