list_of_elements = [6,7,8,9,3]




value = 1

for i in list_of_elements:
    value = value * i
    print("name of ", value, sep="$")
#print(value)
