num = int(input("Enter number"))
for i in range(2, num):
    if (num%i) == 0:
        print("Not a Prime number=", num)
        break
else:
    print("This is prime number", num)

