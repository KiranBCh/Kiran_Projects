x = 10
y = 20
y,x=x,y

print("X=", x)
print("Y=", y)
