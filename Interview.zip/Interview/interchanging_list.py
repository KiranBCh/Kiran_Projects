#1.Python program to interchange first and last elements in a list

list1 = [1, 2, 3]

print("Original list of elements:", list1)

list1[-1], list1[0] = list1[0], list1[-1]
#get = list1[-1], list1[0]
#list1[0], list1[-1] = get

print("After interchange the list of elements", list1)
