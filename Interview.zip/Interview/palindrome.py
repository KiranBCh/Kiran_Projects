print("Case 1")
print("Number Palindrome")
number = int(input("Please enter the number"))

num = number
palindrome = 0

while number > 0:
    digit = number % 10
    palindrome = palindrome * 10 + digit
    number //= 10
if num == palindrome:
    print("Given number is palindrome", num)
else:
    print("Given number is not palindrome", num)


print("Case 2")

a1 = str(num)
a2 = a1[::-1]
if a1 == a2:
    print("Given number is palindrome", a1)
else:
    print("Given number is not palindrome", a1)
