number = 4563123
print("Original Number", number)
reverse_number = 0
while number !=0:
    digi = number % 10
    reverse_number = reverse_number * 10 + digi
    number //= 10
print(reverse_number)




