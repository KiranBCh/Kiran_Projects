data_elements = ["kiran", "babu", 1, 2, 3, "hyd", "bang", 0, 6, 7]
print("Original elements", data_elements)
str1 = []
dig1 = []
for i in data_elements:
    if isinstance(i, str):
        str1.append(i)
    else:
        dig1.append(i)
print("Strings", str1)
print("Numbers", dig1)
