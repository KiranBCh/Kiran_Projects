list_of_elements = [1,2,3,4,56,7,8,8,5,4,3,2,4,5,76,89,9,9,9,6]


print("Sum of elements:", sum(list_of_elements))


sum1 = 0

for i in  list_of_elements:
    sum1 = sum1 + i
print("Without using the In-Built func", sum1)


