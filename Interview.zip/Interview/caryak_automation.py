import requests

headers = {
    'sec-ch-ua': '"Chromium";v="118", "Google Chrome";v="118", "Not=A?Brand";v="99"',
    'Referer': 'https://cit.caryak.org/',
    'sec-ch-ua-mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'sec-ch-ua-platform': '"Windows"',
}

trim_response = requests.get('https://dtlehta1thuw9.cloudfront.net/caryakcit/api/v1.0/vehicles/getTrimByVin/2GNAXHEV9L6283858', headers=headers).json()

trim_name = trim_response[0].get("trims", [])[0].get("name", "")

params = {
    'vin_number': '2GNAXHEV9L6283858',
    'mileage': '25000',
    'condition': 'Good',
    'runtime': 'true',
    'zip_code': '10006',
    'trim': str(trim_name),
    'emailAddress': 'raju1234@email.com',
}

batch_com = requests.get('https://dtlehta1thuw9.cloudfront.net/caryakcit/api/v1.0/vehicles/withoutSse', params=params, headers=headers).json()


main_url = f"https://dtlehta1thuw9.cloudfront.net/caryakcit/api/v1.0/vehicles/getOfferFromDB/{batch_com}/2GNAXHEV9L6283858"
response_results = requests.get(main_url, headers=headers)
import pdb;pdb.set_trace()




