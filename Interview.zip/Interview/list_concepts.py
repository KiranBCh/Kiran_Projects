list_of_elements = [432414,34124,123,441,54312,614145,6456367,875745,9756]
print("Original List is ", list_of_elements)

print("1. Python program to find smallest number in a list")
print("Case 1, Smallest number is", min(list_of_elements))
print("Case 2, Smallest number is", sorted(list_of_elements, reverse=True)[-1])
min1 = list_of_elements[0]
for i in list_of_elements:
    if i < min1:
        min1 = i
print("Case 3, Smallest number is", min1)

print("*******Close********")



print("2. Python program to find largest number in a list")
print("Case 1, Largest number is", max(list_of_elements))
print("Case 2, Largest number is", sorted(list_of_elements, reverse=True)[0])
max1 = list_of_elements[0]
for i in list_of_elements:
    if i > max1:
        max1 = i
print("Case 3, Largest number is", max1)
print("*****Close****")



print("3. Python program to find second largest number in a list")
print("Case 1, 2nd Largest number is ", sorted(list_of_elements, reverse=True)[1])
print("*****Close****")

print("4. Python program to find N largest elements from a list")
nth_ = 3#int(input("Enter the postions"))
print("Case 1, Nth Largest number is ", sorted(list_of_elements, reverse=True)[:nth_])
print("*****Close****")

print("5. Python program to print even numbers in a list")
list_of = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49]
print("Case 1", [i for i in list_of if i % 2 == 0])
print("Case 2", list(filter(lambda i: i %2 ==0, list_of)))
print("Case 1", [i for i in list_of if i % 2 !=0])

print("6. Python program to print positive numbers in a list")
x = [-10, 21, 4, -45, -66, 93, -11]
print("Original List", x)
for i in x:
    if i < 0:
        print(i, end=" ")
print("\n")
print("Case 2 using Lambda func", list(filter(lambda name: name < 0, x)))

print("7. Python | Count occurrences of an element in a list")

duplicate_list = [1,2,3,4,5,3,1,23,43,2,5,232,1,232,4,456,5,2,7,41,8,9,3,4,5,6,76,0,21,2,3,4,5,5,1,6,1,2,3,4,1,5,6]
print("Original List", duplicate_list)
print("Case 1 Count occurrence", [{i:duplicate_list.count(i) for i in list(set(duplicate_list))}])

print("Case 2 Count occurrence", [i for i in duplicate_list if duplicate_list.count(i) > 1])

print("8. Python | Remove empty tuples and list from a list")

original_list = [1,2,3,4,[],[""], (1,2,3), (), (" ")]
print("Original_list", original_list)
for i in original_list:
    if i != [] and i != ():
        print(i)

print("Case 2 Remove the empty tuples and lits", list(filter(None, original_list)))



print("9, Python | Sum of number digits in List")
test_list = [12, 67, 98, 34]
print("Original_list", test_list)
sum_list = []
for i in test_list:
    sum1 = 0
    for j in str(i):
        sum1 = sum1 + int(j)
    sum_list.append(sum1)
print("Case 1 sum of number digits in list:", sum_list)
print("Case 2 sum of num digits in list:", list(map(lambda i: sum(int(j) for j in str(i)), test_list)))

print("10, Remove common elements from two list in Python")

x1 = [1,2,3,4]
x2 = [4,3,0,5]
f1 = []
for i, j in zip(x1, x2):
    if i not in x2:
        f1.append(i)
    if j not in x1:
        f1.append(j)
print("Remove common elements from List", f1)


print("Case 1 Difference from two lists", list(set(x1).difference(set(x2))))
print("Case 2 Union from two lists", list(set(x1).union(set(x2))))
print("Case 3 Intersection from two lists", list(set(x1).intersection(set(x2))))
print("Case 4 Symmetric_difference from two lists",list(set(x1).symmetric_difference(set(x2))))
print("Case 5 Listcomparssion",[i for i in x1 if i not in x2],[j for j in x2 if j not in x1])

print("11. Move all zeroes to end of array using List Comprehension in Python")
arr = [1, 2, 0, 4, 3, 0, 5, 0]
print([nonZero for nonZero in arr if nonZero!=0] + [Zero for Zero in arr if Zero==0])



print("12. Python to remove all characters other than alphabets")


input1 = "$Gee*k;s..fo, r'Ge^eks?"
print("Original string", input1)
print("Remove all characters other than Alphabets: ", "".join(list(filter(lambda name: name.isalpha(), input1))))
print(f"A={ord('A')}, Z={ord('Z')}, a={ord('a')}, z={ord('z')}")
#for i in input1:
#    print("{}={}".format(str(i), ord(i)))


#A=65, Z=90, a=97, z=122
str1 = []
for i in input1:
    if ord(i) > 65 and ord(i) < 122:
            str1.append(i)
print("".join(str1))



print("13. Find average of a list in python")
"""
Input : [4, 5, 1, 2]
Output : 3
Explanation:
Sum of the elements is 4+5+1+2 = 12 and total number of elements is 4.
So average is 12/4 = 3

Input : [15, 9, 55]
Output : 26.33
"""
print("14. Given a list of numbers, the task is to write a Python program to remove all numbers with repetitive digits.")

list1 = [123, 323, 435, 989, 987, 765]
print(list1)
final_list = []
uni = []
for i in list1:
    num = str(i)
    if len(num) == len(set(num)):
        final_list.append(i)
print(final_list)
print("15. python-program-to-print-all-distinct-uncommon-digits-present-in-two-given-numbers")
A = 378212
B = 78124590
A1 = list(str(A))
B1 = list(str(B))
#.symmetric_difference
print(int("".join(sorted(list(set(A1).symmetric_difference(list(set(B1)))), reverse=True))))
print("16. python-convert-list-of-lists-to-list-of-sets")
A1 = [[1, 2, 1], [1, 2, 3], [2, 2, 2, 2], [0]]

print("Case 1 Convert list of lists to list of sets",[set(i) for i in A1])
print("Case 2 Convert list of lists to list of sets", list(map(set, A1)))

print("17. https://www.geeksforgeeks.org/python-program-to-convert-a-list-into-a-list-of-lists-using-a-step-value/")
test_list = [5, 6, 3, 2, 7, 1, 9, 10, 8]
K = 3
print(test_list)
dup= []
count = 0
d1 = []
for i in test_list:
    count = count + 1
    d1.append(i)

print([test_list[i::K] for i in range(0, K)])
print(dup)
