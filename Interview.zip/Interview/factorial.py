number = int(input("Enter the number = "))


fact = 1

if number < 0:
    print("Please enter the +ve values")
elif number == 0:
    print("Please enter the grater than 0")

else:
    for i in range(1, number +1):
        fact = fact * i
    print(fact)

