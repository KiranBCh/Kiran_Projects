from datetime import datetime, timedelta

# Original datetime "Mon 12:00"
#original_datetime = datetime(2023, 1, 2, 12, 0)  # Assuming the year is 2023
time_str = "Mon 12:00"
time_obj = datetime.strptime(time_str, "%a %H:%M")
print(time_str)


time_to_add = timedelta(hours=12)
print(time_to_add)
# Add the time duration to the original datetime
new_datetime = time_obj + time_to_add

# Format the new datetime as "Day Hour:Minute"
formatted_datetime = new_datetime.strftime("%a %H:%M")

print("Original Datetime:", formatted_datetime)
print("New Datetime after adding 12 hours:", formatted_datetime)
