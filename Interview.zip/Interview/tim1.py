from datetime import datetime

# Define the input strings
start_time_str = "Tue 01:00 AM"
end_time_str = "Fri 01:00 PM"

# Define the format for parsing the input strings
date_format = "%a %I:%M %p"

# Parse the input strings to create datetime objects
start_time = datetime.strptime(start_time_str, date_format)
end_time = datetime.strptime(end_time_str, date_format)

# Calculate the time difference
time_difference = end_time - start_time

# Get the total number of days, hours, and minutes
days = time_difference.days
hours, remainder = divmod(time_difference.seconds, 3600)
minutes = remainder // 60

# Print the result
print(f"Duration: {days} days, {hours} hours, and {minutes} minutes")

