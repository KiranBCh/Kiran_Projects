"""
import json
import csv


data = open("/home/ubuntu/kiranch/code_examples/doc_v1.csv", "r").readlines()


#out_data = csv.DictReader(data)
for rows in data:
    print(rows)
    import pdb;pdb.set_trace()
"""




import sys
import csv
import json

def csv_to_json(csv_file):
    json_data = []
    data = open(csv_file, "r").readlines()
    import pdb;pdb.set_trace()
    """
    with open(csv_file, 'r') as csvfile:
        csvreader = csv.DictReader(csvfile)
        for row in csvreader:
            json_data.append(row)
    """
    return json_data

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py input.csv")
        sys.exit(1)
    input_csv = sys.argv[1]
    output_json = input_csv.replace(".csv", ".json")

    data = csv_to_json(input_csv)

    with open(output_json, 'w') as jsonfile:
        json.dump(data, jsonfile, indent=4)

    print(f"CSV file '{input_csv}' converted to JSON file '{output_json}'.")

