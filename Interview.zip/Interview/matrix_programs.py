print("1. Python program to add two Matrices")
A1 = [[1,2,3], [4,5,6], [7,8,9]]
B1 = [[9,8,7], [6,5,4], [3,2,1]]
print("Rows", len(A1))
print("Columns", len(A1[0]))
c1 = [[0,0,0], [0,0,0], [0,0,0]]
for rows in range(len(A1)):
    for columns in range(len(A1[0])):
        c1[rows][columns] = A1[rows][columns] + B1[rows][columns]
print(c1, end="\n ")
print("*************************************************************")

print("2. Python program to multiply two matrices")

c2 = [[0,0,0], [0,0,0], [0,0,0]]

for row in range(len(A1)):
    for column in range(len(A1[0])):
        c2[row][column] = A1[rows][columns] * B1[rows][columns]
print(c2)

