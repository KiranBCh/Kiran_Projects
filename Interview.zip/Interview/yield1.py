def func():
    yield "My name is kiran"
outs = func()
print(next(outs))
#for out in outs:
#    print(out)





