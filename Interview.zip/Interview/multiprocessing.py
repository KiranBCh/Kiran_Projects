import multiprocessing
from multiprocessing import Pool
# Function to calculate the square of a number
def calculate_square(number):
    print(f"Calculating square of {number}")
    result = number ** 2
    print(f"Square of {number} is {result}")

if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]

    # Create a process pool
    pool = multiprocessing.Pool()
    # Map the function to the list of numbers using the process pool
    pool.map(calculate_square, numbers)

    # Close the pool and wait for the processes to finish
    #pool.close()
    #pool.join()

    print("All processes are done")

