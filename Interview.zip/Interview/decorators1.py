def function1(func):

    def inner():
        print("kiran is decorated")
        func()
    return inner

@function1
def outer():
    return print("Outside function")

#value = function1(outer)
outer()
#value()









def rani(func):
    def inner1():
        print("this is new one")
        func()
    return inner1

@rani
def babu():
    print("My name is Babu")

babu()
