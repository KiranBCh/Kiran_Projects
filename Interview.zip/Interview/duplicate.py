elements = [1,2,3,4,5,6,7,8,6,5,43,2, 3, 3, 3]

#Case 1:
print("Original_List", elements)
print(set(elements))


#Case 2:
dup = []
fin = []
for i in elements:
    if i not in dup:
        dup.append(i)
    else:
        fin.append(i)
print("without duplicate values", dup)
print("duplicate values", fin)


#Case 3
print("Case 3")
duplicates = [value for value in elements if elements.count(value) > 1]
print(duplicates)

#Case 4

print("Case 4")
print(({value:elements.count(value)} for value in elements))




