elements = [1,2,3,4,2,1,4,5,2,1,1,23,4,5,6]
elements_str = ["apple", "bananna", "juice", "na"]
print("Original_str", elements_str)
#Case 1:

print("direct sort", sorted(elements))
print("with reverese True", sorted(elements, reverse=True))

print("sorted len of the strings", sorted(elements_str, key=len))
print("sorted len of the strings with reve", sorted(elements_str, key=len, reverse=True))

print("using Lambda Functions")
print("Sorted len of the strings with Accending", sorted(elements_str, key=lambda name: len(name)))
print("Sorted len of the strings with Dec", sorted(elements_str, key=lambda kiran: len(kiran), reverse=True))
print("Sorting Tuples by a Specific Element:")
people = [('Alice', 25), ('Bob', 30), ('Charlie', 22), ('David', 28), ('Alias', 10)]
sorted_people_by_age = sorted(people, key=lambda person: person[1])
print(sorted_people_by_age)

print("Sorting a Dictionary by Values:")
scores = {'Alice': 95, 'Bob': 82, 'Charlie': 78, 'David': 90}
sorted_scores = dict(sorted(scores.items(), key=lambda item: item[0], ))#reverse=True))
print(sorted_scores)

#Case 2:
sort_list = []
