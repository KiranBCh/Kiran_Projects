import pandas as pd

# Sample data (replace with your own data)
data = {
    'datetime': ['2023-09-15 08:30:00', '2023-09-15 09:15:00', '2023-09-15 10:45:00', '2023-09-15 08:45:00'],
    'value': [10, 15, 20, 12]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Convert 'datetime' column to datetime format
df['datetime'] = pd.to_datetime(df['datetime'])

# Group data by hour and perform aggregation (e.g., sum)
hourly_data = df.groupby(pd.Grouper(key='datetime', freq='H')).sum()

print(hourly_data)
