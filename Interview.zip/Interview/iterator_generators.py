class Iterator:
    """
    An iterator is an object that implements the iterator protocol, which consists of two methods: __iter__() and __next__(). The __iter__() method returns the iterator object itself, and the __next__() method returns the next value from the sequence or raises the StopIteration exception if there are no more items.
    """
    def __init__(self, max_count):
        self.max_count = max_count
        self.count = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.count < self.max_count:
            value = self.count
            value = value * 2
            self.count += 1
            return value
        else:
            raise StopIteration


values = Iterator(5)
for value in values:
    print(value)


def func(max_count):
    count = 0
    while count < max_count:
        yield count
        count += 1
        print("Count ",count)

values = func(5)
for i in values:
    print(i)
