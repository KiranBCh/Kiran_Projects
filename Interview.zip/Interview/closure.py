"""
Python closure is a nested function that allows us to access variables of the outer function even after the outer function is closed.
"""
print("Case 1")
def kiran():
    print("my name is kiran")
    def babu():
        print("age is ")
    babu()

print(kiran())

print("Case 2")

def raju(name):
    #def rani():
    #    print(f"This is closer functions{name}")
    #rani()
    return lambda: "Hi " + name

val = raju("Kiran")
print(val)
print(val())



print("Case 3 function with call another func")




def kiran(x, y):
    return x + y

def calca(kiran, x, y):
    return kiran(x, y)


va = calca(kiran, 10, 20)

print(va)
