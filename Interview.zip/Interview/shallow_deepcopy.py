import copy


copy_list = [1,2, [30, 40]]

copy1 = copy.copy(copy_list)
print("Original Copy Lis", copy_list)

copy1[2][0] = 100

print("Shallow Copy", copy1)
print("After shallow copy Original", copy_list)

print("***********************************************")


copy_list1 = [1,2, [30, 40]]
copy2 = copy.deepcopy(copy_list1)


print("Original List", copy_list1)

copy2[2][0] = 30*20

print("Deepcopy list", copy2)
print("After deepcopy list", copy2)

