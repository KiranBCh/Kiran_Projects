import threading


def sum(a, b):
    print(a+b)
def mul(a,b):
    print(a*b)

thread1 = threading.Thread(target=sum(10, 20), )
thread2 = threading.Thread(target=mul(10, 20), )


thread1.start()
thread2.start()


thread1.join()
thread2.join()
print("Threading")
import pdb;pdb.set_trace()

