from datetime import datetime, timedelta
start_time_str = "Mon 12:00 PM"
end_time_str = "Fri 00:00 AM"
day_mapping = {
    'Mon': 0,
    'Tue': 1,
    'Wed': 2,
    'Thu': 3,
    'Fri': 4,
    'Sat': 5,
    'Sun': 6
}

# Parse the day and time strings to create datetime objects
start_day = day_mapping[start_time_str[:3]]
end_day = day_mapping[end_time_str[:3]]

# Calculate the number of days between the two dates
day_difference = (end_day - start_day) % 7  # Use modulo 7 to handle wrap-around
print(day_difference* 24)
# Parse the time part
start_time = datetime.strptime(start_time_str.replace("Mon", "").strip(), "%H:%M %p")
end_time = datetime.strptime(end_time_str.replace("Fri", "").strip(), "%H:%M %p")

# Calculate the time difference
time_difference = end_time - start_time

# Add the day difference to the time difference
total_difference = timedelta(days=day_difference, seconds=time_difference.seconds)

# Get the total number of days, hours, and minutes
days = total_difference.days
seconds = total_difference.seconds
hours, seconds = divmod(seconds, 3600)
hours1 = days * hours
minutes, seconds = divmod(seconds, 60)

# Print the result
print(f"Duration: {days} days, {hours} hours, and {minutes} minutes")
print(hours1)
