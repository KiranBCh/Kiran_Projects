x_list = [1,2,3]


values = iter(x_list)


print(next(values))
print(next(values))
print(next(values))


for i in values:
    print(next(i))



print("Custom iterator")


class Powvalue:

    def __init__(self, value):
        self.max_value = value
        self.num = 30

    def __iter__(self):
        return self

    def __next__(self):
        return self.max_value * self.num
va = Powvalue(10)

print(next(va))
