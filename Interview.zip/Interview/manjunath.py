import requests

response = requests.get('http://65.2.23.32:8000/update')
print(response.text)
print(response.status_code)
