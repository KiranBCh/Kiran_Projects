import requests

cookies = {
    'session-id': '145-0750498-6487049',
    'ubid-main': '132-2148061-4897601',
    'x-main': '"2Kt2p@eOin8DSAzNgUsMn@?7eKMrMz6XYByi4Vwz3wlMahyp6Sr@Tf1AODO6VXji"',
    'at-main': 'Atza|IwEBIF2qXu-C115WsC-5PPj6eZPrxZujfaeya0U1r1K1gBbcQM3Hf745Xif7nMY9YTNjTa3ArMImloTD_sPGmkDkNUrIcdjCsreFgytY1SM4fYXkyy7hwI-Rat3NTbSpnIBLjRjvcLOQpwCsT_-kiCLpxj8a-nK5RnOO2AyrtuASfEHeCJ8Y0dARW8fntynar3Eg5J7gy75gY9SdE0lzBmUC72fBUxl8bijWSbIw-HKjVS49Zg',
    'sess-at-main': '"6WMdu7sUus8h6TDH/ZqYgVlrGnU9HyHA7KQBWd+QgQE="',
    'uu': 'eyJpZCI6InV1ZjU4ZTkwNWM0ZmNmNGIzOGE2NTIiLCJwcmVmZXJlbmNlcyI6eyJmaW5kX2luY2x1ZGVfYWR1bHQiOmZhbHNlfSwidWMiOiJ1cjE2OTY2MzMyNSJ9',
    'session-id-time': '2082787201l',
    'ad-oo': '0',
    'as': '%7B%22n%22%3A%7B%22t%22%3A%5B0%2C0%5D%2C%22tr%22%3A%5B0%2C0%5D%2C%22in%22%3A%5B0%2C0%5D%2C%22ib%22%3A%5B0%2C0%5D%7D%7D',
    'session-token': 'drUn0KOGcRxZ5P5vLs2F2hcg5qTWfEBEZsxIUT3OsErFiKgFKpvdIcQmZHo/LnppNf+UJhE+n8mAOWrIxOruyM1n3B06Rqn8kJmobAOjMM1KVS+eCqPHURMzmJgT6pHTRnmoKLI5H5u5hJ4zfxC2DkjQ5b5WB8b26XaKfPlZ+2jH2CyNf0/W/h/m9ta1+bpQW9J1BnzwnN84LdKOlA8NFx25+HkAaL8bg9wryefb38rpEKhxM4bmmfPxTPn2Wvuninw/8TPluU/kIc0yzS0liNqtGixMMkaVTi8bghlz0v2VVeSgBgGViu2C1qMQqjLQAVULZZfdrboJ5HsG7Tt/L42pzrjnvGuYlJ6V/mTqQiyagcDX3jRQ4lwrWbxCb6lE',
    'mp_d7f79c10b89f9fa3026f2fb08d3cf36d_mixpanel': '%7B%22distinct_id%22%3A%20%22%24device%3A18a4f1d65d5d97-002772146e3bad-26031f51-e1000-18a4f1d65d5d97%22%2C%22%24device_id%22%3A%20%2218a4f1d65d5d97-002772146e3bad-26031f51-e1000-18a4f1d65d5d97%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D',
}

headers = {
    'authority': 'caching.graphql.imdb.com',
    'accept': 'application/graphql+json, application/json',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'content-type': 'application/json',
    'origin': 'https://www.imdb.com',
    'referer': 'https://www.imdb.com/',
    'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Google Chrome";v="116"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    'x-amzn-sessionid': '145-0750498-6487049',
    'x-imdb-client-name': 'imdb-web-next',
    'x-imdb-client-rid': 'BX9PJBBC5HKE5KP1A2KY',
    'x-imdb-user-country': 'GB',
    'x-imdb-user-language': 'en-GB',
    'x-imdb-weblab-treatment-overrides': '{"IMDB_DESKTOP_SEARCH_ALGORITHM_UPDATES_577300":"T1"}',
}

params = {
    'operationName': 'TMD_Storyline',
    'variables': '{"isAutoTranslationEnabled":false,"locale":"en-GB","titleId":"tt0088247"}',
    'extensions': '{"persistedQuery":{"sha256Hash":"ad739d75c0062966ebf299e3aedc010e17888355fde6d0eee417f30368f38c14","version":1}}',
}

response = requests.get('https://caching.graphql.imdb.com/', params=params,  headers=headers)
